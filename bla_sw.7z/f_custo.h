
/******************************************************************************
- TITULO       : f_custo.h
- PROPOSITO    :
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 11/12/2014 - Daniel Vieira, Anderson Millan
- MODIFICACOES : -
*******************************************************************************/

#ifndef F_CUSTO_H_
#define F_CUSTO_H_

#include "estruturas.h"

double f_custo(double x[], void *params);
double f_custo_ventoth(double x[], void *params);
double f_custo_ventoff(double x[], void *params);
double f_custoAlcanceMaximo(double x[], void *params);

#endif /* F_CUSTO_H_ */
