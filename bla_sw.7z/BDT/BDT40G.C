//\ SS-40 S/F Bal. BDT401 baseado 'DD40-4' c/ alteracao no Cd da Sub-municao
//\    D40-41 - ExT401 - DDT401 -  3 Sep 1986
//\ DATA DE MONTAGEM :  29 Out 1987 - 15:04:58    ARQUIVO : 'BDT403'


//\ [KG] TOTAL ROCKET MASS
DDT.Mass       = 185.6;
//\ [KG] PROPELLANT MASS
DDT.Propmass   = 68.84;
//\ [M] LAUNCHER LENGHT
DDT.Laul       = 5.42;
//\ [M] REFERENCE DIAMETER OF ROCKET
DDT.Diaref     = 0.1770;
//\ NUMBER OF POINTS IN THRUST PROFILE
DDT.N_points   = 18.0;
//\ [M2] EXAUST AREA
DDT.Ass        = 0.016061;
//\ [N/M2] REFERENCE PRESSURE
DDT.Pnom       = 94540.0;
//\ [N] REFERENCE THRUST * STEP
DDT.Emp        = 10300 * 4;//11130.00 * 4;
//\ [DEG] MAXIMUM ELEVATION
DDT.Elevmax    = 60.0;
//\ [M/S] MAXIMUM WIND VELOCITY
DDT.Vwmax      = 15.0;
//\ CORRECTION FACTOR FOR DRAG IN THRUSTPHASE
DDT.Cdadj      = 0.78638;
//\ CORRECTION FACTOR FOR DRAG IN SEC. BAL.
DDT.Cdadjsm    = 36.00;
//\ WEIGHTING FACTOR
DDT.Fpon       = 1.00000;

DDT.T_emp_step[ 1] = 0.0;
DDT.T_emp_step[ 2] = 1.0;
DDT.T_emp_step[ 3] = 2.0;
DDT.T_emp_step[ 4] = 4.0;
DDT.T_emp_step[ 5] = 6.0;
DDT.T_emp_step[ 6] = 8.0;
DDT.T_emp_step[ 7] = 9.0;
DDT.T_emp_step[ 8] = 10.0;
DDT.T_emp_step[ 9] = 13.0;
DDT.T_emp_step[10] = 16.0;
DDT.T_emp_step[11] = 17.0;
DDT.T_emp_step[12] = 18.0;
DDT.T_emp_step[13] = 19.0;
DDT.T_emp_step[14] = 21.0;
DDT.T_emp_step[15] = 22.0;
DDT.T_emp_step[16] = 24.0;
DDT.T_emp_step[17] = 26.0;
DDT.T_emp_step[18] = 30.0;
DDT.T_emp_step[19] = 0.0;
DDT.T_emp_step[20] = 0.0;


DDT.P_emp_tp[1][ 1] = 7.8985889E-1;
DDT.P_emp_tp[1][ 2] = 7.2023434E-1;
DDT.P_emp_tp[1][ 3] = 6.7534277E-1;
DDT.P_emp_tp[1][ 4] = 6.4522846E-1;
DDT.P_emp_tp[1][ 5] = 6.4499252E-1;
DDT.P_emp_tp[1][ 6] = 6.5347844E-1;
DDT.P_emp_tp[1][ 7] = 6.5799592E-1;
DDT.P_emp_tp[1][ 8] = 6.6179844E-1;
DDT.P_emp_tp[1][ 9] = 6.5957204E-1;
DDT.P_emp_tp[1][10] = 6.4406293E-1;
DDT.P_emp_tp[1][11] = 6.2707942E-1;
DDT.P_emp_tp[1][12] = 5.8692074E-1;
DDT.P_emp_tp[1][13] = 5.3164415E-1;
DDT.P_emp_tp[1][14] = 2.8137657E-1;
DDT.P_emp_tp[1][15] = 1.7078660E-1;
DDT.P_emp_tp[1][16] = 7.5472696E-2;
DDT.P_emp_tp[1][17] = 3.9036173E-2;
DDT.P_emp_tp[1][18] = 0.0000000E+0;
DDT.P_emp_tp[1][19] = 0.0000000E+0;
DDT.P_emp_tp[1][20] = 0.0000000E+0;

DDT.P_emp_tp[2][ 1] = 2.2643065E-3;
DDT.P_emp_tp[2][ 2] = 1.7743352E-3;
DDT.P_emp_tp[2][ 3] = 1.6758851E-3;
DDT.P_emp_tp[2][ 4] = 1.6713847E-3;
DDT.P_emp_tp[2][ 5] = 1.7390309E-3;
DDT.P_emp_tp[2][ 6] = 1.7560097E-3;
DDT.P_emp_tp[2][ 7] = 1.6858715E-3;
DDT.P_emp_tp[2][ 8] = 1.6031072E-3;
DDT.P_emp_tp[2][ 9] = 1.3229921E-3;
DDT.P_emp_tp[2][10] = 8.0909141E-4;
DDT.P_emp_tp[2][11] = 2.4991093E-5;
DDT.P_emp_tp[2][12] = -1.0014760E-3;
DDT.P_emp_tp[2][13] = -2.8924933E-3;
DDT.P_emp_tp[2][14] = -1.0224261E-2;
DDT.P_emp_tp[2][15] = -1.2152149E-2;
DDT.P_emp_tp[2][16] = -1.2315097E-2;
DDT.P_emp_tp[2][17] = -1.2183561E-2;
DDT.P_emp_tp[2][18] = 0.0000000E+0;
DDT.P_emp_tp[2][19] = 0.0000000E+0;
DDT.P_emp_tp[2][20] = 0.0000000E+0;

DDT.P_emp_tp[3][ 1] = 5.2475657E-6;
DDT.P_emp_tp[3][ 2] = 3.0010441E-7;
DDT.P_emp_tp[3][ 3] = 3.6918127E-7;
DDT.P_emp_tp[3][ 4] = -8.1050467E-7;
DDT.P_emp_tp[3][ 5] = -1.4270472E-6;
DDT.P_emp_tp[3][ 6] = -1.7594825E-6;
DDT.P_emp_tp[3][ 7] = -1.8535072E-6;
DDT.P_emp_tp[3][ 8] = -2.3481268E-6;
DDT.P_emp_tp[3][ 9] = -1.8478135E-6;
DDT.P_emp_tp[3][10] = -4.7661523E-6;
DDT.P_emp_tp[3][11] = -1.3276204E-5;
DDT.P_emp_tp[3][12] = -1.4392798E-5;
DDT.P_emp_tp[3][13] = -3.3004181E-5;
DDT.P_emp_tp[3][14] = 3.1857945E-6;
DDT.P_emp_tp[3][15] = 6.7209670E-5;
DDT.P_emp_tp[3][16] = 6.0122570E-5;
DDT.P_emp_tp[3][17] = 5.4883965E-5;
DDT.P_emp_tp[3][18] = 0.0000000E+0;
DDT.P_emp_tp[3][19] = 0.0000000E+0;
DDT.P_emp_tp[3][20] = 0.0000000E+0;

DDT.P_emp_tp[4][ 1] = 6.9747134E-1;
DDT.P_emp_tp[4][ 2] = 6.4433624E-1;
DDT.P_emp_tp[4][ 3] = 6.0833253E-1;
DDT.P_emp_tp[4][ 4] = 5.7864030E-1;
DDT.P_emp_tp[4][ 5] = 5.7437924E-1;
DDT.P_emp_tp[4][ 6] = 5.8048835E-1;
DDT.P_emp_tp[4][ 7] = 5.8704756E-1;
DDT.P_emp_tp[4][ 8] = 5.9254805E-1;
DDT.P_emp_tp[4][ 9] = 6.0282797E-1;
DDT.P_emp_tp[4][10] = 6.0174565E-1;
DDT.P_emp_tp[4][11] = 5.9616829E-1;
DDT.P_emp_tp[4][12] = 5.4336427E-1;
DDT.P_emp_tp[4][13] = 4.2691255E-1;
DDT.P_emp_tp[4][14] = 1.5373276E-1;
DDT.P_emp_tp[4][15] = 1.0063650E-1;
DDT.P_emp_tp[4][16] = 4.2835951E-2;
DDT.P_emp_tp[4][17] = 2.1972672E-2;
DDT.P_emp_tp[4][18] = 0.0000000E+0;
DDT.P_emp_tp[4][19] = 0.0000000E+0;
DDT.P_emp_tp[4][20] = 0.0000000E+0;

DDT.P_emp_tp[5][ 1] = 8.7873390E-1;
DDT.P_emp_tp[5][ 2] = 7.7817921E-1;
DDT.P_emp_tp[5][ 3] = 7.2677852E-1;
DDT.P_emp_tp[5][ 4] = 6.9269859E-1;
DDT.P_emp_tp[5][ 5] = 6.9360343E-1;
DDT.P_emp_tp[5][ 6] = 7.0278828E-1;
DDT.P_emp_tp[5][ 7] = 7.0544458E-1;
DDT.P_emp_tp[5][ 8] = 7.0639364E-1;
DDT.P_emp_tp[5][ 9] = 6.9637142E-1;
DDT.P_emp_tp[5][10] = 6.6129654E-1;
DDT.P_emp_tp[5][11] = 6.2707942E-1;
DDT.P_emp_tp[5][12] = 5.9177721E-1;
DDT.P_emp_tp[5][13] = 5.6074345E-1;
DDT.P_emp_tp[5][14] = 4.5721569E-1;
DDT.P_emp_tp[5][15] = 3.3663468E-1;
DDT.P_emp_tp[5][16] = 1.4757532E-1;
DDT.P_emp_tp[5][17] = 7.5285004E-2;
DDT.P_emp_tp[5][18] = 0.0000000E+0;
DDT.P_emp_tp[5][19] = 0.0000000E+0;
DDT.P_emp_tp[5][20] = 0.0000000E+0;


//\ F(ELEV.)
DDT.V0_el[1] = 4.6025923E+1;
DDT.V0_el[2] = -1.3673517E+0;
DDT.V0_el[3] = 5.7701395E-1;


//\ F(PROP. TEMP.)
DDT.V0_tp[1] = 1.0000000E+0;
DDT.V0_tp[2] = 1.0570223E-3;
DDT.V0_tp[3] = 8.7514509E-7;


//\ F(ELEV.)
DDT.T0_el[1] = 2.3364562E-1;
DDT.T0_el[2] = 7.2610863E-3;
DDT.T0_el[3] = -3.2076329E-3;


//\ F(PROP. TEMP.)
DDT.T0_tp[1] = 1.0000000E+0;
DDT.T0_tp[2] = -1.0985965E-3;
DDT.T0_tp[3] = -2.9932566E-7;


//\ [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec1[1] = 1.0000000E+3;
DDT.Hejec1[2] = 4.0000000E+1;
DDT.Hejec1[3] = 0.0000000E+0;
DDT.Hejec1[4] = 2.0000000E+3;
DDT.Hejec1[5] = 3.0000000E+3;

//\ [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec2[1] = 3.0000000E+3;
DDT.Hejec2[2] = 0.0000000E+0;
DDT.Hejec2[3] = 0.0000000E+0;
DDT.Hejec2[4] = 3.0000000E+3;
DDT.Hejec2[5] = 3.0000000E+3;


//\ [SEC] DELAY OF EJECTION
DDT.Delta_ejec = 0.100;

//\ WIND WEIGHTING POLYNOM
DDT.Bwiwe[1] = 5.5207E+1;
DDT.Bwiwe[2] = -4.8166E+2;
DDT.Bwiwe[3] = 1.5315E+3;
DDT.Bwiwe[4] = -2.4183E+3;
DDT.Bwiwe[5] = 1.8730E+3;
DDT.Bwiwe[6] = -5.6708E+2;


//\ HEIGHT OF END OF THRUSTPHASE
DDT.Hmthph[1] = -5.0714E+2;
DDT.Hmthph[2] = 3.3774E+3;
DDT.Hmthph[3] = -8.0050E+2;
DDT.Hmthph[4] = 0.0000E+0;


DDT.Cwss[ 0] = 0.55739;
DDT.Cwss[ 1] = 0.55739;
DDT.Cwss[ 2] = 0.55739;
DDT.Cwss[ 3] = 0.55739;
DDT.Cwss[ 4] = 0.55739;
DDT.Cwss[ 5] = 0.55739;
DDT.Cwss[ 6] = 0.55739;
DDT.Cwss[ 7] = 0.55739;
DDT.Cwss[ 8] = 0.55902;
DDT.Cwss[ 9] = 0.62659;
DDT.Cwss[10] = 0.71489;
DDT.Cwss[11] = 0.74638;
DDT.Cwss[12] = 0.74704;
DDT.Cwss[13] = 0.73600;
DDT.Cwss[14] = 0.71887;
DDT.Cwss[15] = 0.70016;
DDT.Cwss[16] = 0.68111;
DDT.Cwss[17] = 0.66134;
DDT.Cwss[18] = 0.64104;
DDT.Cwss[19] = 0.62154;
DDT.Cwss[20] = 0.60343;
DDT.Cwss[21] = 0.58561;
DDT.Cwss[22] = 0.56985;
DDT.Cwss[23] = 0.55593;
DDT.Cwss[24] = 0.54142;
DDT.Cwss[25] = 0.52746;
DDT.Cwss[26] = 0.51353;
DDT.Cwss[27] = 0.50021;
DDT.Cwss[28] = 0.48749;
DDT.Cwss[29] = 0.47562;
DDT.Cwss[30] = 0.46456;
DDT.Cwss[31] = 0.45399;
DDT.Cwss[32] = 0.44278;
DDT.Cwss[33] = 0.43183;
DDT.Cwss[34] = 0.42107;
DDT.Cwss[35] = 0.41039;
DDT.Cwss[36] = 0.39962;
DDT.Cwss[37] = 0.38890;
DDT.Cwss[38] = 0.37826;
DDT.Cwss[39] = 0.36754;
DDT.Cwss[40] = 0.35699;

//\ [MILS] MAX. TACTICAL ELEVATION
DDT.Elev_tat   = 1000.0;
//\ [MILS] MIN. TACTICAL ELEVATION
DDT.Elev_min   = 250.0;
//\ [MILS]  F                       {<<<5.2}
//\ [MILS]  F                       {<<<5.2}

//\ FLIGHT_TIME/ FUZE_TIME (low ejection)
DDT.Fuzecor1[1] = 1.4430000E+0;
DDT.Fuzecor1[2] = -1.6270000E-2;
DDT.Fuzecor1[3] = 1.5630000E-4;

//\ FLIGHT_TIME/ FUZE_TIME (high ejection)
DDT.Fuzecor2[1] = 2.9230000E+0;
DDT.Fuzecor2[2] = -7.2940000E-2;
DDT.Fuzecor2[3] = 7.1680000E-4;

//\ ELEVATION CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2
//DDT.Elcor[1][1] = 0.000301+( 0.000301)*-0.5;
//DDT.Elcor[1][2] = -0.003875+( -0.003875)*-0.5;
//DDT.Elcor[1][3] = -0.000215+( -0.000215)*-0.5;
//DDT.Elcor[1][4] = 0.000063+( 0.000063)*-0.5;
//DDT.Elcor[1][5] = 0.000047+( 0.000047)*-0.5;
//DDT.Elcor[1][6] = 0.000017+( 0.000017)*-0.5;
//DDT.Elcor[1][7] = 0.000382+( 0.000382)*-0.5;
//DDT.Elcor[1][8] = 0.000143+( 0.000143)*-0.5;
//DDT.Elcor[1][9] = -0.000048+( -0.000048)*-0.5;
//
//DDT.Elcor[2][1] = -0.000761+( -0.000761)*-0.5;
//DDT.Elcor[2][2] = 0.029081+( 0.029081)*-0.5;
//DDT.Elcor[2][3] = 0.002525+( 0.002525)*-0.5;
//DDT.Elcor[2][4] = 0.000042+( 0.000042)*-0.5;
//DDT.Elcor[2][5] = -0.000080+( -0.000080)*-0.5;
//DDT.Elcor[2][6] = -0.000044+( -0.000044)*-0.5;
//DDT.Elcor[2][7] = -0.001693+( -0.001693)*-0.5;
//DDT.Elcor[2][8] = -0.000288+( -0.000288)*-0.5;
//DDT.Elcor[2][9] = -0.000047+( -0.000047)*-0.5;
//
//DDT.Elcor[3][1] = 0.000486+( 0.000486)*-0.5;
//DDT.Elcor[3][2] = -0.018127+( -0.018127)*-0.5;
//DDT.Elcor[3][3] = -0.001941+( -0.001941)*-0.5;
//DDT.Elcor[3][4] = -0.000060+( -0.000060)*-0.5;
//DDT.Elcor[3][5] = 0.000045+( 0.000045)*-0.5;
//DDT.Elcor[3][6] = 0.000028+( 0.000028)*-0.5;
//DDT.Elcor[3][7] = 0.000583+( 0.000583)*-0.5;
//DDT.Elcor[3][8] = -0.000049+( -0.000049)*-0.5;
//DDT.Elcor[3][9] = 0.000033+( 0.000033)*-0.5;

//DDT.Elcor[1][1] = 0.000301+0.01;
//DDT.Elcor[1][2] = -0.003875+0.01;
//DDT.Elcor[1][3] = -0.000215+0.01;
//DDT.Elcor[1][4] = 0.000063+0.01;
//DDT.Elcor[1][5] = 0.000047+0.01;
//DDT.Elcor[1][6] = 0.000017+0.01;
//DDT.Elcor[1][7] = 0.000382+0.01;
//DDT.Elcor[1][8] = 0.000143+0.01;
//DDT.Elcor[1][9] = -0.000048+0.01;
//
//DDT.Elcor[2][1] = -0.000761+0.01;
//DDT.Elcor[2][2] = 0.029081+0.01;
//DDT.Elcor[2][3] = 0.002525+0.01;
//DDT.Elcor[2][4] = 0.000042+0.01;
//DDT.Elcor[2][5] = -0.000080+0.01;
//DDT.Elcor[2][6] = -0.000044+0.01;
//DDT.Elcor[2][7] = -0.001693+0.01;
//DDT.Elcor[2][8] = -0.000288+0.01;
//DDT.Elcor[2][9] = -0.000047+0.01;
//
//DDT.Elcor[3][1] = 0.000486+0.01;
//DDT.Elcor[3][2] = -0.018127+0.01;
//DDT.Elcor[3][3] = -0.001941+0.01;
//DDT.Elcor[3][4] = -0.000060+0.01;
//DDT.Elcor[3][5] = 0.000045+0.01;
//DDT.Elcor[3][6] = 0.000028+0.01;
//DDT.Elcor[3][7] = 0.000583+0.01;
//DDT.Elcor[3][8] = -0.000049+0.01;
//DDT.Elcor[3][9] = 0.000033+0.01;

DDT.Elcor[1][1] =0.0103010000000000;
DDT.Elcor[1][2] =0.00612500000000000;
DDT.Elcor[1][3] =0.00978500000000000;
DDT.Elcor[1][4] =0.0100630000000000;
DDT.Elcor[1][5] =0.0100470000000000;
DDT.Elcor[1][6] =0.0100170000000000;
DDT.Elcor[1][7] =0.0103820000000000;
DDT.Elcor[1][8] =0.0101430000000000;
DDT.Elcor[1][9] =0.00995200000000000;
DDT.Elcor[2][1] =0.00923900000000000;
DDT.Elcor[2][2] =0.0390810000000000;
DDT.Elcor[2][3] =0.0125250000000000;
DDT.Elcor[2][4] =0.0100420000000000;
DDT.Elcor[2][5] =0.00992000000000000;
DDT.Elcor[2][6] =0.00995600000000000;
DDT.Elcor[2][7] =0.00830700000000000;
DDT.Elcor[2][8] =0.00971200000000000;
DDT.Elcor[2][9] =0.00995300000000000;
DDT.Elcor[3][1] =0.0104860000000000;
DDT.Elcor[3][2] =-0.00812700000000000;
DDT.Elcor[3][3] =0.00805900000000000;
DDT.Elcor[3][4] =0.00994000000000000;
DDT.Elcor[3][5] =0.0100450000000000;
DDT.Elcor[3][6] =0.0100280000000000;
DDT.Elcor[3][7] =0.0105830000000000;
DDT.Elcor[3][8] =0.00995100000000000;
DDT.Elcor[3][9] =0.0100330000000000;


//\ AZIMUTH CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2
//DDT.Azcor[1][1] = -0.000017*8.5;
//DDT.Azcor[1][2] = -0.000053*8.5;
//DDT.Azcor[1][3] = -0.000038*8.5;
//DDT.Azcor[1][4] = -0.015954*8.5;
//DDT.Azcor[1][5] = -0.002367*8.5;
//DDT.Azcor[1][6] = -0.000442*8.5;
//DDT.Azcor[1][7] = -0.000034*8.5;
//DDT.Azcor[1][8] = 0.000037*8.5;
//DDT.Azcor[1][9] = 0.000063*8.5;
//
//DDT.Azcor[2][1] = -0.000028*8.5;
//DDT.Azcor[2][2] = 0.000150*8.5;
//DDT.Azcor[2][3] = 0.000089*8.5;
//DDT.Azcor[2][4] = -0.002382*8.5;
//DDT.Azcor[2][5] = 0.003626*8.5;
//DDT.Azcor[2][6] = 0.001372*8.5;
//DDT.Azcor[2][7] = 0.000054*8.5;
//DDT.Azcor[2][8] = -0.000057*8.5;
//DDT.Azcor[2][9] = -0.000157*8.5;
//
//DDT.Azcor[3][1] = 0.000032*8.5;
//DDT.Azcor[3][2] = -0.000017*8.5;
//DDT.Azcor[3][3] = -0.000045*8.5;
//DDT.Azcor[3][4] = 0.001796*8.5;
//DDT.Azcor[3][5] = -0.004708*8.5;
//DDT.Azcor[3][6] = -0.001668*8.5;
//DDT.Azcor[3][7] = -0.000049*8.5;
//DDT.Azcor[3][8] = -0.000002*8.5;
//DDT.Azcor[3][9] = 0.000106*8.5;

DDT.Azcor[1][1] =-0.000144500000000000;
DDT.Azcor[1][2] =-0.000450500000000000;
DDT.Azcor[1][3] =-0.000323000000000000;
DDT.Azcor[1][4] =-0.135609000000000;
DDT.Azcor[1][5] =-0.0201195000000000;
DDT.Azcor[1][6] =-0.00375700000000000;
DDT.Azcor[1][7] =-0.000289000000000000;
DDT.Azcor[1][8] =0.000314500000000000;
DDT.Azcor[1][9] =0.000535500000000000;

DDT.Azcor[2][1] =-0.000238000000000000;
DDT.Azcor[2][2] =0.00127500000000000;
DDT.Azcor[2][3] =0.000756500000000000;
DDT.Azcor[2][4] =-0.0202470000000000;
DDT.Azcor[2][5] =0.0308210000000000;
DDT.Azcor[2][6] =0.0116620000000000;
DDT.Azcor[2][7] =0.000459000000000000;
DDT.Azcor[2][8] =-0.000484500000000000;
DDT.Azcor[2][9] =-0.00133450000000000;

DDT.Azcor[3][1] =0.000272000000000000;
DDT.Azcor[3][2] =-0.000144500000000000;
DDT.Azcor[3][3] =-0.000382500000000000;
DDT.Azcor[3][4] =0.0152660000000000;
DDT.Azcor[3][5] =-0.0400180000000000;
DDT.Azcor[3][6] =-0.0141780000000000;
DDT.Azcor[3][7] =-0.000416500000000000;
DDT.Azcor[3][8] =-1.70000000000000e-05;
DDT.Azcor[3][9] =0.000901000000000000;
 
 

//\ DRAG CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2
DDT.Velcor[1][1] = -0.000108;
DDT.Velcor[1][2] = -0.001917;
DDT.Velcor[1][3] = -0.001571;
DDT.Velcor[1][4] = 0.000016;
DDT.Velcor[1][5] = 0.000008;
DDT.Velcor[1][6] = -0.000011;
DDT.Velcor[1][7] = 0.002992;
DDT.Velcor[1][8] = 0.000512;
DDT.Velcor[1][9] = 0.000120;

DDT.Velcor[2][1] = 0.000364;
DDT.Velcor[2][2] = -0.000232;
DDT.Velcor[2][3] = 0.005453;
DDT.Velcor[2][4] = -0.000018;
DDT.Velcor[2][5] = -0.000006;
DDT.Velcor[2][6] = 0.000039;
DDT.Velcor[2][7] = 0.003067;
DDT.Velcor[2][8] = 0.000772;
DDT.Velcor[2][9] = 0.000005;

DDT.Velcor[3][1] = -0.000260;
DDT.Velcor[3][2] = 0.001300;
DDT.Velcor[3][3] = -0.002104;
DDT.Velcor[3][4] = 0.000005;
DDT.Velcor[3][5] = 0.000000;
DDT.Velcor[3][6] = -0.000029;
DDT.Velcor[3][7] = -0.003422;
DDT.Velcor[3][8] = -0.000955;
DDT.Velcor[3][9] = -0.000144;

DDT.El_to      = -5.1292410E-1;

DDT.Elbas[1] = -6.0862617E-1;
DDT.Elbas[2] = 1.7963415E+0;
DDT.Elbas[3] = -1.3821132E+0;


DDT.Azbas[1] = -6.7353566E-3;
DDT.Azbas[2] = -2.9778759E-2;
DDT.Azbas[3] = 3.4729113E-2;


DDT.Velbas[1] = 4.9068225E-3;
DDT.Velbas[2] = -4.5574613E-3;
DDT.Velbas[3] = -3.3482054E-4;


