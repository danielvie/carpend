//\ ToT C-35 RHAN 122mm Arr. SS-30 +6% - 02/09/15 >> DD122C35_AMB - DDTRHN - 8 Sep 2015
//\    DD122C35_AMB - Emp. Estimado - DDTRHM -  9 Sep 2015
//\ DATA DE MONTAGEM :  09 Set 2015 - 12:15:00    ARQUIVO : 'BDTRHN'

//\ [KG] TOTAL ROCKET MASS
DDT.Mass      = 65.42;
//\ [KG] PROPELLANT MASS
DDT.Propmass  = 28.67;
//\ [M] LAUNCHER LENGHT
DDT.Laul      = 2.91;
//\ [M] REFERENCE DIAMETER OF ROCKET
DDT.Diaref    = 0.1215;
//\ NUMBER OF POINTS IN THRUST PROFILE
DDT.N_points  = 14.0;
//\ [M2] EXAUST AREA
DDT.Ass       = 0.0079801;
//\ [N/M2] REFERENCE PRESSURE
DDT.Pnom      = 94540.0;
//\ [N] REFERENCE THRUST * STEP
DDT.Emp       = 18139.33332; // 4534.83333 * 4;
//\ [DEG] MAXIMUM ELEVATION
DDT.Elevmax   = 60.0;
//\ [M/S] MAXIMUM WIND VELOCITY
DDT.Vwmax     = 15.0;
//\ CORRECTION FACTOR FOR DRAG IN THRUSTPHASE
DDT.Cdadj     = 0.76936;
//\ CORRECTION FACTOR FOR DRAG IN SEC. BAL.
DDT.Cdadjsm   = 1.00;
//\ WEIGHTING FACTOR
DDT.Fpon            = 1.00000;

DDT.T_emp_step[1]   = 0.0;
DDT.T_emp_step[2]   = 1.0;
DDT.T_emp_step[3]   = 2.0;
DDT.T_emp_step[4]   = 5.0;
DDT.T_emp_step[5]   = 7.0;
DDT.T_emp_step[6]   = 10.0;
DDT.T_emp_step[7]   = 12.0;
DDT.T_emp_step[8]   = 13.0;
DDT.T_emp_step[9]   = 14.0;
DDT.T_emp_step[10]  = 16.0;
DDT.T_emp_step[11]  = 19.0;
DDT.T_emp_step[12]  = 20.0;
DDT.T_emp_step[13]  = 22.0;
DDT.T_emp_step[14]  = 23.0;
DDT.T_emp_step[15]  = 0.0;
DDT.T_emp_step[16]  = 0.0;
DDT.T_emp_step[17]  = 0.0;
DDT.T_emp_step[18]  = 0.0;
DDT.T_emp_step[19]  = 0.0;
DDT.T_emp_step[20]  = 0.0;

DDT.P_emp_tp[1][ 1] = 9.370900E-1;
DDT.P_emp_tp[1][ 2] = 8.017330E-1;
DDT.P_emp_tp[1][ 3] = 7.704960E-1;
DDT.P_emp_tp[1][ 4] = 7.809090E-1;
DDT.P_emp_tp[1][ 5] = 8.329690E-1;
DDT.P_emp_tp[1][ 6] = 9.370900E-1;
DDT.P_emp_tp[1][ 7] = 6.247270E-1;
DDT.P_emp_tp[1][ 8] = 5.206060E-1;
DDT.P_emp_tp[1][ 9] = 4.164850E-1;
DDT.P_emp_tp[1][10] = 4.164850E-1;
DDT.P_emp_tp[1][11] = 4.581330E-1;
DDT.P_emp_tp[1][12] = 3.540120E-1;
DDT.P_emp_tp[1][13] = 1.822120E-1;
DDT.P_emp_tp[1][14] = 0.000000E+0;
DDT.P_emp_tp[1][15] = 0.000000E+0;
DDT.P_emp_tp[1][16] = 0.000000E+0;
DDT.P_emp_tp[1][17] = 0.000000E+0;
DDT.P_emp_tp[1][18] = 0.000000E+0;
DDT.P_emp_tp[1][19] = 0.0000000E+0;
DDT.P_emp_tp[1][20] = 0.0000000E+0;

DDT.P_emp_tp[2][ 1] =  4.664070E-4;
DDT.P_emp_tp[2][ 2] =  3.084280E-4;
DDT.P_emp_tp[2][ 3] =  2.820760E-4;
DDT.P_emp_tp[2][ 4] =  2.501720E-4;
DDT.P_emp_tp[2][ 5] =  2.361720E-4;
DDT.P_emp_tp[2][ 6] =  3.804900E-5;
DDT.P_emp_tp[2][ 7] =  1.251850E-4;
DDT.P_emp_tp[2][ 8] =  2.380360E-4;
DDT.P_emp_tp[2][ 9] =  3.508870E-4;
DDT.P_emp_tp[2][10] =  5.765900E-4;
DDT.P_emp_tp[2][11] =  9.151430E-4;
DDT.P_emp_tp[2][12] =  1.027990E-3;
DDT.P_emp_tp[2][13] =  1.253700E-3;
DDT.P_emp_tp[2][14] =  0.000000E+0;
DDT.P_emp_tp[2][15] =  0.000000E+0;
DDT.P_emp_tp[2][16] =  0.000000E+0;
DDT.P_emp_tp[2][17] =  0.000000E+0;
DDT.P_emp_tp[2][18] =  0.000000E+0;
DDT.P_emp_tp[2][19] =  0.0000000E+0;
DDT.P_emp_tp[2][20] =  0.0000000E+0;

DDT.P_emp_tp[3][ 1] =  2.888720E-6;
DDT.P_emp_tp[3][ 2] =  1.266980E-6;
DDT.P_emp_tp[3][ 3] =  4.372550E-7;
DDT.P_emp_tp[3][ 4] = -1.472170E-7;
DDT.P_emp_tp[3][ 5] = -2.546520E-7;
DDT.P_emp_tp[3][ 6] = -1.613770E-6;
DDT.P_emp_tp[3][ 7] =  2.394620E-8;
DDT.P_emp_tp[3][ 8] =  6.045360E-10;
DDT.P_emp_tp[3][ 9] = -2.273710E-8;
DDT.P_emp_tp[3][10] = -6.942030E-8;
DDT.P_emp_tp[3][11] = -1.394450E-7;
DDT.P_emp_tp[3][12] = -1.627870E-7;
DDT.P_emp_tp[3][13] = -2.094700E-7;
DDT.P_emp_tp[3][14] =  0.000000E+0;
DDT.P_emp_tp[3][15] =  0.000000E+0;
DDT.P_emp_tp[3][16] =  0.000000E+0;
DDT.P_emp_tp[3][17] =  0.000000E+0;
DDT.P_emp_tp[3][18] =  0.000000E+0;
DDT.P_emp_tp[3][19] =  0.0000000E+0;
DDT.P_emp_tp[3][20] =  0.0000000E+0;

DDT.P_emp_tp[4][ 1] = 8.303340E-1;
DDT.P_emp_tp[4][ 2] = 7.366920E-1;
DDT.P_emp_tp[4][ 3] = 7.083270E-1;
DDT.P_emp_tp[4][ 4] = 7.206380E-1;
DDT.P_emp_tp[4][ 5] = 7.700170E-1;
DDT.P_emp_tp[4][ 6] = 8.708270E-1;
DDT.P_emp_tp[4][ 7] = 5.795090E-1;
DDT.P_emp_tp[4][ 8] = 5.071020E-1;
DDT.P_emp_tp[4][ 9] = 4.052400E-1;
DDT.P_emp_tp[4][10] = 3.837990E-1;
DDT.P_emp_tp[4][11] = 3.884130E-1;
DDT.P_emp_tp[4][12] = 2.287650E-1;
DDT.P_emp_tp[4][13] = 8.657840E-2;
DDT.P_emp_tp[4][14] = 0.000000E+0;
DDT.P_emp_tp[4][15] = 0.000000E+0;
DDT.P_emp_tp[4][16] = 0.000000E+0;
DDT.P_emp_tp[4][17] = 0.000000E+0;
DDT.P_emp_tp[4][18] = 0.000000E+0;
DDT.P_emp_tp[4][19] = 0.0000000E+0;
DDT.P_emp_tp[4][20] = 0.0000000E+0;

DDT.P_emp_tp[5][1] = 1.049130E+0;
DDT.P_emp_tp[5][2] = 8.625120E-1;
DDT.P_emp_tp[5][3] = 8.211030E-1;
DDT.P_emp_tp[5][4] = 8.249010E-1;
DDT.P_emp_tp[5][5] = 8.785770E-1;
DDT.P_emp_tp[5][6] = 9.829570E-1;
DDT.P_emp_tp[5][7] = 6.479530E-1;
DDT.P_emp_tp[5][8] = 5.230206E-1;
DDT.P_emp_tp[5][9] = 4.200430E-1;
DDT.P_emp_tp[5][10] = 4.318190E-1;
DDT.P_emp_tp[5][11] = 4.995410E-1;
DDT.P_emp_tp[5][12] = 4.444280E-1;
DDT.P_emp_tp[5][13] = 3.427230E-1;
DDT.P_emp_tp[5][14] = 0.000000E+0;
DDT.P_emp_tp[5][15] = 0.000000E+0;
DDT.P_emp_tp[5][16] = 0.000000E+0;
DDT.P_emp_tp[5][17] = 0.000000E+0;
DDT.P_emp_tp[5][18] = 0.000000E+0;
DDT.P_emp_tp[5][19] = 0.0000000E+0;
DDT.P_emp_tp[5][20] = 0.0000000E+0;

//\ F(ELEV.)
DDT.V0_el[1]   =  3.75511E+1;
DDT.V0_el[2]   = -8.574014E-1;
DDT.V0_el[3]   =  9.447341E-1;

//\ F(PROP. TEMP.)
DDT.V0_tp[1]   = 1.0000000E+0;
DDT.V0_tp[2]   = 2.425567E-4;
DDT.V0_tp[3]   = 1.224372E-6;

//\ F(ELEV.)
DDT.T0_el[1]   = 1.504492E-1;
DDT.T0_el[2]   = 3.326062E-3;
DDT.T0_el[3]   = -1.763504E-3;

//\ F(PROP. TEMP.)
DDT.T0_tp[1]   = 1.0000000E+0;
DDT.T0_tp[2]   = -2.3303790E-4;
DDT.T0_tp[3]   = -1.172020E-6;

//\ [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec1[1]  = 0.0000000E+0;
DDT.Hejec1[2]  = 0.0000000E+0;
DDT.Hejec1[3]  = 0.0000000E+0;
DDT.Hejec1[4]  = 0.0000000E+0;
DDT.Hejec1[5]  = 0.0000000E+0;

//\ [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec1[1]  = 0.0000000E+0;
DDT.Hejec1[2]  = 0.0000000E+0;
DDT.Hejec1[3]  = 0.0000000E+0;
DDT.Hejec1[4]  = 0.0000000E+0;
DDT.Hejec1[5]  = 0.0000000E+0;

//\ [SEC] DELAY OF EJECTION
DDT.Delta_ejec = 0.000;

//\ WIND WEIGHTING POLYNOM
DDT.Bwiwe[1]   =    45.9419;
DDT.Bwiwe[2]   =  -429.9806;
DDT.Bwiwe[3]   =  1416.5463;
DDT.Bwiwe[4]   = -2301.0594;
DDT.Bwiwe[5]   =  1826.9238;
DDT.Bwiwe[6]   =   -565.964;

//\ HEIGHT OF END OF THRUSTPHASE
DDT.Hmthph[1] = -2.97202E+2;
DDT.Hmthph[2] = 2.39196446E+3;
DDT.Hmthph[3] = -4.97533986E+2;
DDT.Hmthph[4] = 0.0000E+0;

DDT.Cwss[ 0]  = 0.41258;
DDT.Cwss[ 1]  = 0.41257;
DDT.Cwss[ 2]  = 0.41256;
DDT.Cwss[ 3]  = 0.41263;
DDT.Cwss[ 4]  = 0.41261;
DDT.Cwss[ 5]  = 0.41258;
DDT.Cwss[ 6]  = 0.41262;
DDT.Cwss[ 7]  = 0.41259;
DDT.Cwss[ 8]  = 0.41262;
DDT.Cwss[ 9]  = 0.50414;
DDT.Cwss[10]  = 0.62382;
DDT.Cwss[11]  = 0.63653;
DDT.Cwss[12]  = 0.63437;
DDT.Cwss[13]  = 0.62680;
DDT.Cwss[14]  = 0.61590;
DDT.Cwss[15]  = 0.60819;
DDT.Cwss[16]  = 0.59517;
DDT.Cwss[17]  = 0.58423;
DDT.Cwss[18]  = 0.57330;
DDT.Cwss[19]  = 0.56134;
DDT.Cwss[20]  = 0.55253;
DDT.Cwss[21]  = 0.54054;
DDT.Cwss[22]  = 0.53004;
DDT.Cwss[23]  = 0.52116;
DDT.Cwss[24]  = 0.51110;
DDT.Cwss[25]  = 0.50006;
DDT.Cwss[26]  = 0.49131;
DDT.Cwss[27]  = 0.48148;
DDT.Cwss[28]  = 0.47273;
DDT.Cwss[29]  = 0.46177;
DDT.Cwss[30]  = 0.45411;
DDT.Cwss[31]  = 0.44537;
DDT.Cwss[32]  = 0.43662;
DDT.Cwss[33]  = 0.42997;
DDT.Cwss[34]  = 0.42126;
DDT.Cwss[35]  = 0.41576;
DDT.Cwss[36]  = 0.40917;
DDT.Cwss[37]  = 0.40370;
DDT.Cwss[38]  = 0.39933;
DDT.Cwss[39]  = 0.39386;
DDT.Cwss[40]  = 0.38840;

//\ [MILS] MAX. TACTICAL ELEVATION
DDT.Elev_tat = 1050.0;

//\ [MILS] MIN. TACTICAL ELEVATION
DDT.Elev_min = 110.0;

//\ [MILS]  F                       {<<<5.2}
// DDT.IDENT_ELEV_1 = 300.0;

//\ [MILS]  F                       {<<<5.2}
// DDT.IDENT_ELEV_2 =   0.0;

//\ FLIGHT_TIME/ FUZE_TIME (low ejection)
DDT.Fuzecor1[1] = 1.0000000E+0;
DDT.Fuzecor1[2] = 0.0000000E+0;
DDT.Fuzecor1[3] = 0.0000000E+0;

//\ FLIGHT_TIME/ FUZE_TIME (high ejection)
DDT.Fuzecor2[1] = 1.0000000E+0;
DDT.Fuzecor2[2] = 0.0000000E+0;
DDT.Fuzecor2[3] = 0.0000000E+0;

//\ ELEVATION CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2

DDT.Elcor[1][1] = -5.470707E-5;
DDT.Elcor[1][2] = -1.614529E-3;
DDT.Elcor[1][3] = -8.237703E-5;
DDT.Elcor[1][4] =  1.534036E-5;
DDT.Elcor[1][5] = -3.254360E-5;
DDT.Elcor[1][6] =  2.648867E-5;
DDT.Elcor[1][7] =  1.210949E-4;
DDT.Elcor[1][8] =  9.877378E-5;
DDT.Elcor[1][9] = -6.879526E-5;

DDT.Elcor[2][1] =  2.211396E-4;
DDT.Elcor[2][2] =  1.975667E-2;
DDT.Elcor[2][3] =  1.259411E-3;
DDT.Elcor[2][4] =  1.610032E-4;
DDT.Elcor[2][5] =  1.276000E-4;
DDT.Elcor[2][6] = -5.726780E-5;
DDT.Elcor[2][7] = -8.082836E-4;
DDT.Elcor[2][8] =  1.775127E-4;
DDT.Elcor[2][9] =  1.991600E-4;

DDT.Elcor[3][1] = -1.635494E-4;
DDT.Elcor[3][2] = -1.193772E-2;
DDT.Elcor[3][3] = -9.282408E-4;
DDT.Elcor[3][4] = -1.316821E-4;
DDT.Elcor[3][5] = -8.745210E-5;
DDT.Elcor[3][6] =  2.907086E-5;
DDT.Elcor[3][7] =  1.999516E-4;
DDT.Elcor[3][8] = -2.571778E-4;
DDT.Elcor[3][9] = -1.549879E-4;

//\ AZIMUTH CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2

DDT.Azcor[1][1] = -1.619146E-5;
DDT.Azcor[1][2] = -2.618838E-5;
DDT.Azcor[1][3] = 1.092855E-5;
DDT.Azcor[1][4] = -1.354503E-2;
DDT.Azcor[1][5] = -1.049223E-3;
DDT.Azcor[1][6] = -4.353877E-5;
DDT.Azcor[1][7] = -1.660589E-5;
DDT.Azcor[1][8] = 8.440290E-6;
DDT.Azcor[1][9] = 9.251328E-7;

DDT.Azcor[2][1] = 1.869225E-5;
DDT.Azcor[2][2] = 8.640467E-5;
DDT.Azcor[2][3] = -8.078643E-5;
DDT.Azcor[2][4] = -5.863808E-4;
DDT.Azcor[2][5] = 1.003457E-3;
DDT.Azcor[2][6] = 9.495569E-5;
DDT.Azcor[2][7] = -1.040265E-6;
DDT.Azcor[2][8] = 8.888460E-6;
DDT.Azcor[2][9] = 5.868875E-5;

DDT.Azcor[3][1] = -1.470118E-5;
DDT.Azcor[3][2] = 6.440446E-6;
DDT.Azcor[3][3] = 8.283997E-5;
DDT.Azcor[3][4] = 4.277324E-4;
DDT.Azcor[3][5] = -2.028737E-3;
DDT.Azcor[3][6] = -5.305923E-4;
DDT.Azcor[3][7] = 2.678120E-6;
DDT.Azcor[3][8] = -2.967664E-5;
DDT.Azcor[3][9] = -5.933034E-5;

//\ DRAG CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2

DDT.Velcor[1][1] =  1.792317E-6;
DDT.Velcor[1][2] = -2.142703E-3;
DDT.Velcor[1][3] = -4.020050E-4;
DDT.Velcor[1][4] =  2.335567E-5;
DDT.Velcor[1][5] =  3.117234E-6;
DDT.Velcor[1][6] = -7.852799E-6;
DDT.Velcor[1][7] =  3.163302E-3;
DDT.Velcor[1][8] =  4.449362E-4;
DDT.Velcor[1][9] =  6.067842E-6;

DDT.Velcor[2][1] = -1.973623E-5;
DDT.Velcor[2][2] = 4.875163E-4;
DDT.Velcor[2][3] = 2.736462E-3;
DDT.Velcor[2][4] = -4.272315E-5;
DDT.Velcor[2][5] = 3.929367E-6;
DDT.Velcor[2][6] = 1.600749E-5;
DDT.Velcor[2][7] = 1.493512E-3;
DDT.Velcor[2][8] = 3.351702E-4;
DDT.Velcor[2][9] = -1.359481E-5;

DDT.Velcor[3][1] = -3.901375E-6;
DDT.Velcor[3][2] = 9.605779E-4;
DDT.Velcor[3][3] = -7.624478E-4;
DDT.Velcor[3][4] = 2.295593E-5;
DDT.Velcor[3][5] = -5.536903E-6;
DDT.Velcor[3][6] = -7.113417E-6;
DDT.Velcor[3][7] = -2.287467E-3;
DDT.Velcor[3][8] = -5.373229E-4;
DDT.Velcor[3][9] =  2.664714E-5;

DDT.El_to        = -2.9282760E-1 ;

DDT.Elbas[1]     = -4.8306494E-1;
DDT.Elbas[2]     =  1.0178916E+0;
DDT.Elbas[3]     = -6.5691510E-1;

DDT.Azbas[1]     = -1.1327421E-2;
DDT.Azbas[2]     = -7.4810104E-3;
DDT.Azbas[3]     =  1.8293652E-2;

DDT.Velbas[1]    = -7.6988114E-4;
DDT.Velbas[2]    =  9.3580342E-4;
DDT.Velbas[3]    = -2.8090350E-4;
