// SS-60 Car. Bal. BDT6c4 baseado 'DD6C-8' c/ Cd da Sub-municao 70 M12
//    D6C-81 - 6CC�12 - DDT6C4 - 20 Jan 1988
// DATA DE MONTAGEM :  02 Feb 1988 - 09:51:30    ARQUIVO : 'BDT6C5'
//
// REVISADO EM JANEIRO DE 2005:
//       - MAX-T-EL (Elevacao tatica maxima) alterado para 1000 mils
//
// [KG] TOTAL ROCKET MASS
DDT.Mass       = 574.30;
// [KG] PROPELLANT MASS
DDT.Propmass   = 253.00;
// [M] LAUNCHER LENGHT
DDT.Laul       = 5.42;
// [M] REFERENCE DIAMETER OF ROCKET
DDT.Diaref     = 0.3000;
// NUMBER OF POINTS IN THRUST PROFILE
DDT.N_points   = 19.0;
// [M2] EXAUST AREA
DDT.Ass        = 0.042829;
// [N/M2] REFERENCE PRESSURE
DDT.Pnom       = 94540.0;
// [N] REFERENCE THRUST * STEP
DDT.Emp        = 20000.00 * 4;
// [DEG] MAXIMUM ELEVATION
DDT.Elevmax    = 63.0;
// [M/S] MAXIMUM WIND VELOCITY
DDT.Vwmax      = 15.0;
// CORRECTION FACTOR FOR DRAG IN THRUSTPHASE
DDT.Cdadj      = 0.68542;
// CORRECTION FACTOR FOR DRAG IN SEC. BAL.
DDT.Cdadjsm    = 35.70;
// WEIGHTING FACTOR
DDT.Fpon       = 1.00000;

DDT.T_emp_step[ 1] = 0.0;
DDT.T_emp_step[ 2] = 1.0;
DDT.T_emp_step[ 3] = 2.0;
DDT.T_emp_step[ 4] = 3.0;
DDT.T_emp_step[ 5] = 4.0;
DDT.T_emp_step[ 6] = 5.0;
DDT.T_emp_step[ 7] = 6.0;
DDT.T_emp_step[ 8] = 7.0;
DDT.T_emp_step[ 9] = 8.0;
DDT.T_emp_step[10] = 9.0;
DDT.T_emp_step[11] = 18.0;
DDT.T_emp_step[12] = 25.0;
DDT.T_emp_step[13] = 28.0;
DDT.T_emp_step[14] = 30.0;
DDT.T_emp_step[15] = 32.0;
DDT.T_emp_step[16] = 34.0;
DDT.T_emp_step[17] = 37.0;
DDT.T_emp_step[18] = 40.0;
DDT.T_emp_step[19] = 42.0;
DDT.T_emp_step[20] = 0.0;


DDT.P_emp_tp[1][ 1] = 7.5397850E-1;
DDT.P_emp_tp[1][ 2] = 8.7089504E-1;
DDT.P_emp_tp[1][ 3] = 8.5824178E-1;
DDT.P_emp_tp[1][ 4] = 8.5459279E-1;
DDT.P_emp_tp[1][ 5] = 8.5087739E-1;
DDT.P_emp_tp[1][ 6] = 8.5097266E-1;
DDT.P_emp_tp[1][ 7] = 8.4985324E-1;
DDT.P_emp_tp[1][ 8] = 8.5516714E-1;
DDT.P_emp_tp[1][ 9] = 8.5844986E-1;
DDT.P_emp_tp[1][10] = 8.6805295E-1;
DDT.P_emp_tp[1][11] = 9.1558100E-1;
DDT.P_emp_tp[1][12] = 8.9721248E-1;
DDT.P_emp_tp[1][13] = 8.4224541E-1;
DDT.P_emp_tp[1][14] = 7.1201651E-1;
DDT.P_emp_tp[1][15] = 4.2746167E-1;
DDT.P_emp_tp[1][16] = 2.2794613E-1;
DDT.P_emp_tp[1][17] = 1.1646043E-1;
DDT.P_emp_tp[1][18] = 5.0792631E-2;
DDT.P_emp_tp[1][19] = 0.0000000E+0;
DDT.P_emp_tp[1][20] = 0.0000000E+0;

DDT.P_emp_tp[2][ 1] = 4.8779637E-4;
DDT.P_emp_tp[2][ 2] = 2.1358660E-3;
DDT.P_emp_tp[2][ 3] = 2.0782430E-3;
DDT.P_emp_tp[2][ 4] = 2.0358787E-3;
DDT.P_emp_tp[2][ 5] = 1.9029460E-3;
DDT.P_emp_tp[2][ 6] = 2.0216599E-3;
DDT.P_emp_tp[2][ 7] = 1.9938610E-3;
DDT.P_emp_tp[2][ 8] = 2.1473366E-3;
DDT.P_emp_tp[2][ 9] = 2.1416768E-3;
DDT.P_emp_tp[2][10] = 2.2705853E-3;
DDT.P_emp_tp[2][11] = 2.0256178E-3;
DDT.P_emp_tp[2][12] = 1.5257274E-3;
DDT.P_emp_tp[2][13] = -3.9635720E-4;
DDT.P_emp_tp[2][14] = -5.4373666E-3;
DDT.P_emp_tp[2][15] = -1.1594113E-2;
DDT.P_emp_tp[2][16] = -1.4553185E-2;
DDT.P_emp_tp[2][17] = -1.8670951E-2;
DDT.P_emp_tp[2][18] = -2.5118041E-2;
DDT.P_emp_tp[2][19] = 0.0000000E+0;
DDT.P_emp_tp[2][20] = 0.0000000E+0;

DDT.P_emp_tp[3][ 1] = -1.1793227E-5;
DDT.P_emp_tp[3][ 2] = 5.7030906E-6;
DDT.P_emp_tp[3][ 3] = 5.6116135E-6;
DDT.P_emp_tp[3][ 4] = 5.3092065E-6;
DDT.P_emp_tp[3][ 5] = 3.4720509E-6;
DDT.P_emp_tp[3][ 6] = 4.5184047E-6;
DDT.P_emp_tp[3][ 7] = 4.4601227E-6;
DDT.P_emp_tp[3][ 8] = 5.6818446E-6;
DDT.P_emp_tp[3][ 9] = 5.8895073E-6;
DDT.P_emp_tp[3][10] = 6.7926081E-6;
DDT.P_emp_tp[3][11] = 6.9822695E-6;
DDT.P_emp_tp[3][12] = 5.7333694E-6;
DDT.P_emp_tp[3][13] = -8.1383030E-6;
DDT.P_emp_tp[3][14] = -5.0110742E-5;
DDT.P_emp_tp[3][15] = -9.5966076E-6;
DDT.P_emp_tp[3][16] = 2.8751891E-5;
DDT.P_emp_tp[3][17] = 2.5040716E-5;
DDT.P_emp_tp[3][18] = 1.2394174E-4;
DDT.P_emp_tp[3][19] = 0.0000000E+0;
DDT.P_emp_tp[3][20] = 0.0000000E+0;

DDT.P_emp_tp[4][ 1] = 6.9990060E-1;
DDT.P_emp_tp[4][ 2] = 7.7716859E-1;
DDT.P_emp_tp[4][ 3] = 7.6856172E-1;
DDT.P_emp_tp[4][ 4] = 7.6653591E-1;
DDT.P_emp_tp[4][ 5] = 7.6436240E-1;
DDT.P_emp_tp[4][ 6] = 7.6159216E-1;
DDT.P_emp_tp[4][ 7] = 7.6182951E-1;
DDT.P_emp_tp[4][ 8] = 7.6247938E-1;
DDT.P_emp_tp[4][ 9] = 7.6633957E-1;
DDT.P_emp_tp[4][10] = 7.7102049E-1;
DDT.P_emp_tp[4][11] = 8.2731817E-1;
DDT.P_emp_tp[4][12] = 8.3359696E-1;
DDT.P_emp_tp[4][13] = 8.1334280E-1;
DDT.P_emp_tp[4][14] = 4.6554790E-1;
DDT.P_emp_tp[4][15] = 1.9613300E-1;
DDT.P_emp_tp[4][16] = 9.1937344E-2;
DDT.P_emp_tp[4][17] = 2.4516625E-2;
DDT.P_emp_tp[4][18] = 6.1291563E-3;
DDT.P_emp_tp[4][19] = 0.0000000E+0;
DDT.P_emp_tp[4][20] = 0.0000000E+0;

DDT.P_emp_tp[5][ 1] = 7.5397850E-1;
DDT.P_emp_tp[5][ 2] = 9.6465798E-1;
DDT.P_emp_tp[5][ 3] = 9.4825800E-1;
DDT.P_emp_tp[5][ 4] = 9.4207377E-1;
DDT.P_emp_tp[5][ 5] = 9.2972264E-1;
DDT.P_emp_tp[5][ 6] = 9.3617585E-1;
DDT.P_emp_tp[5][ 7] = 9.3378092E-1;
DDT.P_emp_tp[5][ 8] = 9.4764139E-1;
DDT.P_emp_tp[5][ 9] = 9.5142144E-1;
DDT.P_emp_tp[5][10] = 9.6868752E-1;
DDT.P_emp_tp[5][11] = 1.0119843E+0;
DDT.P_emp_tp[5][12] = 9.6922976E-1;
DDT.P_emp_tp[5][13] = 8.4224541E-1;
DDT.P_emp_tp[5][14] = 8.1585937E-1;
DDT.P_emp_tp[5][15] = 7.1005616E-1;
DDT.P_emp_tp[5][16] = 4.5058063E-1;
DDT.P_emp_tp[5][17] = 2.5742456E-1;
DDT.P_emp_tp[5][18] = 1.5000449E-1;
DDT.P_emp_tp[5][19] = 0.0000000E+0;
DDT.P_emp_tp[5][20] = 0.0000000E+0;


// F(ELEV.)
DDT.V0_el[1] = 3.5219871E+1;
DDT.V0_el[2] = -2.0157835E+0;
DDT.V0_el[3] = 9.8678088E-1;


// F(PROP. TEMP.)
DDT.V0_tp[1] = 1.0000000E+0;
DDT.V0_tp[2] = 9.5477500E-4;
DDT.V0_tp[3] = 8.4619948E-7;


// F(ELEV.)
DDT.T0_el[1] = 3.1639508E-1;
DDT.T0_el[2] = 1.9116005E-2;
DDT.T0_el[3] = -9.0611972E-3;


// F(PROP. TEMP.)
DDT.T0_tp[1] = 1.0000000E+0;
DDT.T0_tp[2] = -6.3994358E-4;
DDT.T0_tp[3] = 2.8414791E-6;


// [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec1[1] = 1.0000000E+3;
DDT.Hejec1[2] = 4.0000000E+1;
DDT.Hejec1[3] = 0.0000000E+0;
DDT.Hejec1[4] = 2.0000000E+3;
DDT.Hejec1[5] = 3.0000000E+3;


// [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec2[1] = 3.0000000E+3;
DDT.Hejec2[2] = 0.0000000E+0;
DDT.Hejec2[3] = 0.0000000E+0;
DDT.Hejec2[4] = 3.0000000E+3;
DDT.Hejec2[5] = 3.0000000E+3;


// [SEC] DELAY OF EJECTION
DDT.Delta_ejec = 0.100;

// WIND WEIGHTING POLYNOM

DDT.Bwiwe[1] =    67.4237; //  6.7424E+1
DDT.Bwiwe[2] =  -511.490599996; // -5.1149E+2
DDT.Bwiwe[3] =  1429.78119999; //  1.4298E+3
DDT.Bwiwe[4] = -2014.98009996; // -2.0150E+3
DDT.Bwiwe[5] =  1417.4671; //  1.4175E+3
DDT.Bwiwe[6] =  -397.4118; // -3.9741E+2


// HEIGHT OF END OF THRUSTPHASE
DDT.Hmthph[1] = -1.2290E+3;
DDT.Hmthph[2] = 5.8185E+3;
DDT.Hmthph[3] = -1.4897E+3;
DDT.Hmthph[4] = 0.0000E+0;


DDT.Cwss[ 0] = 0.49175;
DDT.Cwss[ 1] = 0.49175;
DDT.Cwss[ 2] = 0.49175;
DDT.Cwss[ 3] = 0.49175;
DDT.Cwss[ 4] = 0.49175;
DDT.Cwss[ 5] = 0.49175;
DDT.Cwss[ 6] = 0.49175;
DDT.Cwss[ 7] = 0.49175;
DDT.Cwss[ 8] = 0.49332;
DDT.Cwss[ 9] = 0.51121;
DDT.Cwss[10] = 0.59802;
DDT.Cwss[11] = 0.69241;
DDT.Cwss[12] = 0.70682;
DDT.Cwss[13] = 0.69361;
DDT.Cwss[14] = 0.67350;
DDT.Cwss[15] = 0.65561;
DDT.Cwss[16] = 0.63657;
DDT.Cwss[17] = 0.61589;
DDT.Cwss[18] = 0.59593;
DDT.Cwss[19] = 0.58010;
DDT.Cwss[20] = 0.56388;
DDT.Cwss[21] = 0.54871;
DDT.Cwss[22] = 0.53583;
DDT.Cwss[23] = 0.52164;
DDT.Cwss[24] = 0.50762;
DDT.Cwss[25] = 0.49592;
DDT.Cwss[26] = 0.48475;
DDT.Cwss[27] = 0.47226;
DDT.Cwss[28] = 0.46158;
DDT.Cwss[29] = 0.44869;
DDT.Cwss[30] = 0.43561;
DDT.Cwss[31] = 0.42450;
DDT.Cwss[32] = 0.41441;
DDT.Cwss[33] = 0.40486;
DDT.Cwss[34] = 0.39527;
DDT.Cwss[35] = 0.38554;
DDT.Cwss[36] = 0.37658;
DDT.Cwss[37] = 0.36671;
DDT.Cwss[38] = 0.35812;
DDT.Cwss[39] = 0.34887;
DDT.Cwss[40] = 0.34031;

// [MILS] MAX. TACTICAL ELEVATION
DDT.Elev_tat   = 1000.0;
// [MILS] MIN. TACTICAL ELEVATION
DDT.Elev_min   = 350.0;
// [MILS]  F                       {<<<5.2}
// [MILS]  F                       {<<<5.2}

// FLIGHT_TIME/ FUZE_TIME (low ejection)
DDT.Fuzecor1[1] = 1.3440000E+0;
DDT.Fuzecor1[2] = -1.1680000E-2;
DDT.Fuzecor1[3] = 1.0410000E-4;

// FLIGHT_TIME/ FUZE_TIME (high ejection)
DDT.Fuzecor2[1] = 1.9670000E+0;
DDT.Fuzecor2[2] = -3.1050000E-2;
DDT.Fuzecor2[3] = 2.6190000E-4;

// ELEVATION CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2
DDT.Elcor[1][1] = -0.000011;
DDT.Elcor[1][2] = -0.006129;
DDT.Elcor[1][3] = -0.000354;
DDT.Elcor[1][4] = -0.000354;
DDT.Elcor[1][5] = -0.000110;
DDT.Elcor[1][6] = -0.000016;
DDT.Elcor[1][7] = 0.000300;
DDT.Elcor[1][8] = -0.000117;
DDT.Elcor[1][9] = -0.000092;

DDT.Elcor[2][1] = 0.000039;
DDT.Elcor[2][2] = 0.040337;
DDT.Elcor[2][3] = 0.002971;
DDT.Elcor[2][4] = 0.000001;
DDT.Elcor[2][5] = 0.000059;
DDT.Elcor[2][6] = -0.000038;
DDT.Elcor[2][7] = -0.002327;
DDT.Elcor[2][8] = 0.000657;
DDT.Elcor[2][9] = 0.000735;

DDT.Elcor[3][1] = -0.000050;
DDT.Elcor[3][2] = -0.025840;
DDT.Elcor[3][3] = -0.002244;
DDT.Elcor[3][4] = 0.000178;
DDT.Elcor[3][5] = -0.00001;
DDT.Elcor[3][6] = 0.000034;
DDT.Elcor[3][7] = 0.000810;
DDT.Elcor[3][8] = -0.000865;
DDT.Elcor[3][9] = -0.000722;


// AZIMUTH CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2
DDT.Azcor[1][1] = 0.000039;
DDT.Azcor[1][2] = 0.000305;
DDT.Azcor[1][3] = 0.000217;
DDT.Azcor[1][4] = -0.020766;
DDT.Azcor[1][5] = -0.003782;
DDT.Azcor[1][6] = -0.001513;
DDT.Azcor[1][7] = 0.000283;
DDT.Azcor[1][8] = -0.000097;
DDT.Azcor[1][9] = -0.000305;

DDT.Azcor[2][1] = 0.000567;
DDT.Azcor[2][2] = -0.000946;
DDT.Azcor[2][3] = -0.000408;
DDT.Azcor[2][4] = -0.003244;
DDT.Azcor[2][5] = 0.007092;
DDT.Azcor[2][6] = 0.004851;
DDT.Azcor[2][7] = -0.000433;
DDT.Azcor[2][8] = 0.000246;
DDT.Azcor[2][9] = 0.000536;

DDT.Azcor[3][1] = -0.000473;
DDT.Azcor[3][2] = 0.000295;
DDT.Azcor[3][3] = 0.000124;
DDT.Azcor[3][4] = 0.003303;
DDT.Azcor[3][5] = -0.008981;
DDT.Azcor[3][6] = -0.005042;
DDT.Azcor[3][7] = 0.000291;
DDT.Azcor[3][8] = -0.000057;
DDT.Azcor[3][9] = -0.000221;


// DRAG CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2
DDT.Velcor[1][1] = 0.000059;
DDT.Velcor[1][2] = 0.004720;
DDT.Velcor[1][3] = -0.001239;
DDT.Velcor[1][4] = -0.000045;
DDT.Velcor[1][5] = -0.000069;
DDT.Velcor[1][6] = -0.000002;
DDT.Velcor[1][7] = 0.002762;
DDT.Velcor[1][8] = 0.000386;
DDT.Velcor[1][9] = 0.000129;

DDT.Velcor[2][1] = -0.000095;
DDT.Velcor[2][2] = -0.009055;
DDT.Velcor[2][3] = 0.004084;
DDT.Velcor[2][4] = -0.000058;
DDT.Velcor[2][5] = 0.000092;
DDT.Velcor[2][6] = -0.000011;
DDT.Velcor[2][7] = 0.006869;
DDT.Velcor[2][8] = 0.002590;
DDT.Velcor[2][9] = 0.000135;

DDT.Velcor[3][1] = 0.000045;
DDT.Velcor[3][2] = 0.003981;
DDT.Velcor[3][3] = -0.000401;
DDT.Velcor[3][4] = 0.000084;
DDT.Velcor[3][5] = -0.000022;
DDT.Velcor[3][6] = 0.000010;
DDT.Velcor[3][7] = -0.006030;
DDT.Velcor[3][8] = -0.002345;
DDT.Velcor[3][9] = -0.000278;


DDT.El_to      = -1.2520776E+0;

DDT.Elbas[1] = -1.1434805E+0;
DDT.Elbas[2] = 2.2558532E+0;
DDT.Elbas[3] = -7.2954889E-1;


DDT.Azbas[1] = 1.6243023E-1;
DDT.Azbas[2] = -3.4334637E-1;
DDT.Azbas[3] = 8.8998594E-2;


DDT.Velbas[1] = 7.6688916E-3;
DDT.Velbas[2] = -1.4781290E-2;
DDT.Velbas[3] = 7.1237865E-3;
DDT.Velbas[3] = 7.1237865E-3;


