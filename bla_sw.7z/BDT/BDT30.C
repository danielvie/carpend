// SS-30 P/ Tab.Tiro II (Emp. 7/4/86, Cdmedio(AR30M) 20/03/86 - Tp=25*C) - 7/4/86
//    D30-31 - ExT301 - DDT301 -  9 Apr 1986
// DATA DE MONTAGEM :  29 Out 1987 - 18:53:12    ARQUIVO : 'BDT303'
//
// REVISADO EM JANEIRO DE 2005:
//       - MIN-T-EL (Elevacao tatica minima) alterado para  125 mils
//
// [KG] TOTAL ROCKET MASS
DDT.Mass       = 68.30;
// [KG] PROPELLANT MASS
DDT.Propmass   = 29.17; // mudado de 29.16 ***
// [M] LAUNCHER LENGHT
DDT.Laul       = 5.42;
// [M] REFERENCE DIAMETER OF ROCKET
DDT.Diaref     = 0.1265;
// NUMBER OF POINTS IN THRUST PROFILE
DDT.N_points   = 18.0;
// [M2] EXAUST AREA
DDT.Ass        = 0.011310;
// [N/M2] REFERENCE PRESSURE
DDT.Pnom       = 94540.0;
// [N] REFERENCE THRUST * STEP
DDT.Emp        = 35000; // 8750.00 * 4; que porra eh essa? ***
// [DEG] MAXIMUM ELEVATION
DDT.Elevmax    = 57.0;
// [M/S] MAXIMUM WIND VELOCITY
DDT.Vwmax      = 15.0;
// CORRECTION FACTOR FOR DRAG IN THRUSTPHASE
DDT.Cdadj      = 0.76936;
// CORRECTION FACTOR FOR DRAG IN SEC. BAL.
DDT.Cdadjsm    = 1.00;
// WEIGHTING FACTOR
DDT.Fpon       = 1.00000;

DDT.T_emp_step[ 1] =  0.0;
DDT.T_emp_step[ 2] =  1.0;
DDT.T_emp_step[ 3] =  2.0;
DDT.T_emp_step[ 4] =  4.0;
DDT.T_emp_step[ 5] =  6.0;
DDT.T_emp_step[ 6] =  8.0;
DDT.T_emp_step[ 7] =  9.0;
DDT.T_emp_step[ 8] = 10.0;
DDT.T_emp_step[ 9] = 11.0;
DDT.T_emp_step[10] = 12.0;
DDT.T_emp_step[11] = 13.0;
DDT.T_emp_step[12] = 14.0;
DDT.T_emp_step[13] = 15.0;
DDT.T_emp_step[14] = 16.0;
DDT.T_emp_step[15] = 17.0;
DDT.T_emp_step[16] = 18.0;
DDT.T_emp_step[17] = 19.0;
DDT.T_emp_step[18] = 20.0;
DDT.T_emp_step[19] =  0.0;
DDT.T_emp_step[20] =  0.0; // conferido

DDT.P_emp_tp[1][ 1] = 7.3255392E-1;
DDT.P_emp_tp[1][ 2] = 6.4157866E-1;
DDT.P_emp_tp[1][ 3] = 6.0585039E-1;
DDT.P_emp_tp[1][ 4] = 5.7918779E-1;
DDT.P_emp_tp[1][ 5] = 5.6860432E-1;
DDT.P_emp_tp[1][ 6] = 5.6066643E-1;
DDT.P_emp_tp[1][ 7] = 5.5536847E-1;
DDT.P_emp_tp[1][ 8] = 5.2257017E-1;
DDT.P_emp_tp[1][ 9] = 4.6601805E-1;
DDT.P_emp_tp[1][10] = 3.9929857E-1;
DDT.P_emp_tp[1][11] = 3.1961179E-1;
DDT.P_emp_tp[1][12] = 2.2384896E-1;
DDT.P_emp_tp[1][13] = 1.1125004E-1;
DDT.P_emp_tp[1][14] = 4.6693928E-2;
DDT.P_emp_tp[1][15] = 2.7161254E-2;
DDT.P_emp_tp[1][16] = 1.5894398E-2;
DDT.P_emp_tp[1][17] = 9.5275111E-3;
DDT.P_emp_tp[1][18] = 0.0000000E+0;
DDT.P_emp_tp[1][19] = 0.0000000E+0;
DDT.P_emp_tp[1][20] = 0.0000000E+0;

DDT.P_emp_tp[2][ 1] =  2.3320359E-3;
DDT.P_emp_tp[2][ 2] =  1.5421375E-3;
DDT.P_emp_tp[2][ 3] =  1.4103795E-3;
DDT.P_emp_tp[2][ 4] =  1.2666554E-3;
DDT.P_emp_tp[2][ 5] =  1.2351078E-3;
DDT.P_emp_tp[2][ 6] =  1.1266143E-3;
DDT.P_emp_tp[2][ 7] =  9.8911007E-4;
DDT.P_emp_tp[2][ 8] =  1.9024510E-4;
DDT.P_emp_tp[2][ 9] = -3.4897486E-4;
DDT.P_emp_tp[2][10] = -1.1852659E-3;
DDT.P_emp_tp[2][11] = -2.5780663E-3;
DDT.P_emp_tp[2][12] = -6.3169219E-3;
DDT.P_emp_tp[2][13] = -1.2956882E-2;
DDT.P_emp_tp[2][14] = -1.6693556E-2;
DDT.P_emp_tp[2][15] = -1.3587725E-2;
DDT.P_emp_tp[2][16] = -1.2063435E-2;
DDT.P_emp_tp[2][17] = -1.7844403E-2;
DDT.P_emp_tp[2][18] =  0.0000000E+0;
DDT.P_emp_tp[2][19] =  0.0000000E+0;
DDT.P_emp_tp[2][20] =  0.0000000E+0;

DDT.P_emp_tp[3][ 1] =  7.2218009E-6;
DDT.P_emp_tp[3][ 2] =  3.1674491E-6;
DDT.P_emp_tp[3][ 3] =  1.0931382E-6;
DDT.P_emp_tp[3][ 4] = -3.2797269E-7;
DDT.P_emp_tp[3][ 5] = -4.0811192E-7;
DDT.P_emp_tp[3][ 6] = -8.6514678E-7;
DDT.P_emp_tp[3][ 7] = -3.6205075E-6;
DDT.P_emp_tp[3][ 8] = -4.0344209E-6;
DDT.P_emp_tp[3][ 9] = -5.5772223E-6;
DDT.P_emp_tp[3][10] = -1.2415996E-5;
DDT.P_emp_tp[3][11] = -1.7861362E-5;
DDT.P_emp_tp[3][12] = -3.4336465E-5;
DDT.P_emp_tp[3][13] =  2.8746465E-5;
DDT.P_emp_tp[3][14] =  1.8540050E-4;
DDT.P_emp_tp[3][15] =  1.1850134E-4;
DDT.P_emp_tp[3][16] =  9.4210815E-5;
DDT.P_emp_tp[3][17] =  9.9750844E-5;
DDT.P_emp_tp[3][18] =  0.0000000E+0;
DDT.P_emp_tp[3][19] =  0.0000000E+0;
DDT.P_emp_tp[3][20] =  0.0000000E+0;

DDT.P_emp_tp[4][ 1] = 6.4909869E-1;
DDT.P_emp_tp[4][ 2] = 5.8953031E-1;
DDT.P_emp_tp[4][ 3] = 5.5696586E-1;
DDT.P_emp_tp[4][ 4] = 5.3448606E-1;
DDT.P_emp_tp[4][ 5] = 5.2563167E-1;
DDT.P_emp_tp[4][ 6] = 5.2102093E-1;
DDT.P_emp_tp[4][ 7] = 5.1517066E-1;
DDT.P_emp_tp[4][ 8] = 5.0901542E-1;
DDT.P_emp_tp[4][ 9] = 4.5343661E-1;
DDT.P_emp_tp[4][10] = 3.6796188E-1;
DDT.P_emp_tp[4][11] = 2.7097255E-1;
DDT.P_emp_tp[4][12] = 1.4465281E-1;
DDT.P_emp_tp[4][13] = 5.2860670E-2;
DDT.P_emp_tp[4][14] = 2.9147563E-2;
DDT.P_emp_tp[4][15] = 1.7071326E-2;
DDT.P_emp_tp[4][16] = 1.0298335E-2;
DDT.P_emp_tp[4][17] = 3.8014515E-3;
DDT.P_emp_tp[4][18] = 0.0000000E+0;
DDT.P_emp_tp[4][19] = 0.0000000E+0;
DDT.P_emp_tp[4][20] = 0.0000000E+0;

DDT.P_emp_tp[5][ 1] = 8.2014229E-1;
DDT.P_emp_tp[5][ 2] = 6.9021691E-1;
DDT.P_emp_tp[5][ 3] = 6.4564306E-1;
DDT.P_emp_tp[5][ 4] = 6.1181654E-1;
DDT.P_emp_tp[5][ 5] = 5.9973736E-1;
DDT.P_emp_tp[5][ 6] = 5.8810865E-1;
DDT.P_emp_tp[5][ 7] = 5.7601619E-1;
DDT.P_emp_tp[5][ 8] = 5.2500000E-1;
DDT.P_emp_tp[5][ 9] = 4.7000000E-1;
DDT.P_emp_tp[5][10] = 4.1400000E-1;
DDT.P_emp_tp[5][11] = 3.4849929E-1;
DDT.P_emp_tp[5][12] = 2.8102089E-1;
DDT.P_emp_tp[5][13] = 2.0925023E-1;
DDT.P_emp_tp[5][14] = 1.2462867E-1;
DDT.P_emp_tp[5][15] = 6.0891955E-2;
DDT.P_emp_tp[5][16] = 3.2789587E-2;
DDT.P_emp_tp[5][17] = 2.3149634E-2;
DDT.P_emp_tp[5][18] = 0.0000000E+0;
DDT.P_emp_tp[5][19] = 0.0000000E+0;
DDT.P_emp_tp[5][20] = 0.0000000E+0;

// F(ELEV.)
DDT.V0_el[1] =  6.2213490E+1;
DDT.V0_el[2] = -9.6527327E-1; // ***
DDT.V0_el[3] =  4.2822793E-1; // ***

// F(PROP. TEMP.)
DDT.V0_tp[1] = 1.0000000E+0;
DDT.V0_tp[2] = 1.0456580E-3;
DDT.V0_tp[3] = 1.8451650E-6;

// F(ELEV.)
DDT.T0_el[1] =  1.7271422E-1;
DDT.T0_el[2] =  2.5623723E-3;
DDT.T0_el[3] = -1.0319039E-3;

// F(PROP. TEMP.)
DDT.T0_tp[1] =  1.0000000E+0;
DDT.T0_tp[2] = -1.0906680E-3;
DDT.T0_tp[3] = -7.9336900E-7;

// [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec1[1] = 0.0000000E+0;
DDT.Hejec1[2] = 0.0000000E+0;
DDT.Hejec1[3] = 0.0000000E+0;
DDT.Hejec1[4] = 0.0000000E+0;
DDT.Hejec1[5] = 0.0000000E+0;

// [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec2[1] = 0.0000000E+0;
DDT.Hejec2[2] = 0.0000000E+0;
DDT.Hejec2[3] = 0.0000000E+0;
DDT.Hejec2[4] = 0.0000000E+0;
DDT.Hejec2[5] = 0.0000000E+0;

// [SEC] DELAY OF EJECTION
DDT.Delta_ejec = 0.000;

// WIND WEIGHTING POLYNOM
DDT.Bwiwe[1] =    45.9419; //  4.5942E+1;
DDT.Bwiwe[2] =  -429.9806; // -4.2998E+2;
DDT.Bwiwe[3] =  1416.5463; //  1.4165E+3;
DDT.Bwiwe[4] = -2301.0594; // -2.3011E+3;
DDT.Bwiwe[5] =  1826.9238; //  1.8269E+3;
DDT.Bwiwe[6] =  -565.9640; // -5.6596E+2;

// HEIGHT OF END OF THRUSTPHASE
DDT.Hmthph[1] = -210.9681; //-2.1097E+2; ***
DDT.Hmthph[2] = 2261.7033; // 2.2617E+3; ***
DDT.Hmthph[3] = -487.4126; //-4.8741E+2;
DDT.Hmthph[4] =    0.0000;

DDT.Cwss[ 0] = 0.38873;
DDT.Cwss[ 1] = 0.38872;
DDT.Cwss[ 2] = 0.38872;
DDT.Cwss[ 3] = 0.38878;
DDT.Cwss[ 4] = 0.38876;
DDT.Cwss[ 5] = 0.38874;
DDT.Cwss[ 6] = 0.38878;
DDT.Cwss[ 7] = 0.38875;
DDT.Cwss[ 8] = 0.38877;
DDT.Cwss[ 9] = 0.47500;
DDT.Cwss[10] = 0.58777;
DDT.Cwss[11] = 0.59974;
DDT.Cwss[12] = 0.59771;
DDT.Cwss[13] = 0.59057;
DDT.Cwss[14] = 0.58031;
DDT.Cwss[15] = 0.57304;
DDT.Cwss[16] = 0.56077;
DDT.Cwss[17] = 0.55047;
DDT.Cwss[18] = 0.54017;
DDT.Cwss[19] = 0.52890;
DDT.Cwss[20] = 0.52060;
DDT.Cwss[21] = 0.50930;
DDT.Cwss[22] = 0.49941;
DDT.Cwss[23] = 0.49104;
DDT.Cwss[24] = 0.48156;
DDT.Cwss[25] = 0.47116;
DDT.Cwss[26] = 0.46292;
DDT.Cwss[27] = 0.45365;
DDT.Cwss[28] = 0.44541;
DDT.Cwss[29] = 0.43508;
DDT.Cwss[30] = 0.42787;
DDT.Cwss[31] = 0.41963;
DDT.Cwss[32] = 0.41139;
DDT.Cwss[33] = 0.40512;
DDT.Cwss[34] = 0.39691;
DDT.Cwss[35] = 0.39173;
DDT.Cwss[36] = 0.38552;
DDT.Cwss[37] = 0.38037;
DDT.Cwss[38] = 0.37625;
DDT.Cwss[39] = 0.37110;
DDT.Cwss[40] = 0.36595;

// [MILS] MAX. TACTICAL ELEVATION
DDT.Elev_tat   = 980.0;
// [MILS] MIN. TACTICAL ELEVATION
DDT.Elev_min   = 109.9999; //125.0; alteracao determinada pelo ricardo pinto ***
// [MILS]  F                       {<<<5.2}
// [MILS]  F                       {<<<5.2}
// FLIGHT_TIME/ FUZE_TIME (low ejection)
DDT.Fuzecor1[1] = 1.0000000E+0;
DDT.Fuzecor1[2] = 0.0000000E+0;
DDT.Fuzecor1[3] = 0.0000000E+0;

// FLIGHT_TIME/ FUZE_TIME (high ejection)
DDT.Fuzecor2[1] = 1.0000000E+0;
DDT.Fuzecor2[2] = 0.0000000E+0;
DDT.Fuzecor2[3] = 0.0000000E+0;

// ELEVATION CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2

DDT.Elcor[1][1] = -0.000055; // ***
DDT.Elcor[1][2] = -0.001615;
DDT.Elcor[1][3] = -0.000082;
DDT.Elcor[1][4] =  0.000015;
DDT.Elcor[1][5] = -0.000033;
DDT.Elcor[1][6] =  0.000026;
DDT.Elcor[1][7] =  0.000121;
DDT.Elcor[1][8] =  0.000099;
DDT.Elcor[1][9] = -0.000069;

DDT.Elcor[2][1] =  0.000221; // ***
DDT.Elcor[2][2] =  0.019757;
DDT.Elcor[2][3] =  0.001259;
DDT.Elcor[2][4] =  0.000161;
DDT.Elcor[2][5] =  0.000128;
DDT.Elcor[2][6] = -0.000057;
DDT.Elcor[2][7] = -0.000808;
DDT.Elcor[2][8] =  0.000178;
DDT.Elcor[2][9] =  0.000199;

DDT.Elcor[3][1] = -0.000164; // ***
DDT.Elcor[3][2] = -0.011938;
DDT.Elcor[3][3] = -0.000928;
DDT.Elcor[3][4] = -0.000132;
DDT.Elcor[3][5] = -0.000087;
DDT.Elcor[3][6] =  0.000029;
DDT.Elcor[3][7] =  0.000200;
DDT.Elcor[3][8] = -0.000257;
DDT.Elcor[3][9] = -0.000155;

// AZIMUTH CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2

DDT.Azcor[1][1] = -0.000016; // ***
DDT.Azcor[1][2] = -0.000026;
DDT.Azcor[1][3] =  0.000011;
DDT.Azcor[1][4] = -0.013545;
DDT.Azcor[1][5] = -0.001049;
DDT.Azcor[1][6] = -0.000044;
DDT.Azcor[1][7] = -0.000017;
DDT.Azcor[1][8] =  0.000008;
DDT.Azcor[1][9] =  0.000001;

DDT.Azcor[2][1] =  0.000019; // ***
DDT.Azcor[2][2] =  0.000086;
DDT.Azcor[2][3] = -0.000081;
DDT.Azcor[2][4] = -0.000586;
DDT.Azcor[2][5] =  0.001003;
DDT.Azcor[2][6] =  0.000095;
DDT.Azcor[2][7] = -0.000001;
DDT.Azcor[2][8] =  0.000009;
DDT.Azcor[2][9] =  0.000059;

DDT.Azcor[3][1] = -0.000015; // ***
DDT.Azcor[3][2] =  0.000006;
DDT.Azcor[3][3] =  0.000083;
DDT.Azcor[3][4] =  0.000428;
DDT.Azcor[3][5] = -0.002029;
DDT.Azcor[3][6] = -0.000531;
DDT.Azcor[3][7] =  0.000003;
DDT.Azcor[3][8] = -0.000030;
DDT.Azcor[3][9] = -0.000059;

// DRAG CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2

DDT.Velcor[1][1] =  0.000002; // ***
DDT.Velcor[1][2] = -0.002143;
DDT.Velcor[1][3] = -0.000402;
DDT.Velcor[1][4] =  0.000023;
DDT.Velcor[1][5] =  0.000003;
DDT.Velcor[1][6] = -0.000008;
DDT.Velcor[1][7] =  0.003163;
DDT.Velcor[1][8] =  0.000445;
DDT.Velcor[1][9] =  0.000006;

DDT.Velcor[2][1] = -0.000020; // ***
DDT.Velcor[2][2] =  0.000488;
DDT.Velcor[2][3] =  0.002736;
DDT.Velcor[2][4] = -0.000043;
DDT.Velcor[2][5] =  0.000004;
DDT.Velcor[2][6] =  0.000016;
DDT.Velcor[2][7] =  0.001494;
DDT.Velcor[2][8] =  0.000335;
DDT.Velcor[2][9] = -0.000014;

DDT.Velcor[3][1] = -0.000004; // ***
DDT.Velcor[3][2] =  0.000961;
DDT.Velcor[3][3] = -0.000762;
DDT.Velcor[3][4] =  0.000023;
DDT.Velcor[3][5] = -0.000006;
DDT.Velcor[3][6] = -0.000007;
DDT.Velcor[3][7] = -0.002287;
DDT.Velcor[3][8] = -0.000537;
DDT.Velcor[3][9] =  0.000027;

DDT.El_to    = -2.9282760E-1;

DDT.Elbas[1] = -4.8306494E-1;
DDT.Elbas[2] =  1.0178916E+0;
DDT.Elbas[3] = -6.5691510E-1;

DDT.Azbas[1] = -1.1327421E-2;
DDT.Azbas[2] = -7.4810104E-3;
DDT.Azbas[3] =  1.8293652E-2;

DDT.Velbas[1] = -7.6988114E-4;
DDT.Velbas[2] =  9.3580342E-4;
DDT.Velbas[3] = -2.8090350E-4;
