// SKYFIRE M9 TS BAS. RES MEDIOS FORMOSA E DDSKYM9B.TS - 29/04/98 - DDSKYM9C.TS
//   DDM9T35.TS - DDTSFM9C.TS - 15 May 1998
// DATA DE MONTAGEM : 18 May 1998 - 13:03:09    ARQUIVO : 'BDTM9TSD.DAT'
// [KG] TOTAL ROCKET MASS
//
// REVISADO EM JANEIRO DE 2005:
//       - MIN-T-EL (Elevacao tatica minima) 145 mils conforme contrator C10
//         Valor diferente da AV-EDT
//
// [KG] TOTAL ROCKET MASS
DDT.Mass       = 11.30;
// [KG] PROPELLANT MASS
DDT.Propmass   = 3.65;
// [M] LAUNCHER LENGHT
DDT.Laul       = 5.33;
// [M] REFERENCE DIAMETER OF ROCKET
DDT.Diaref     = 0.070;
// NUMBER OF POINTS IN THRUST PROFILE
DDT.N_points   = 6.0;
// [M2] EXAUST AREA
DDT.Ass        = 0.00159;
// [N/M2] REFERENCE PRESSURE
DDT.Pnom       = 94540.0;
// [N] REFERENCE THRUST * STEP
DDT.Emp        = 2183.8 * 4;
// [DEG] MAXIMUM ELEVATION
DDT.Elevmax    = 38.0;
// [M/S] MAXIMUM WIND VELOCITY
DDT.Vwmax      = 15.0;
// CORRECTION FACTOR FOR DRAG IN THRUSTPHASE
DDT.Cdadj      = 0.79500;
// CORRECTION FACTOR FOR DRAG IN SEC. BAL.
DDT.Cdadjsm    = 0.00;
// WEIGHTING FACTOR
DDT.Fpon       = 1.20000;
DDT.T_emp_step[ 1] = 0.0;
DDT.T_emp_step[ 2] = 1.0;
DDT.T_emp_step[ 3] = 2.0;
DDT.T_emp_step[ 4] = 3.0;
DDT.T_emp_step[ 5] = 4.0;
DDT.T_emp_step[ 6] = 5.0;
DDT.T_emp_step[ 7] = 0.0;
DDT.T_emp_step[ 8] = 0.0;
DDT.T_emp_step[ 9] = 0.0;
DDT.T_emp_step[10] = 0.0;
DDT.T_emp_step[11] = 0.0;
DDT.T_emp_step[12] = 0.0;
DDT.T_emp_step[13] = 0.0;
DDT.T_emp_step[14] = 0.0;
DDT.T_emp_step[15] = 0.0;
DDT.T_emp_step[16] = 0.0;
DDT.T_emp_step[17] = 0.0;
DDT.T_emp_step[18] = 0.0;
DDT.T_emp_step[19] = 0.0;
DDT.T_emp_step[20] = 0.0;

DDT.P_emp_tp[1][ 1] = 0.9704380E+0;
DDT.P_emp_tp[1][ 2] = 0.9341620E+0;
DDT.P_emp_tp[1][ 3] = 0.9702580E+0;
DDT.P_emp_tp[1][ 4] = 0.9683910E+0;
DDT.P_emp_tp[1][ 5] = 0.3604670E+0;
DDT.P_emp_tp[1][ 6] = 0.0000000E+0;
DDT.P_emp_tp[1][ 7] = 0.0000000E+0;
DDT.P_emp_tp[1][ 8] = 0.0000000E+0;
DDT.P_emp_tp[1][ 9] = 0.0000000E+0;
DDT.P_emp_tp[1][10] = 0.0000000E+0;
DDT.P_emp_tp[1][11] = 0.0000000E+0;
DDT.P_emp_tp[1][12] = 0.0000000E+0;
DDT.P_emp_tp[1][13] = 0.0000000E+0;
DDT.P_emp_tp[1][14] = 0.0000000E+0;
DDT.P_emp_tp[1][15] = 0.0000000E+0;
DDT.P_emp_tp[1][16] = 0.0000000E+0;
DDT.P_emp_tp[1][17] = 0.0000000E+0;
DDT.P_emp_tp[1][18] = 0.0000000E+0;
DDT.P_emp_tp[1][19] = 0.0000000E+0;
DDT.P_emp_tp[1][20] = 0.0000000E+0;

DDT.P_emp_tp[2][ 1] = 2.8294800E-3;
DDT.P_emp_tp[2][ 2] = 1.6755200E-3;
DDT.P_emp_tp[2][ 3] = 1.8329900E-3;
DDT.P_emp_tp[2][ 4] = 1.2040900E-3;
DDT.P_emp_tp[2][ 5] = -5.5615300E-3;
DDT.P_emp_tp[2][ 6] = 0.0000000E+0;
DDT.P_emp_tp[2][ 7] = 0.0000000E+0;
DDT.P_emp_tp[2][ 8] = 0.0000000E+0;
DDT.P_emp_tp[2][ 9] = 0.0000000E+0;
DDT.P_emp_tp[2][10] = 0.0000000E+0;
DDT.P_emp_tp[2][11] = 0.0000000E+0;
DDT.P_emp_tp[2][12] = 0.0000000E+0;
DDT.P_emp_tp[2][13] = 0.0000000E+0;
DDT.P_emp_tp[2][14] = 0.0000000E+0;
DDT.P_emp_tp[2][15] = 0.0000000E+0;
DDT.P_emp_tp[2][16] = 0.0000000E+0;
DDT.P_emp_tp[2][17] = 0.0000000E+0;
DDT.P_emp_tp[2][18] = 0.0000000E+0;
DDT.P_emp_tp[2][19] = 0.0000000E+0;
DDT.P_emp_tp[2][20] = 0.0000000E+0;

DDT.P_emp_tp[3][ 1] = 1.2675600E-5;
DDT.P_emp_tp[3][ 2] = -9.1753200E-6;
DDT.P_emp_tp[3][ 3] = -3.8831200E-6;
DDT.P_emp_tp[3][ 4] = -4.3181800E-6;
DDT.P_emp_tp[3][ 5] = 1.0483800E-5;
DDT.P_emp_tp[3][ 6] = 0.0000000E+0;
DDT.P_emp_tp[3][ 7] = 0.0000000E+0;
DDT.P_emp_tp[3][ 8] = 0.0000000E+0;
DDT.P_emp_tp[3][ 9] = 0.0000000E+0;
DDT.P_emp_tp[3][10] = 0.0000000E+0;
DDT.P_emp_tp[3][11] = 0.0000000E+0;
DDT.P_emp_tp[3][12] = 0.0000000E+0;
DDT.P_emp_tp[3][13] = 0.0000000E+0;
DDT.P_emp_tp[3][14] = 0.0000000E+0;
DDT.P_emp_tp[3][15] = 0.0000000E+0;
DDT.P_emp_tp[3][16] = 0.0000000E+0;
DDT.P_emp_tp[3][17] = 0.0000000E+0;
DDT.P_emp_tp[3][18] = 0.0000000E+0;
DDT.P_emp_tp[3][19] = 0.0000000E+0;
DDT.P_emp_tp[3][20] = 0.0000000E+0;

DDT.P_emp_tp[4][ 1] = 0.0000000E+0;
DDT.P_emp_tp[4][ 2] = 0.0000000E+0;
DDT.P_emp_tp[4][ 3] = 0.0000000E+0;
DDT.P_emp_tp[4][ 4] = 0.0000000E+0;
DDT.P_emp_tp[4][ 5] = 0.0000000E+0;
DDT.P_emp_tp[4][ 6] = 0.0000000E+0;
DDT.P_emp_tp[4][ 7] = 0.0000000E+0;
DDT.P_emp_tp[4][ 8] = 0.0000000E+0;
DDT.P_emp_tp[4][ 9] = 0.0000000E+0;
DDT.P_emp_tp[4][10] = 0.0000000E+0;
DDT.P_emp_tp[4][11] = 0.0000000E+0;
DDT.P_emp_tp[4][12] = 0.0000000E+0;
DDT.P_emp_tp[4][13] = 0.0000000E+0;
DDT.P_emp_tp[4][14] = 0.0000000E+0;
DDT.P_emp_tp[4][15] = 0.0000000E+0;
DDT.P_emp_tp[4][16] = 0.0000000E+0;
DDT.P_emp_tp[4][17] = 0.0000000E+0;
DDT.P_emp_tp[4][18] = 0.0000000E+0;
DDT.P_emp_tp[4][19] = 0.0000000E+0;
DDT.P_emp_tp[4][20] = 0.0000000E+0;

DDT.P_emp_tp[5][ 1] = 2.0000000E+0;
DDT.P_emp_tp[5][ 2] = 2.0000000E+0;
DDT.P_emp_tp[5][ 3] = 2.0000000E+0;
DDT.P_emp_tp[5][ 4] = 2.0000000E+0;
DDT.P_emp_tp[5][ 5] = 2.0000000E+0;
DDT.P_emp_tp[5][ 6] = 0.0000000E+0;
DDT.P_emp_tp[5][ 7] = 0.0000000E+0;
DDT.P_emp_tp[5][ 8] = 0.0000000E+0;
DDT.P_emp_tp[5][ 9] = 0.0000000E+0;
DDT.P_emp_tp[5][10] = 0.0000000E+0;
DDT.P_emp_tp[5][11] = 0.0000000E+0;
DDT.P_emp_tp[5][12] = 0.0000000E+0;
DDT.P_emp_tp[5][13] = 0.0000000E+0;
DDT.P_emp_tp[5][14] = 0.0000000E+0;
DDT.P_emp_tp[5][15] = 0.0000000E+0;
DDT.P_emp_tp[5][16] = 0.0000000E+0;
DDT.P_emp_tp[5][17] = 0.0000000E+0;
DDT.P_emp_tp[5][18] = 0.0000000E+0;
DDT.P_emp_tp[5][19] = 0.0000000E+0;
DDT.P_emp_tp[5][20] = 0.0000000E+0;

// F(ELEV.)
DDT.V0_el[1] = 9.1122940E+1;
DDT.V0_el[2] = -3.9997600E-1;
DDT.V0_el[3] = 9.6689560E-2;

// F(PROP. TEMP.)
DDT.V0_tp[1] = 1.0000000E+0;
DDT.V0_tp[2] = 1.3244560E-3;
DDT.V0_tp[3] = 2.5068660E-6;

// F(ELEV.)
DDT.T0_el[1] = 1.1754100E-1;
DDT.T0_el[2] = 5.1931740E-4;
DDT.T0_el[3] = -1.2317800E-4;

// F(PROP. TEMP.)
DDT.T0_tp[1] = 1.0000000E+0;
DDT.T0_tp[2] = -1.3585800E-3;
DDT.T0_tp[3] = -2.1001790E-6;

// [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec1[1] = 0.0000000E+0;
DDT.Hejec1[2] = 0.0000000E+0;
DDT.Hejec1[3] = 0.0000000E+0;
DDT.Hejec1[4] = 0.0000000E+0;
DDT.Hejec1[5] = 0.0000000E+0;

// [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec2[1] = 0.0000000E+0;
DDT.Hejec2[2] = 0.0000000E+0;
DDT.Hejec2[3] = 0.0000000E+0;
DDT.Hejec2[4] = 0.0000000E+0;
DDT.Hejec2[5] = 0.0000000E+0;

// [SEC] DELAY OF EJECTION
DDT.Delta_ejec = 0.000;
// WIND WEIGHTING POLYNOM
DDT.Bwiwe[1] = 1.0000E+0;
DDT.Bwiwe[2] = 0.0000E+0;
DDT.Bwiwe[3] = 0.0000E+0;
DDT.Bwiwe[4] = 0.0000E+0;
DDT.Bwiwe[5] = 0.0000E+0;
DDT.Bwiwe[6] = 0.0000E+0;

// HEIGHT OF END OF THRUSTPHASE
DDT.Hmthph[1] = -3.922800E+1;
DDT.Hmthph[2] = 6.610100E+2;
DDT.Hmthph[3] = -3.543000E+1;
DDT.Hmthph[4] = 0.0000E+0;

DDT.Cwss[ 0] = 0.57014;
DDT.Cwss[ 1] = 0.57014;
DDT.Cwss[ 2] = 0.57014;
DDT.Cwss[ 3] = 0.57014;
DDT.Cwss[ 4] = 0.58566;
DDT.Cwss[ 5] = 0.58566;
DDT.Cwss[ 6] = 0.58566;
DDT.Cwss[ 7] = 0.60078;
DDT.Cwss[ 8] = 0.61939;
DDT.Cwss[ 9] = 0.64476;
DDT.Cwss[10] = 0.66804;
DDT.Cwss[11] = 0.70356;
DDT.Cwss[12] = 0.70715;
DDT.Cwss[13] = 0.73819;
DDT.Cwss[14] = 0.76595;
DDT.Cwss[15] = 0.78336;
DDT.Cwss[16] = 0.75540;
DDT.Cwss[17] = 0.76177;
DDT.Cwss[18] = 0.74436;
DDT.Cwss[19] = 0.73749;
DDT.Cwss[20] = 0.72555;
DDT.Cwss[21] = 0.71351;
DDT.Cwss[22] = 0.70725;
DDT.Cwss[23] = 0.70764;
DDT.Cwss[24] = 0.70625;
DDT.Cwss[25] = 0.69779;
DDT.Cwss[26] = 0.69381;
DDT.Cwss[27] = 0.68317;
DDT.Cwss[28] = 0.67978;
DDT.Cwss[29] = 0.67511;
DDT.Cwss[30] = 0.66914;
DDT.Cwss[31] = 0.66516;
DDT.Cwss[32] = 0.65690;
DDT.Cwss[33] = 0.64894;
DDT.Cwss[34] = 0.64138;
DDT.Cwss[35] = 0.63421;
DDT.Cwss[36] = 0.62755;
DDT.Cwss[37] = 0.62138;
DDT.Cwss[38] = 0.61541;
DDT.Cwss[39] = 0.61003;
DDT.Cwss[40] = 0.60496;

// [MILS] MAX. TACTICAL ELEVATION
DDT.Elev_tat   = 650.0;
// [MILS] MIN. TACTICAL ELEVATION
DDT.Elev_min   = 145.0;
// [MILS]
// [MILS]
// FLIGHT_TIME/ FUZE_TIME (LOW EJECTION)
DDT.Fuzecor1[1] = 1.0000E+0;
DDT.Fuzecor1[2] = 0.0000E+0;
DDT.Fuzecor1[3] = 0.0000E+0;

// FLIGHT_TIME/ FUZE_TIME (HIGH EJECTION)
DDT.Fuzecor2[1] = 1.0000E+0;
DDT.Fuzecor2[2] = 0.0000E+0;
DDT.Fuzecor2[3] = 0.0000E+0;

// ELEVATION CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2
DDT.Elcor[1][1] = 0.000007;
DDT.Elcor[1][2] = -0.000336;
DDT.Elcor[1][3] = -0.000030;
DDT.Elcor[1][4] = 0.000079;
DDT.Elcor[1][5] = 0.000006;
DDT.Elcor[1][6] = -0.000012;
DDT.Elcor[1][7] = 0.000012;
DDT.Elcor[1][8] = 0.000007;
DDT.Elcor[1][9] = 0.000041;

DDT.Elcor[2][1] = -0.000016;
DDT.Elcor[2][2] = 0.006987;
DDT.Elcor[2][3] = 0.000344;
DDT.Elcor[2][4] = -0.000041;
DDT.Elcor[2][5] = 0.000019;
DDT.Elcor[2][6] = 0.000062;
DDT.Elcor[2][7] = -0.000155;
DDT.Elcor[2][8] = 0.000353;
DDT.Elcor[2][9] = -0.000054;

DDT.Elcor[3][1] = 0.000006;
DDT.Elcor[3][2] = -0.002436;
DDT.Elcor[3][3] = -0.000159;
DDT.Elcor[3][4] = 0.000019;
DDT.Elcor[3][5] = -0.000020;
DDT.Elcor[3][6] = -0.000042;
DDT.Elcor[3][7] = 0.000019;
DDT.Elcor[3][8] = -0.000217;
DDT.Elcor[3][9] = -0.000005;

// AZIMUTH CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2
DDT.Azcor[1][1] = -0.000012;
DDT.Azcor[1][2] = -0.000000;
DDT.Azcor[1][3] = 0.000012;
DDT.Azcor[1][4] = -0.008738;
DDT.Azcor[1][5] = -0.000369;
DDT.Azcor[1][6] = 0.000012;
DDT.Azcor[1][7] = -0.000008;
DDT.Azcor[1][8] = -0.000011;
DDT.Azcor[1][9] = -0.000028;

DDT.Azcor[2][1] = 0.000028;
DDT.Azcor[2][2] = -0.000010;
DDT.Azcor[2][3] = -0.000076;
DDT.Azcor[2][4] = -0.000440;
DDT.Azcor[2][5] = 0.000006;
DDT.Azcor[2][6] = -0.000067;
DDT.Azcor[2][7] = -0.000045;
DDT.Azcor[2][8] = 0.000088;
DDT.Azcor[2][9] = 0.000155;

DDT.Azcor[3][1] = -0.000029;
DDT.Azcor[3][2] = 0.000039;
DDT.Azcor[3][3] = 0.000069;
DDT.Azcor[3][4] = 0.000261;
DDT.Azcor[3][5] = -0.000197;
DDT.Azcor[3][6] = -0.000083;
DDT.Azcor[3][7] = 0.000049;
DDT.Azcor[3][8] = -0.000059;
DDT.Azcor[3][9] = -0.000132;

// DRAG CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//       En^0          En^1          En^2
// VY^0*VX^0
// VY^1*VX^0
// VY^2*VX^0
// VY^0*VX^1
// VY^1*VX^1
// VY^2*VX^1
// VY^0*VX^2
// VY^1*VX^2
// VY^2*VX^2
DDT.Velcor[1][1] = -0.000234;
DDT.Velcor[1][2] = 0.002064;
DDT.Velcor[1][3] = 0.000719;
DDT.Velcor[1][4] = -0.000016;
DDT.Velcor[1][5] = -0.000075;
DDT.Velcor[1][6] = 0.000105;
DDT.Velcor[1][7] = 0.010107;
DDT.Velcor[1][8] = 0.000659;
DDT.Velcor[1][9] = -0.000517;

DDT.Velcor[2][1] = -0.000056;
DDT.Velcor[2][2] = -0.003025;
DDT.Velcor[2][3] = 0.000916;
DDT.Velcor[2][4] = 0.000064;
DDT.Velcor[2][5] = 0.000342;
DDT.Velcor[2][6] = -0.000288;
DDT.Velcor[2][7] = 0.000415;
DDT.Velcor[2][8] = 0.000658;
DDT.Velcor[2][9] = 0.002058;

DDT.Velcor[3][1] = 0.000184;
DDT.Velcor[3][2] = 0.001328;
DDT.Velcor[3][3] = 0.001307;
DDT.Velcor[3][4] = -0.000082;
DDT.Velcor[3][5] = -0.000268;
DDT.Velcor[3][6] = 0.000219;
DDT.Velcor[3][7] = -0.002170;
DDT.Velcor[3][8] = -0.000696;
DDT.Velcor[3][9] = -0.001286;

DDT.El_to      = -2.5000000E-2;
DDT.Elbas[1] = -5.3956180E-3;
DDT.Elbas[2] = -8.8809030E-2;
DDT.Elbas[3] = -9.1381320E-3;

DDT.Azbas[1] = -2.1124200E-3;
DDT.Azbas[2] = 1.0805190E-2;
DDT.Azbas[3] = -6.6124150E-3;

DDT.Velbas[1] = -2.5124610E-2;
DDT.Velbas[2] = 1.5020080E-3;
DDT.Velbas[3] = -2.0549060E-4;
DDT.Velbas[3] = -2.0549060E-4;

