//\ SS-80 ARQUIVO NOMINAL COM CORRECAO DE EMPUXO POS FORMOSA 28/06 E CPrM 13/07/02
//\    DD8C-7 - S-ARQ - DDT8C7 - 19 Out 2002
//\ DATA DE MONTAGEM : 19 Out 2002 - 10:50:40    ARQUIVO : ''
//\
//\ REVISADO EM JANEIRO DE 2005:
//\       - MIN-T-EL (Elevacao tatica minima) alterado para  350 mils
//\       - MAX-T-EL (Elevacao tatica maxima) alterado para 1005 mils
//\
//\ [KG] TOTAL ROCKET MASS
DDT.Mass       = 590.88;
//\ [KG] PROPELLANT MASS
DDT.Propmass   = 277.98;
//\ [M] LAUNCHER LENGHT
DDT.Laul       = 5.45;
//\ [M] REFERENCE DIAMETER OF ROCKET
DDT.Diaref     = 0.3000;
//\ NUMBER OF POINTS IN THRUST PROFILE
DDT.N_points   = 19.0;
//\ [M2] EXAUST AREA
DDT.Ass        = 0.045239;
//\ [N/M2] REFERENCE PRESSURE
DDT.Pnom       = 94540.0;
//\ [N] REFERENCE THRUST * STEP
DDT.Emp        = 19217.175 * 4;
//\ [DEG] MAXIMUM ELEVATION
DDT.Elevmax    = 61.80;
//\ [M/S] MAXIMUM WIND VELOCITY
DDT.Vwmax      = 15.0;
//\ CORRECTION FACTOR FOR DRAG IN THRUSTPHASE
DDT.Cdadj      = 0.6150;
//\ CORRECTION FACTOR FOR DRAG IN SEC. BAL.
DDT.Cdadjsm    = 34.756676;
//\ WEIGHTING FACTOR
DDT.Fpon       = 1.00000;
DDT.T_emp_step[ 1] = 0.0;
DDT.T_emp_step[ 2] = 1.0;
DDT.T_emp_step[ 3] = 2.0;
DDT.T_emp_step[ 4] = 8.0;
DDT.T_emp_step[ 5] = 16.0;
DDT.T_emp_step[ 6] = 27.0;
DDT.T_emp_step[ 7] = 29.0;
DDT.T_emp_step[ 8] = 30.0;
DDT.T_emp_step[ 9] = 31.0;
DDT.T_emp_step[10] = 32.0;
DDT.T_emp_step[11] = 34.0;
DDT.T_emp_step[12] = 35.0;
DDT.T_emp_step[13] = 36.0;
DDT.T_emp_step[14] = 38.0;
DDT.T_emp_step[15] = 40.0;
DDT.T_emp_step[16] = 42.0;
DDT.T_emp_step[17] = 44.0;
DDT.T_emp_step[18] = 46.0;
DDT.T_emp_step[19] = 49.0;
DDT.T_emp_step[20] = 0.0;

DDT.P_emp_tp[1][ 1] = 8.0271500E-1;
DDT.P_emp_tp[1][ 2] = 8.5116500E-1;
DDT.P_emp_tp[1][ 3] = 9.0043100E-1;
DDT.P_emp_tp[1][ 4] = 8.8988800E-1;
DDT.P_emp_tp[1][ 5] = 9.5994200E-1;
DDT.P_emp_tp[1][ 6] = 9.4115500E-1;
DDT.P_emp_tp[1][ 7] = 9.2412200E-1;
DDT.P_emp_tp[1][ 8] = 8.6755700E-1;
DDT.P_emp_tp[1][ 9] = 8.2236300E-1;
DDT.P_emp_tp[1][10] = 7.7391900E-1;
DDT.P_emp_tp[1][11] = 6.4063300E-1;
DDT.P_emp_tp[1][12] = 4.4537900E-1;
DDT.P_emp_tp[1][13] = 3.6203900E-1;
DDT.P_emp_tp[1][14] = 2.3754600E-1;
DDT.P_emp_tp[1][15] = 1.6188500E-1;
DDT.P_emp_tp[1][16] = 1.2400000E-1;
DDT.P_emp_tp[1][17] = 1.0000000E-1;
DDT.P_emp_tp[1][18] = 8.6000000E-2;
DDT.P_emp_tp[1][19] = 0.0000000E+0;
DDT.P_emp_tp[1][20] = 0.0000000E+0;

DDT.P_emp_tp[2][ 1] = 1.3525470E-3;
DDT.P_emp_tp[2][ 2] = 1.7553120E-3;
DDT.P_emp_tp[2][ 3] = 1.9496660E-3;
DDT.P_emp_tp[2][ 4] = 2.0324580E-3;
DDT.P_emp_tp[2][ 5] = 2.0393520E-3;
DDT.P_emp_tp[2][ 6] = 1.3508510E-3;
DDT.P_emp_tp[2][ 7] = -4.0695380E-4;
DDT.P_emp_tp[2][ 8] = -1.5921370E-3;
DDT.P_emp_tp[2][ 9] = -3.7580850E-3;
DDT.P_emp_tp[2][10] = -6.6118160E-3;
DDT.P_emp_tp[2][11] = -8.6774640E-3;
DDT.P_emp_tp[2][12] = -1.0580700E-2;
DDT.P_emp_tp[2][13] = -1.2126590E-2;
DDT.P_emp_tp[2][14] = -1.1068260E-2;
DDT.P_emp_tp[2][15] = -1.1095470E-2;
DDT.P_emp_tp[2][16] = -1.2580510E-2;
DDT.P_emp_tp[2][17] = -1.2881410E-2;
DDT.P_emp_tp[2][18] = -1.3259620E-2;
DDT.P_emp_tp[2][19] = 0.0000000E+0;
DDT.P_emp_tp[2][20] = 0.0000000E+0;

DDT.P_emp_tp[3][ 1] = -7.1189030E-6;
DDT.P_emp_tp[3][ 2] = -6.3619980E-6;
DDT.P_emp_tp[3][ 3] = -9.2852650E-6;
DDT.P_emp_tp[3][ 4] = -1.4027720E-6;
DDT.P_emp_tp[3][ 5] = -5.4206190E-6;
DDT.P_emp_tp[3][ 6] = -4.3896600E-6;
DDT.P_emp_tp[3][ 7] = -3.0565550E-5;
DDT.P_emp_tp[3][ 8] = -3.2957490E-5;
DDT.P_emp_tp[3][ 9] = -5.7521920E-5;
DDT.P_emp_tp[3][10] = -9.0068340E-5;
DDT.P_emp_tp[3][11] = -1.1021080E-4;
DDT.P_emp_tp[3][12] = -4.2488530E-5;
DDT.P_emp_tp[3][13] = -6.1048120E-6;
DDT.P_emp_tp[3][14] = -2.9584290E-5;
DDT.P_emp_tp[3][15] = -3.3728260E-5;
DDT.P_emp_tp[3][16] = -1.7808020E-5;
DDT.P_emp_tp[3][17] = -3.5854310E-5;
DDT.P_emp_tp[3][18] = -1.2100190E-5;
DDT.P_emp_tp[3][19] = 0.0000000E+0;
DDT.P_emp_tp[3][20] = 0.0000000E+0;

DDT.P_emp_tp[4][ 1] = 7.1700000E-1;
DDT.P_emp_tp[4][ 2] = 7.4200000E-1;
DDT.P_emp_tp[4][ 3] = 7.6500000E-1;
DDT.P_emp_tp[4][ 4] = 7.7690000E-1;
DDT.P_emp_tp[4][ 5] = 8.2380000E-1;
DDT.P_emp_tp[4][ 6] = 8.5000000E-1;
DDT.P_emp_tp[4][ 7] = 8.3190000E-1;
DDT.P_emp_tp[4][ 8] = 7.2440000E-1;
DDT.P_emp_tp[4][ 9] = 5.4710000E-1;
DDT.P_emp_tp[4][10] = 3.4150000E-1;
DDT.P_emp_tp[4][11] = 1.8430000E-1;
DDT.P_emp_tp[4][12] = 1.6110000E-1;
DDT.P_emp_tp[4][13] = 1.3590000E-1;
DDT.P_emp_tp[4][14] = 8.7800000E-2;
DDT.P_emp_tp[4][15] = 7.0000000E-2;
DDT.P_emp_tp[4][16] = 5.0000000E-2;
DDT.P_emp_tp[4][17] = 3.0800000E-2;
DDT.P_emp_tp[4][18] = 3.0000000E-2;
DDT.P_emp_tp[4][19] = 0.0000000E+0;
DDT.P_emp_tp[4][20] = 0.0000000E+0;

DDT.P_emp_tp[5][ 1] = 8.4440000E-1;
DDT.P_emp_tp[5][ 2] = 9.1410000E-1;
DDT.P_emp_tp[5][ 3] = 9.6920000E-1;
DDT.P_emp_tp[5][ 4] = 9.7910000E-1;
DDT.P_emp_tp[5][ 5] = 1.0468000E+0;
DDT.P_emp_tp[5][ 6] = 9.9150000E-1;
DDT.P_emp_tp[5][ 7] = 9.3950000E-1;
DDT.P_emp_tp[5][ 8] = 8.9630000E-1;
DDT.P_emp_tp[5][ 9] = 8.8270000E-1;
DDT.P_emp_tp[5][10] = 8.7600000E-1;
DDT.P_emp_tp[5][11] = 7.5590000E-1;
DDT.P_emp_tp[5][12] = 6.6000000E-1;
DDT.P_emp_tp[5][13] = 6.1750000E-1;
DDT.P_emp_tp[5][14] = 3.7000000E-1;
DDT.P_emp_tp[5][15] = 2.5000000E-1;
DDT.P_emp_tp[5][16] = 2.0000000E-1;
DDT.P_emp_tp[5][17] = 1.4000000E-1;
DDT.P_emp_tp[5][18] = 1.0000000E-1;
DDT.P_emp_tp[5][19] = 0.0000000E+0;
DDT.P_emp_tp[5][20] = 0.0000000E+0;

//\ F(ELEV.)
DDT.V0_el[1] = 3.3828667E+1;
DDT.V0_el[2] = -2.0086546E+0;
DDT.V0_el[3] = 9.3381818E-1;

//\ F(PROP. TEMP.)
DDT.V0_tp[1] = 9.9562035E-1;
DDT.V0_tp[2] = 8.9588930E-4;
DDT.V0_tp[3] = -3.9919000E-6;

//\ F(ELEV.)
DDT.T0_el[1] = 3.2969526E-1;
DDT.T0_el[2] = 2.0617000E-2;
DDT.T0_el[3] = -9.2869100E-3;

//\ F(PROP. TEMP.)
DDT.T0_tp[1] = 1.0040454E+0;
DDT.T0_tp[2] = -8.3302110E-4;
DDT.T0_tp[3] = 4.7875000E-6;

//\ [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec1[1] = 1.0000000E+3;
DDT.Hejec1[2] = 4.0000000E+1;
DDT.Hejec1[3] = 0.0000000E+0;
DDT.Hejec1[4] = 2.0000000E+3;
DDT.Hejec1[5] = 3.0000000E+3;

//\ [M] HEIGHT OF EJECTION RELATIVE TO TARGET
DDT.Hejec2[1] = 3.0000000E+3;
DDT.Hejec2[2] = 0.0000000E+0;
DDT.Hejec2[3] = 0.0000000E+0;
DDT.Hejec2[4] = 3.0000000E+3;
DDT.Hejec2[5] = 3.0000000E+3;

//\ [SEC] DELAY OF EJECTION
DDT.Delta_ejec = 0.100;
//\ WIND WEIGHTING POLYNOM

DDT.Bwiwe[1] = 6.74237E+1;
DDT.Bwiwe[2] = -5.114906E+2;
DDT.Bwiwe[3] =1.429781E+3;
DDT.Bwiwe[4] = -2.01498E+3;
DDT.Bwiwe[5] = 1.417467E+3;
DDT.Bwiwe[6] = -3.974118E+2;

//\ HEIGHT OF END OF THRUSTPHASE
DDT.Hmthph[1] = -1.228984E+3;
DDT.Hmthph[2] = 5.818474E+3;
DDT.Hmthph[3] = -1.429781E+3;
DDT.Hmthph[4] = 0.0000E+0;

DDT.Cwss[0]=0.57986;
DDT.Cwss[1]=0.57986;
DDT.Cwss[2]=0.57986;
DDT.Cwss[3]=0.57986;
DDT.Cwss[4]=0.57986;
DDT.Cwss[5]=0.57986;
DDT.Cwss[6]=0.57986;
DDT.Cwss[7]=0.57986;
DDT.Cwss[8]=0.58171;
DDT.Cwss[9]=0.60280;
DDT.Cwss[10]=0.70516;
DDT.Cwss[11]=0.81648;
DDT.Cwss[12]=0.83346;
DDT.Cwss[13]=0.81789;
DDT.Cwss[14]=0.79418;
DDT.Cwss[15]=0.77308;
DDT.Cwss[16]=0.75063;
DDT.Cwss[17]=0.72624;
DDT.Cwss[18]=0.70270;
DDT.Cwss[19]=0.68404;
DDT.Cwss[20]=0.66492;
DDT.Cwss[21]=0.64702;
DDT.Cwss[22]=0.63184;
DDT.Cwss[23]=0.61511;
DDT.Cwss[24]=0.59857;
DDT.Cwss[25]=0.58477;
DDT.Cwss[26]=0.57161;
DDT.Cwss[27]=0.55688;
DDT.Cwss[28]=0.54428;
DDT.Cwss[29]=0.52908;
DDT.Cwss[30]=0.51366;
DDT.Cwss[31]=0.50056;
DDT.Cwss[32]=0.48867;
DDT.Cwss[33]=0.47740;
DDT.Cwss[34]=0.46609;
DDT.Cwss[35]=0.45462;
DDT.Cwss[36]=0.44405;
DDT.Cwss[37]=0.43241;
DDT.Cwss[38]=0.42228;
DDT.Cwss[39]=0.41137;
DDT.Cwss[40]=0.40129;

//\ [MILS] MAX. TACTICAL ELEVATION
DDT.Elev_tat   = 1066.0;
//\ [MILS] MIN. TACTICAL ELEVATION
DDT.Elev_min   = 450.0;
//\ [MILS]
//\ [MILS]
//\ FLIGHT_TIME/ FUZE_TIME (LOW EJECTION)
DDT.Fuzecor1[1] = 1.0000000E+0;
DDT.Fuzecor1[2] = 0.0000000E-0;
DDT.Fuzecor1[3] = 0.0000000E-0;

//\ FLIGHT_TIME/ FUZE_TIME (HIGH EJECTION)
DDT.Fuzecor2[1] = 1.0000000E+0;
DDT.Fuzecor2[2] = 0.0000000E-0;
DDT.Fuzecor2[3] = 0.0000000E-0;

//\ ELEVATION CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2
DDT.Elcor[1][1] = 1.558980E-5;
DDT.Elcor[1][2] = 7.555425E-6;
DDT.Elcor[1][3] = -4.083678E-5;
DDT.Elcor[1][4] = -6.850939E-3;
DDT.Elcor[1][5] = 4.206126E-2;
DDT.Elcor[1][6] = -2.676377E-2;
DDT.Elcor[1][7] = -3.478197E-4;
DDT.Elcor[1][8] = 2.868550E-3;
DDT.Elcor[1][9] = -2.174135E-3;

DDT.Elcor[2][1] = -4.081395E-4;
DDT.Elcor[2][2] = 2.667280E-4;
DDT.Elcor[2][3] = -4.347846E-5;
DDT.Elcor[2][4] = -1.000677E-4;
DDT.Elcor[2][5] = 6.444954E-5;
DDT.Elcor[2][6] = -2.458776E-5;
DDT.Elcor[2][7] = 9.135762E-6;
DDT.Elcor[2][8] = -1.154081E-4;
DDT.Elcor[2][9] =  8.364432E-5;

DDT.Elcor[3][1] = 3.354792E-4;
DDT.Elcor[3][2] = -2.443723E-3;
DDT.Elcor[3][3] = 8.560105E-4;
DDT.Elcor[3][4] = -1.481121E-4;
DDT.Elcor[3][5] = 8.323058E-4;
DDT.Elcor[3][6] = -9.830558E-4;
DDT.Elcor[3][7] = -1.635036E-4;
DDT.Elcor[3][8] = 1.032944E-3;
DDT.Elcor[3][9] = -9.342368E-4;

//\ AZIMUTH CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2
DDT.Azcor[1][1] =1.634924E-4;
DDT.Azcor[1][2] =2.914256E-4;
DDT.Azcor[1][3] =-2.976221E-4;
DDT.Azcor[1][4] = 1.349190E-4;
DDT.Azcor[1][5] =-2.991486E-4;
DDT.Azcor[1][6] =-2.203566E-4;
DDT.Azcor[1][7] = 2.234899E-4;
DDT.Azcor[1][8] =-3.280944E-4;
DDT.Azcor[1][9] = 3.113914E-5;

DDT.Azcor[2][1] = -2.147283E-2;
DDT.Azcor[2][2] = -2.108989E-3;
DDT.Azcor[2][3] =  2.534379E-3;
DDT.Azcor[2][4] = -3.676408E-3;
DDT.Azcor[2][5] = 6.204507E-3;
DDT.Azcor[2][6] = -8.112799E-3;
DDT.Azcor[2][7] = -1.453161E-3;
DDT.Azcor[2][8] = 3.886956E-3;
DDT.Azcor[2][9] = -4.043092E-3;

DDT.Azcor[3][1] =  2.885107E-4;
DDT.Azcor[3][2] = -4.620301E-4;
DDT.Azcor[3][3] =  3.214620E-4;
DDT.Azcor[3][4] = -5.433623E-5;
DDT.Azcor[3][5] = 8.918708E-5;
DDT.Azcor[3][6] = 5.847326E-5;
DDT.Azcor[3][7] = -3.148278E-4;
DDT.Azcor[3][8] = 4.453872E-4;
DDT.Azcor[3][9] = -1.016085E-4;
//\ DRAG CORRECTION POLYNOM DUE TO WIND IN THRUSTPHASE
//\       En^0          En^1          En^2
//\ VY^0*VX^0
//\ VY^1*VX^0
//\ VY^2*VX^0
//\ VY^0*VX^1
//\ VY^1*VX^1
//\ VY^2*VX^1
//\ VY^0*VX^2
//\ VY^1*VX^2
//\ VY^2*VX^2
DDT.Velcor[1][1] =1.160547E-4;
DDT.Velcor[1][2] =-3.881121E-4;
DDT.Velcor[1][3] = 3.005183E-4;
DDT.Velcor[1][4] =  6.090155E-3;
DDT.Velcor[1][5] = -1.517866E-2;
DDT.Velcor[1][6] =  8.241911E-3;
DDT.Velcor[1][7] =-9.344703E-4;
DDT.Velcor[1][8] = 2.407089E-3;
DDT.Velcor[1][9] = 6.619235E-4;

DDT.Velcor[2][1] = 1.539945E-4;
DDT.Velcor[2][2] = -3.287243E-4;
DDT.Velcor[2][3] =  2.024917E-4;
DDT.Velcor[2][4] = 7.460378E-6;
DDT.Velcor[2][5] = -6.108733E-5;
DDT.Velcor[2][6] =  5.951597E-5;
DDT.Velcor[2][7] =-4.937029E-6;
DDT.Velcor[2][8] = 1.908748E-5;
DDT.Velcor[2][9] = -2.061896E-5;

DDT.Velcor[3][1] = 1.324877E-3;
DDT.Velcor[3][2] = 6.996154E-3;
DDT.Velcor[3][3] = -5.318913E-3;
DDT.Velcor[3][4] = 1.112592E-4;
DDT.Velcor[3][5] = 2.159189E-3;
DDT.Velcor[3][6] = -1.745534E-3;
DDT.Velcor[3][7] =-3.692884E-5;
DDT.Velcor[3][8] =3.768257E-4;
DDT.Velcor[3][9] =-3.371468E-4 ;

DDT.El_to      = -2.20E+0;
DDT.Elbas[1] = 9.6278327E-1;
DDT.Elbas[2] = 2.8821147E+0;
DDT.Elbas[3] = -1.0189906E+0;

DDT.Azbas[1] = -1.7204298E-1;
DDT.Azbas[2] = 8.7504236E-1;
DDT.Azbas[3] = -9.1907513E-1;

DDT.Velbas[1] = 5.6784101E-2;
DDT.Velbas[2] = -8.9342442E-2;
DDT.Velbas[3] = 2.7399558E-2;


