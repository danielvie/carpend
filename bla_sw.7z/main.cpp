////////////////////////////////////////////////////////////////////////////////////////////
//			Aqui entram os includes necess�rios para esse rodar em C
//
//
////////////////////////////////////////////////////////////////////////////////////////////

#include <cstdio>
#include "novaedt.h"
#include "bradock.h"
#include "imprimir.h"
#include "testes.h"

#include <Windows.h>
#include <time.h>

/* Aqui existe o include da classe. Sim!! O Daniel, o Alexandre e eu estamos trabalhando com
*  classe.
*/

/* PROGRAMA PRINCIPAL.
*  Aqui dentro tentaremos emular tudo que ir� acontecer no
*  CCT e criaremos programas capazes de manter essa bagun�a sob controle.
*/

// inicializando objeto
novaEdt nedt;

int main(int argc, char **argv) {

	testeLancamentoSimples(&nedt);

	return 0;
}
