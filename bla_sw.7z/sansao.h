/*
 * sansao.h
 *
 *  Created on: 08/12/2014
 *      Author: User
 */

#ifndef SANSAO_H_
#define SANSAO_H_

#include <math.h>

struct vetor_xyz {
    double x;
    double y;
    double z;
};

class sansao {
public:
	 static double norma_v(struct vetor_xyz v);
	 static double dot(struct vetor_xyz v1, struct vetor_xyz v2);
	 static struct vetor_xyz sub(struct vetor_xyz v1, struct vetor_xyz v2);
	 static struct vetor_xyz add(struct vetor_xyz v1, struct vetor_xyz v2);
	 static struct vetor_xyz cross(struct vetor_xyz v1, struct vetor_xyz v2);

	 static struct vetor_xyz mul(struct vetor_xyz V, double x);
	 static struct vetor_xyz div(struct vetor_xyz V, double x);

	 static double ang_vetores(struct vetor_xyz v1, struct vetor_xyz v2);
     static double prod_escalar(double *x, double *y);
     static double prod_vetorial(double *x, double *y, int el);
     static int minimo(double *x, int tam);
     static double arredonda(double x);
     static double trunca(double x);
     static double calc_azimute(struct vetor_xyz origem, struct vetor_xyz fim);
     
     static int sinal(double nro);
};

#endif /* SANSAO_H_ */
