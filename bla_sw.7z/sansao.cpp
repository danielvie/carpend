/*
 * sansao.cpp
 *
 *  Created on: 08/12/2014
 *      Author: User
 */

#include "sansao.h"
#include <cstdio>

#define PI 3.1415926535897932384

double sansao::norma_v(struct vetor_xyz v) {
	double res = sqrt(v.x*v.x + v.y*v.y + v.z*v.z);

	return res;	
}

double sansao::dot(struct vetor_xyz v1, struct vetor_xyz v2) {
	double res = v1.x*v2.x + v1.y*v2.y + v1.z*v2.z;

	return res;	
}

struct vetor_xyz sansao::sub(struct vetor_xyz v1, struct vetor_xyz v2) {
	struct vetor_xyz res;
	
	res.x = v1.x - v2.x;
	res.y = v1.y - v2.y;
	res.z = v1.z - v2.z;

	return res;	
}

struct vetor_xyz sansao::add(struct vetor_xyz v1, struct vetor_xyz v2) {
	struct vetor_xyz res;
	
	res.x = v1.x + v2.x;
	res.y = v1.y + v2.y;
	res.z = v1.z + v2.z;

	return res;	
}

struct vetor_xyz sansao::mul(struct vetor_xyz V, double x) {
	struct vetor_xyz res;
	
	res.x = V.x*x;
	res.y = V.y*x;
	res.z = V.z*x;

	return res;	
}

struct vetor_xyz sansao::div(struct vetor_xyz V, double x) {
	struct vetor_xyz res;
	
	res.x = V.x/x;
	res.y = V.y/x;
	res.z = V.z/x;

	return res;	
}

struct vetor_xyz sansao::cross(struct vetor_xyz v1, struct vetor_xyz v2) {
	struct vetor_xyz res;

	res.x = v1.y*v2.z - v2.y*v1.z;
	res.y = v2.x*v1.z - v1.x*v2.z;
	res.z = v1.x*v2.y - v2.x*v1.y;
	return res;	
}

double sansao::ang_vetores(struct vetor_xyz v1, struct vetor_xyz v2) {
    
	// calculo valor do angulo
    double ang = acos(sansao::dot(v1, v2) / sansao::norma_v(v1) / sansao::norma_v(v2));

	// ajuste de sinal
	if (sansao::cross(v1,v2).z < 0.0) {
		ang = -ang;
	}

	return ang;
}

double sansao::prod_escalar(double *x, double *y) {
    double ret = (x[0] * y[0] + x[1] * y[1] + x[2] * y[2]);
    return ret;
}

// double sansao::norma(double *x){
// 	// retorna a norma do vetor x[3]
// 	double ret = sqrt(sansao::produtoEscalar(x,x));
// 	return ret;
// }

double sansao::prod_vetorial(double *x, double *y, int el){
	// calcula produto vetorial
	double res; // vetor resposta
	switch (el) {
		case 1:
			res = (x[1]*y[2] - x[2]*y[1]);
			break;
		case 2:
			res = (x[2]*y[0] - x[0]*y[2]);
			break;
		case 3:
			res = (x[0]*y[1] - x[1]*y[0]);
			break;
		default:
			res = 0;
			break;
	}
	return res;
}

int sansao::minimo(double *x, int tam){
	// encontra o valor minimo do vetor
	double aux = x[0];
	int cont = 0;

	for (int i = 0; i < tam; ++i) {
		if (x[i]<aux){
			aux = x[i];
			cont = i;
		}
	}
	return cont;
}

double sansao::arredonda(double x){
	// arredonda X
	double aux = (double)((int)x);
	double ret = (x - aux >= 0.5001)?(aux + 1):(aux);
	return ret;
}

double sansao::trunca(double x){
	// arredonda X
	double aux = (double)((int)x);
	double ret = aux;
	return ret;
}

double sansao::calc_azimute(struct vetor_xyz origem, struct vetor_xyz fim) {
	// declarando variaveis
	double azi;
	struct vetor_xyz v, n;

	// vetor origem -> fim
	v    = sansao::sub(fim, origem);
	v.z  = 0.0;

	// vetor norte
	n.x  = 0.0;
	n.y  = 1.0;
	n.z  = 0.0;

	// calculando angulo
	azi = acos(sansao::dot(v,n)/sansao::norma_v(n)/sansao::norma_v(v)) * 3200.0 / PI;
	
	// ajustando quadrante do angulo
	if (sansao::cross(v,n).z < 0.0) {
		azi = 6400 - azi;
	}

	// retorno funcao
	return azi;
}

int sansao::sinal(double nro){
	// encontrando sinal do nro
	// entra o double com o nro e retorna int com o sinal
	int ret = (nro >= 0) ? 1:-1;
	return ret;
}