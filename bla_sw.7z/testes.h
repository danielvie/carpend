/*
 * testes.h
 *
 *  Created on: 07/08/2015
 *      Author: avibras
 */

#ifndef TESTES_H_
#define TESTES_H_

#include "novaedt.h"
#include "imprimir.h"
#include <time.h>

int testeLancamentoSimples(novaEdt *nedt);
//void testeApontamento(novaEdt *nedt);
//int testeVentoIdentificacao(novaEdt *nedt);
//int testeLancamentoLeitura(novaEdt *nedt);
//void testeContaDoZe(void);
//void testeExtrapolar(novaEdt *nedt);
//void testeExtrapolar2(novaEdt *nedt);
//void testeFireFor(novaEdt *nedt);
//int testeLancamentoEdtData(novaEdt *nedt);
//int testeLancamentoEdtData2(novaEdt *nedt);
//int testeLancamentoEdtData3(novaEdt *nedt);
//int testeErroElevationTooHigh(novaEdt *nedt);
//int testeCalculoObservador(novaEdt *nedt);
//int testeTiroNominal(novaEdt *nedt);
//int testeTiroComVento(novaEdt *nedt);
//int tiroEdtData(novaEdt *nedt);

#endif /* TESTES_H_ */
