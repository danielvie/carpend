
/******************************************************************************
- TITULO       : novaedt.h
- PROPOSITO    : Arquivo com definicao da classe novaEdt.
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 02/10/2014 - Daniel Vieira
- MODIFICACOES : 12/02/2015 - Flavio Nogueira
					Implementacoes para utilizacao na DLL utilizada pela CCT
			   : 02/05/2016 - Flavio Nogueira
					Adicionado o foguete 40G
*******************************************************************************/

#ifndef NOVAEDT_H_
#define NOVAEDT_H_

#include <windows.h>
#include <time.h>
#include <direct.h>

#include "bradock.h"
#include "f_custo.h"
#include "asa047.hpp"
#include <stdio.h>

extern "C" {
	#include "Avibras.h"
}

#ifndef NULL
#define NULL   ((void *) 0)
#endif

#define LongSwap(value)	(((value) & 0x000000ff) << 24) | (((value) & 0x0000ff00) << 8) | (((value) & 0x00ff0000) >> 8) | (((value) & 0xff000000) >> 24)
#define TRUE 1
#define FALSE 0
#define P_32  0xEDB88320L

#define SS_09TS 1
#define SS_30   2
#define SS_40   3
#define SS_60   4
#define SS_80   5  
#define SS_40G  6

class novaEdt{
public:
	double tempoQueima;       	  			// TEMPO DE QUEIMA DO FOGUETE
	double tempoFimSimulacao; 	  			// TEMPO DE FIM DA SIMULACAO
	double posicaoFimDeQueima[3];    		// POSICAO DE FIM DE QUEIMA
	double velocidadeFimDeQueima[3]; 		// POSICAO DO FOGUETE NO FIM DA QUEIMA DO MOTOR
	double posicaoFimDeVoo[3];    			// POSICAO DO FOGUETE NO FIM DO VOO
	double posicaoImpacto[3];
	double pontoObservado[2];               // PONTO OBSERVADO
	double rangeMin;
	double rangeMax;

// PROPRIEDADES BASICAS

	double T;				  // GUARDANDO TEMPO DA SIMULACAO
	AV_STATE stState;         // ESTRUTURA DE ESTADOS DO FOGUETE
	AV_BDT bdt;         	  // VARIAVEL DE ENTRADA DE DADOS
	struct TEdtData edtData;  // ESTRUTURA DE DADOS DE LANCAMENTO
	struct TDDT DDTDLL; 	  // ESTRUTURA DE DADOS DO FOGUETE
	enum AV_RESULT ret; 	  // RETORNO DE VARIAVEL (AV_OK // AV_FAIL)

	// Hejec, Fusetime e apogeu sao atualizados sempre que algum metodo de voo eh
	// chamado.
	double Hejec;
	double Fusetime;
	double apogeu;	 // VALOR DO APOGEU
	double range_apogeu;

	double Vweth;
	double Vwnth;
	double Vweff;
	double Vwnff;

	int            crc_tab32_init;
	unsigned long  crc_tab32[256];

// METODOS DANIEL

	novaEdt( void );

	void ConfigEdt( int DDTType );

	struct TShot calcularTiro( void );
	struct TShot calcularTiro2( void );
	struct TShot calcularTiro2_semRange( void );
	struct TShot calcularTiroObservador( void );
	struct TRetMaxRange calcularAlcanceMaximo(void);
	void calcularAlcanceMinimo( void );

	void calcularVentoTH( void );
	void calcularVentoFF( void );

	struct TShot voarCompleto( void );
	struct TShot voarCompleto( double tempoFinal );
	struct TShot voarExtrapolando(condicaoInicial *inicio);

	void calcularCoordenadasEN( double *EN );
	double calcularDesvioAlcance( void );
	double calcularDesvioLateral( void );
	double calcularAlcance( void );
	
	void inicializar(condicaoInicial *inicio);
	struct TTelaEngenharia resetTelaEngenharia( void );
	void setTelaEngenharia( struct TTelaEngenharia telaEngenharia );

// METODOS DERSO

	void calcularMediaImpacto(double Norte_Pilotos[100],double Leste_Pilotos[100],double Altitude_Pilotos[100],int Pontos_Validos[100],int tam,double *Media_Pto_Imp);
	void tratarDadosRadar(double Tfq,double *Fim_de_queima,double *Pto_extrap,int *Erro);

// METODOS BASICOS

	void step();
	void Endianize(char *buf, int buflen);

	void init_crc32_tab( void );
	unsigned long update_crc_32( unsigned long crc, char c );
	unsigned long CRC32(char *buf, int buflen);
	struct TDDT SetDataDDT (int DDTType);      
	char * Rocket(int DDTType);

// METODOS FLAVIO

	void SetDebug (bool bType);
	bool GetDebug (void);

	void SetData (struct TEdtData loadData);
	void SetCntTrkData (int nValue);
	void SetExtrapolationStart(unsigned Value);

	void ConfiguraNEDT (void);

	void SetEdtDataReceived (bool bValue);
	bool GetEdtDataReceived (void);

	void SetTrackingDataReceived (bool bValue);
	bool GetTrackingDataReceived (void);

	void SetTrackingData (struct TTrackingResult *TrkData);
	struct TTrackingResult * GetTrackingData (void);
                                      
	void ImprimeResumoDadosVoo(void);

	void print_error(const char * msg);
	void print_debug(const char * msg, bool bTime);
	void print_debug_edtdata(const char * msg);
	void print_debug_trkdata(const char * msg);

	char * CurrentTime(void);
	char * CurrentDate(void); 
	char * CurrentTimePrint(void);

private:
	double Sigma_V[TRK_SIZE];
	struct TShot voar( condicaoInicial *inicio, double tempoFinal );
	struct TShot minimizaAlcance(double a, double b);
	struct TTelaEngenharia telaEngenharia;

	// FLAVIO
	struct TTrackingResult TrackingData;	// ESTRUTURA COM DADOS DO RASTREIO

	bool bEdtDataReceived;
	bool bTrackingDataReceived;

	unsigned ExtrapolationStart;			// VALOR DE INICIO DA ESTRAPOLACAO ENVIADO PELO RADAR
	int CntTrkData;							// NUMERO DE DADOS DO RASTREIO
	bool bDebug;

	char strOutDir[MAX_PATH];
};

#endif /* NOVAEDT_H_ */
