/*
 * configuraNEDT.h
 *
 *  Created on: 09/02/2015
 *      Author: User
 */

#ifndef CONFIGURANEDT_H_
#define CONFIGURANEDT_H_

#include "novaedt.h"

void configuraNEDT(novaEdt *nedt, struct TTrackingResult *rastreio, double *lancamento, double *ponteiroTabelaVento);

#endif /* CONFIGURANEDT_H_ */
