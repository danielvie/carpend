/*
 * lerAquivosTXT.h
 *
 *  Created on: 09/02/2015
 *      Author: User
 */

#ifndef LER_ARQUIVOS_TXT_H_
#define LER_ARQUIVOS_TXT_H_

int lerAquivosTXT(struct TTrackingResult *radarIN, int *foguete, double *Lanc, double *Tabela_VentoIN, int *CntTrkData);

#endif /* LER_ARQUIVOS_TXT_H_ */
