
/******************************************************************************
- TITULO       : Avibras.c
- PROPOSITO    : Utilizacao das funcoes da balistica baseado na versao do RAD FG3,
					para o calculo da extrapolacao.
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 12/02/2015 - Flavio Nogueira, Daniel Vieira, Anderson Millan
- MODIFICACOES : -
*******************************************************************************/

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

/*
 *  When on a windows platform, declare DLL_API
 */
#ifdef WIN32
#define DLL_API __declspec(dllexport)
#endif
#include "Avibras.h"
#ifdef DLL_API
#undef DLL_API
#endif

#ifdef FALSE
#undef FALSE
#endif
#ifdef TRUE
#undef TRUE
#endif
#define FALSE 0
#define TRUE 1

/*
 *  The following preprocessor define is needed when building the
 *  ballistic library as plugin.  In the non-plugin-case, a
 *  dummy value is used.
 */
#ifndef FG3CORE_BALLISTIC_PLUGIN_VERSION
#define FG3CORE_BALLISTIC_PLUGIN_VERSION "<not built as plugin>"
#endif

//#define STEP_VALUE	0.02
//#define STEP_FAST	0.02

#ifdef max
#undef max
#endif

#ifdef min
#undef min
#endif

#define max(a, b) (((a) > (b)) ? (a) : (b))
#define min(a, b) (((a) < (b)) ? (a) : (b))
#define sgn(a) ((a == 0 ) ? (0) : (((a < 0 ) ? (-1) : (1))))
#define CELKEL 273.15

#define SS_09TS 1
#define SS_30   2
#define SS_40   3
#define SS_60   4
#define SS_80   5 
#define SS_40G  6

#define PILOT_TARGET 0
#define MAXRANGE     1
#define CMDCALC      2
#define TRACKING     3

/* CRC */
#define                 P_32        0xEDB88320L

/* Endian */
#define WordSwap(value)			(((value) & 0x00ff) << 8) | (((value) & 0xff00) >> 8)
#define LongSwap(value)			(((value) & 0x000000ff) << 24) | (((value) & 0x0000ff00) << 8) | (((value) & 0x00ff0000) >> 8) | (((value) & 0xff000000) >> 24)
short __ENDIANESS_TEST_word = 0x0001;
char *__ENDIANESS_TEST_byte = (char *)&__ENDIANESS_TEST_word;
#define __BigEndian				(__ENDIANESS_TEST_byte[0]==0)

#pragma pack(1)


static const char *version_string = "Avibras-1.1.0";


struct ST_AV_RESULT
{
	int res;
	double tempoejec;
	int flagEjec;
	double tempo_teste;
};
typedef struct ST_AV_RESULT  st_AV_RESULT;


static void swapWords(double* x)
{
	unsigned* w = (unsigned *) x;

	const unsigned tmp = w[0];
	w[0] = w[1];
	w[1] = tmp;
}


#define LENGTH(A) (sizeof(A) / sizeof(A[0]))


static void trocaUn(struct TDDT *z) {
	int i, j;

	swapWords(&z->Mass);
	swapWords(&z->Propmass);
	swapWords(&z->Laul);
	swapWords(&z->Diaref);
	swapWords(&z->Ass);
	swapWords(&z->Pnom);
	swapWords(&z->Emp);
	swapWords(&z->Elevmax);
	swapWords(&z->Elev_tat);
	swapWords(&z->Elev_min);
	swapWords(&z->Vwmax);
	swapWords(&z->Cdadj);
	swapWords(&z->Cdadjsm);
	swapWords(&z->Fpon);

	for (i = 0; i < LENGTH(z->T_emp_step); ++i) {
		swapWords(&z->T_emp_step[i]);
	}
	for (i = 0; i < LENGTH(z->P_emp_tp); ++i) {
		for (j = 0; j < LENGTH(z->P_emp_tp[i]); ++j) {
			swapWords(&z->P_emp_tp[i][j]);
		}
	}
	for (i = 0; i < LENGTH(z->V0_el); ++i) {
		swapWords(&z->V0_el[i]);
		swapWords(&z->V0_tp[i]);
		swapWords(&z->T0_el[i]);
		swapWords(&z->T0_tp[i]);
	}
	for (i = 0; i < LENGTH(z->Hejec1); ++i) {
		swapWords(&z->Hejec1[i]);
		swapWords(&z->Hejec2[i]);
	}
	swapWords(&z->Delta_ejec);
	for (i = 0; i < LENGTH(z->Bwiwe); ++i) {
		swapWords(&z->Bwiwe[i]);
	}
	for (i = 0; i < LENGTH(z->Hmthph); ++i) {
		swapWords(&z->Hmthph[i]);
	}
	for (i = 0; i < LENGTH(z->Cwss); ++i) {
		swapWords(&z->Cwss[i]);
	}
	for (i = 0; i < LENGTH(z->Elcor); ++i) {
		for (j = 0; j < LENGTH(z->Elcor[i]); ++j) {
			swapWords(&z->Elcor[i][j]);
			swapWords(&z->Azcor[i][j]);
			swapWords(&z->Velcor[i][j]);
		}
	}
	for (i = 0; i < LENGTH(z->Elbas); ++i) {
		swapWords(&z->Elbas[i]);
		swapWords(&z->Azbas[i]);
		swapWords(&z->Velbas[i]);
		swapWords(&z->Fuzecor1[i]);
		swapWords(&z->Fuzecor2[i]);
	}

	swapWords(&z->El_to);
}

static void trocaDos(struct TEdtData* z)
{
	int i;

	swapWords(&z->Latitude);

	for (i = 0; i < LENGTH(z->Vwmetcm); ++i) {
		swapWords(&z->Vwmetcm[i]);
		swapWords(&z->Azwmetcm[i]);
		swapWords(&z->Tent[i]);
		swapWords(&z->Pent[i]);
	}

	swapWords(&z->Alt_met);
	swapWords(&z->Azwcor);
	swapWords(&z->T0);
	swapWords(&z->P0);
	swapWords(&z->Proptemp);
	swapWords(&z->Vws);
	swapWords(&z->Azws);
	swapWords(&z->Altfg);
	swapWords(&z->RefDir);
	swapWords(&z->Elau);
	swapWords(&z->Nlau);
	swapWords(&z->Alt_launch);
	swapWords(&z->Etarg);
	swapWords(&z->Ntarg);
	swapWords(&z->Altarg);
	swapWords(&z->Azim_tiro);
	swapWords(&z->Elev_tiro);
	swapWords(&z->Fusetime_input);
	swapWords(&z->Vweth);
	swapWords(&z->Vwnth);
	swapWords(&z->Vweff);
	swapWords(&z->Vwnff);
	swapWords(&z->Elev_max);
}



/*------FUN��ES---------------------------------------------------------------*/
static void 	Init(struct TDDT DDT, double tempo);
static void	    Init_met(double Bx, double Hpmax, struct TDDT DDT);
static void 	Metcm(double Height, double *pDensity, double *pVsound, double *pBal_windx, double *pBal_windy, double *pPressure);
static void 	Thrust_mass(double Time, double *pAcceler, double *pBal_coef, double Pa, struct TDDT DDT);
static void 	Meteo(double Zabs, double *pDens, double *pTemp);
static void 	Ru_ku_ny(struct TDDT DDT);
static void 	Diff_equ(double Ti, double Qi[4], double Vi[4], struct TDDT DDT);
static double 	FNBux(double Coef[4][10], double En, double Vx, double Vy);
static double 	FNCwff(double Machnr, struct TDDT DDT);
static double 	FNCwsec(double Machnr, struct TDDT DDT);
static double 	FNFzcor(double Qu[4]);
static void 	SetData (struct TEdtData EdtData, struct TTelaEngenharia telaEngenharia);
static unsigned long CRC32(char *buf, int buflen);
static void Endianize(char *buf, int buflen);


static void 	av_step_OVER(AV_STATE *av_state, int *ret, st_AV_RESULT *stRes);

/* COMENTADO POR NAO SER USADO
static void avb_step(AV_STATE *av_state, st_AV_RESULT *stRes);
*/

/*++++++FUN��ES+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/*------CONSTANTES------------------------------------------------------------*/
static const double ISA_ICAO76_H[] = {0, 11, 20, 32, 47, 51, 71, 84.852, 89.716};
static const double ISA_ICAO76_L[] = {-6.5, 0, 1, 2.8, 0, -2.8, -2.0055, 0, 0};
static const double Rad1 = 57.29577951;
static const double Rad1mil = 1018.5916;
static const double Grad1mil = .05625;
static const double Knots = .514444;
static const double Pi = 3.1415927;
static const double Earth_rad = 6366000.0;
static const double G = 9.80665;
static const double Eangvel2 = 1.454441E-4;
static const double Gasconst = 287.0429;
static const double Soundconst = 20.046;
static const int Nlay = 40;
static const double Empty = 1.E+38;
static const double Hlay_end[41] =
  {
	0     , 200   , 500   , 1000  , 1500  , 2000  , 2500  , 3000  , 3500  ,
	4000  , 4500  , 5000  , 6000  , 7000  , 8000  , 9000  , 10000 , 11000 ,
	12000 , 13000 ,14000  , 15000 , 16000 , 17000 , 18000 , 19000 , 20000 ,
	21000 , 22000 , 23000 , 24000 , 25000 , 26000 , 27000 , 28000 , 29000 ,
	30000 , 31000 , 32000 , 33000 , 34000
  };


static const int Metodo = 0, Imet = 0;

/* COMENTADO POR NAO SER USADO
static const int Dazlim = 5;
*/

/*++++++CONSTANTES++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/*------VARIAVEIS-------------------------------------------------------------*/

static int 	Metcm_included, Sec_bal, Natm;
static double 	Azimuth, Elevation;
static double 	Proptemp, T0, P0, Vws, Azws, Latitude, Azwcor;
static double 	Wx_th, Wy_th, Wx_ff, Wy_ff, Thrust_factor, Cda;
static double 	Altarg, Altfg, Alt_launch, Alt_met;
static double 	Vwmetcm[41], Azwmetcm[41], Tent[41], Pent[41];
static double 	Fusetime_input;


static int 	N;
static double 	Q[4], Qa[4], V[4], Va[4], T, Ta, Zcor, Zcora;
static double 	Fuse_time, Hejec_out, Secsteps, Delta_t;

static int 		Secballistics, Thrustphase;
static double 	Thrustime, Thrust0, Steptime;
static double 	Tthrust[21], Thrh[21], Rmass[21], Rtot, Hejec;
static double 	Tubetime, Balcoef0, B1, B2, B3, Refarea2;
static int 		Thrusteps, Interpol, Tubesteps;
static double 	Cwk, Cd_fac_eng;
static double 	Cdsm_fac_eng, Thrust_fac_eng, V0;
static double 	Azcorw, Elcorw, Velcorw, Corbasa, Corbase, Corbast, Corbasv;

static double 	Vwxp, Vwyp;
static int 		Icatm;
static double 	Hcam[41], Vwxc[41], Vwyc[41], Tatm[41], Datm[41];
static double 	Hbat[9], Lbat[9], Tbat[9], Dbat[9];

static double 	Delta_x_e_i, Delta_y_e_i, Delta_z_e_i;
static double 	Delta_vx_e_i, Delta_vy_e_i, Delta_vz_e_i;
static double 	Cd_fac_e_i, Cdsm_fac_e_i, Thrust_fac_e_i;
static double 	Tubetime_e_i, Delta_ejec_e_i, Mass_e_i,Propmass_e_i;
static double 	Hejec_e_i, Cwss_e_i[41];

static double 	F[4];
static double 	Mach, Cw, Vrel, Momass;

static double Elau, Nlau, Etarg, Ntarg, Azim_tiro, RefDir, Elev_tiro, T_ext;
static double Vweth, Vwnth, Vweff, Vwnff;

static int              crc_tab32_init = FALSE;
static unsigned long    crc_tab32[256];

static struct TDDT DDTDLL;

static int step=0;

/*++++++VARIAVEIS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

const char *av_version(void)
{
	return version_string;
}

const char *av_plugin_version(void)
{
	return FG3CORE_BALLISTIC_PLUGIN_VERSION;
}

void av_init_bdt(AV_BDT *av_bdt, enum AV_RESULT *ret, struct TTelaEngenharia telaEngenharia)
{
	struct TEdtData EdtData;
	unsigned long crc;

//	printf("version = 8, bdt length = %d, TDDT = %d, TedtData = %d\n",
//			av_bdt->LENGTH,
//			(int)sizeof(struct TDDT),
//			(int)sizeof(struct TEdtData));
	step = 1;

	/*
	 *  the ballistic data is transferred in a little-endian representation of
	 *  big-endian-words.  i.e every word (32-bit) itself is transmitted in big-endian
	 *  but the words in a multi-word block (like IEEE-754 doubles) are arranged
	 *  in little-endian order (from least-significant to most-significant word).
	 *
	 *  let's say we have a IEEE-754 double with bytes B7 - B0, B7 being the most
	 *  significant byte and B0 the least significant byte.  The bytes are transferred
	 *  in the following order:
	 *
	 *  B3 B2 B1 B0 B7 B6 B5 B4
	 */

	/* first convert words to little-endian representation to compute the CRC. */
	Endianize(av_bdt->RAW_DATA, sizeof(struct TDDT)+sizeof(struct TEdtData) + 4);

	/* one of the nice properties of CRCs is that when you append the CRC of the data
	 * at the end of that data, then computing the CRC of this extended data (original
	 * data + CRC) will achieve zero if the CRC is correct.
	 *
	 * that's why here we compute the CRC of the whole ballistic data plus the 4 bytes
	 * CRC at the end of the ballistic data and later on test if the result is zero.
	 */
	crc=CRC32( av_bdt->RAW_DATA, sizeof(struct TDDT)+sizeof(struct TEdtData) + 4 );

	if (__BigEndian) {
		/* if we are on a big endian platform, convert words back to big-endian */
		Endianize(av_bdt->RAW_DATA, sizeof(struct TDDT)+sizeof(struct TEdtData) + 4);
	}

	if(crc==0) {
		memcpy(&DDTDLL, av_bdt->RAW_DATA, sizeof(struct TDDT));
		memcpy(&EdtData, av_bdt->RAW_DATA + sizeof(struct TDDT), sizeof(struct TEdtData));
		if (__BigEndian) {
			/*  on a big endian platform, convert multi-word data from little-endian to big-endian */
			trocaUn(&DDTDLL);
			trocaDos(&EdtData);
		}

		Elevation 	= EdtData.Elev_tiro*Grad1mil;
		Azimuth		= EdtData.Azim_tiro*Grad1mil;
		SetData(EdtData, telaEngenharia);
		*ret=AV_OK;
	} else {
		printf("av_init_bdt:  bad crc\n");
		*ret=AV_FAILED;
	}
}


void av_init(AV_STATE *av_state, condicaoInicial *inicio, enum AV_RESULT *ret) {
	//double tempo = 38.000000;
	//double q[3] = {-12.679018, 20125.530605, 3404.089551};
	//double v[3] = {-0.089900, 283.444443, -106.815463};

    if(step < 1) {
		*ret = AV_FAILED;
		return;
	}
	else {
		step = 2;
	}

	Zcora = Zcor;

	if (inicio->extrapolar == FALSE)
		inicio->tempo = 0;
	Init(DDTDLL,inicio->tempo);

	if (inicio->extrapolar == TRUE){
		Q[1] = inicio->pos[0]; Q[2] = inicio->pos[1]; Q[3] = inicio->pos[2];
		V[1] = inicio->vel[0]; V[2] = inicio->vel[1]; V[3] = inicio->vel[2];
	}

	// MUDAR INICIO
	av_state->XN  = Q[1];
	av_state->YN  = Q[2];
	av_state->ZN  = Q[3];
	av_state->VXN = V[1];
	av_state->VYN = V[2];
	av_state->VZN = V[3];

	av_state->XO  = Q[1];
	av_state->YO  = Q[2];
	av_state->ZO  = Q[3];
	av_state->VXO = V[1];
	av_state->VYO = V[2];
	av_state->VZO = V[3];

	av_state->ZN_SPH = Zcor;
	av_state->ZO_SPH = Zcor;

	av_state->MISSILE_OUT_OF_TUBE = 0;

	*ret = AV_OK;
}

void av_step(AV_STATE *av_state, enum AV_RESULT *ret, double *Fuse_o, double *Hejec_o) {
	int iret = 0;
	st_AV_RESULT stret = {0};

	*ret = 0;
	av_step_OVER(av_state, &iret, &stret);
	*ret = iret;
	*Fuse_o  = Fuse_time;
	*Hejec_o = Hejec;
}

// FUNCAO DANIEL
double retornaTempo () {
	return T;
}

void escreveTempo (double tempo) {
	T = tempo;
}
// FIM FUNCAO DANIEL



/* COMENTADO PORQUE NAO ESTAVA SENDO USADA
static void avb_step(AV_STATE *av_state, st_AV_RESULT *stRes)
{
	int ret;

	memset(stRes, 0x00, sizeof(st_AV_RESULT));
	av_step_OVER(av_state, &ret, stRes);
}
*/

// alteracoes daniel para ver o fuse_time

static void av_step_OVER(AV_STATE *av_state, int *ret, st_AV_RESULT *stRes) {
	int I;
	double St, Bux, Vez, Aux;
	double 	AuxTimer;
	double  Tant;

	if(step < 2) {
		*ret = 1;
		stRes->res = 1;
		return;
	}

	Q[1] = av_state->XO;
	Q[2] = av_state->YO;
	Q[3] = av_state->ZO;

	V[1] = av_state->VXO;
	V[2] = av_state->VYO;
	V[3] = av_state->VZO;

	Zcor = av_state->ZO_SPH;
/*	av_state->FLIGHT_TIMER_O = av_state->FLIGHT_TIMER_N;*/

	AuxTimer = 0.02;/*-(T - av_state->FLIGHT_TIMER_N);*/

	St	= Steptime;
	T	= N * Steptime;
	if(N <= Thrusteps) {
		Thrustphase = 1;
	}
	else {
		Thrustphase=0;
	}

	Ta = T;
	for(I = 1; I <= 3; I++) {
		Qa[I] = Q[I];
	}

	for(I = 1; I <= 3; I++) {
		Va[I] = V[I];
	}

	Zcora 	= Zcor;
	Delta_t = St;
	if(N >= Tubesteps) {
		av_state->MISSILE_OUT_OF_TUBE = 1;
		if(N == Tubesteps) {
			T = Tubetime;
			Delta_t = (N + 1) * St - Tubetime;
		}

		if(N == Thrusteps) {
			Delta_t = Thrustime - N * St;
			Ru_ku_ny(DDTDLL);
			T = Thrustime;
			Delta_t = (N + 1) * St - Thrustime;
			Thrustphase = 0;
		}
		Ru_ku_ny(DDTDLL);
		T = T + Delta_t;

		if((Sec_bal != 0) && (!Secballistics)) {
			Bux = Altarg - Alt_launch;
			if(Fusetime_input == Empty) {
				if((Zcor <= (Bux + Hejec)) && (Zcora > (Bux + Hejec))) {
					Tant = T;
					Delta_t = St;
					Vez = 0;
					do {
						Aux = (Zcora - Bux - Hejec) / (Zcora - Zcor);
						Fuse_time = Ta + Delta_t * Aux;
						Delta_t = Fuse_time - Ta;
						T = Ta;

						for(I = 1; I <= 3; I++)
							Q[I] = Qa[I];

						for(I = 1; I <= 3; I++)
							V[I] = Va[I];

						Zcor = Zcora;
						Ru_ku_ny(DDTDLL);
						Vez++;
					} while(!((fabs(Zcor - (Bux + Hejec)) < .1) || (Vez > 10)));
					T = Fuse_time;
					Secsteps = N + 1;
					Secballistics = 1;
					Fuse_time = Fuse_time - DDTDLL.Delta_ejec;

					Delta_t = Tant - T;
					Ru_ku_ny(DDTDLL);
					T = T + Delta_t;
					stRes->flagEjec = 1;
				}
			}
			else {
				if(T >= (Fusetime_input + DDTDLL.Delta_ejec)) {
					Tant = T;
					Delta_t = Fusetime_input + DDTDLL.Delta_ejec - Ta;
					T = Ta;

					for(I = 1; I <= 3; I++)
						Q[I] = Qa[I];

					for(I = 1; I <= 3; I++)
						V[I] = Va[I];

					Zcor = Zcora;
					Ru_ku_ny(DDTDLL);
					T = Fusetime_input + DDTDLL.Delta_ejec;

					if(Zcor > Bux) {
						Secsteps=N+1;
						Secballistics=1;
						Hejec_out=Zcor-Bux;
					}
					Delta_t = Tant - T;
					Ru_ku_ny(DDTDLL);
					T = T + Delta_t;
					stRes->flagEjec = 1;
				}
			}
		}
	}
	else
	{
		av_state->MISSILE_OUT_OF_TUBE = 0;
		T =T + Delta_t;
	}
	N = N + 1;

	av_state->XN = Q[1];
	av_state->YN = Q[2];
	av_state->ZN = Q[3];
	av_state->VXN = V[1];
	av_state->VYN = V[2];
	av_state->VZN = V[3];
	av_state->ZN_SPH = Zcor;

	av_state->FLIGHT_TIMER_N = T - AuxTimer;

	#if defined(AVDEBUG)
	stream = fopen("Debug.txt", "a+");
	fprintf(stream, "%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%d\n",
					   T, av_state->XN, av_state->YN, av_state->ZN, av_state->VXN, av_state->VYN, av_state->VZN, av_state->MISSIBLE_OUT_OF_TUBE);
	fclose(stream);
	#endif

	stRes->tempo_teste = T;

	// mostrando fuse_time (alteracao daniel)
//	if(*Fuse_out != Fuse_time){
//		printf("hejec_out: %.2f\n",Hejec_out);
//		printf("hejec: %.2f\n",Hejec);
//		printf("sec_bal: %d\nfuse_time: %.3lf\n",Sec_bal,*Fuse_out);
//		printf("\n");
//		*Fuse_out = Fuse_time;
//	}
	// ----
}

static void Init(struct TDDT DDT, double tempo)
{
	int I;
	double Elr, El, Elcort, Al, Azcort, Hejec1n, Hejec2n, Tp25;
	double En, Hpmax, Bx, Ritot[21];
	double Vx, Vy, Cosel;

	Steptime = STEP_VALUE;
	Elr = Elevation / Rad1;

	/*------STARTVALUES-----------------------------------------------------------*/
	Tp25 = Proptemp - 25;
	Thrust0 = DDT.Emp * (1 + Thrust_factor);

	for(I = 1; I <= DDT.N_points; I++)
	{
		Tthrust[I] = DDT.T_emp_step[I] * Steptime *(.25/Steptime);
		Thrh[I] = 1 + DDT.P_emp_tp[2][I] * Tp25 + DDT.P_emp_tp[3][I] * Tp25 * Tp25;
		Thrh[I] = DDT.P_emp_tp[1][I] * Thrh[I];
		Thrh[I] = max(Thrh[I], DDT.P_emp_tp[4][I]);
		Thrh[I] = min(Thrh[I], DDT.P_emp_tp[5][I]);
	}

	En = Elevation / DDT.Elevmax;
	V0 = (DDT.V0_el[1] + En * (DDT.V0_el[2] + En*DDT.V0_el[3]));
	V0 = V0 * (DDT.V0_tp[1] + Tp25 * (DDT.V0_tp[2] + Tp25 * DDT.V0_tp[3]));
	Tubetime = (DDT.T0_el[1] + (En * (DDT.T0_el[2] + (En * DDT.T0_el[3]))));
	Tubetime = Tubetime * (DDT.T0_tp[1] + (Tp25 * (DDT.T0_tp[2] + (Tp25 * DDT.T0_tp[3]))));
	Hejec1n = DDT.Hejec1[1] + DDT.Hejec1[2] * Elevation + DDT.Hejec1[3] * pow(Elevation, 2);
	Hejec1n = max(Hejec1n, DDT.Hejec1[4]);
	Hejec1n = min(Hejec1n, DDT.Hejec1[5]);
	Hejec2n = DDT.Hejec2[1] + DDT.Hejec2[2] * Elevation + DDT.Hejec2[3] * pow(Elevation, 2);
	Hejec2n = max(Hejec2n, DDT.Hejec2[4]);
	Hejec2n = min(Hejec2n, DDT.Hejec2[5]);

	Thrustime = Tthrust[DDT.N_points];
	Rtot = 0;
	Ritot[1] = 0;

	for(I = 2; I <= DDT.N_points; I++) {
		Ritot[I] = (Thrh[I] + Thrh[I-1]) * (Tthrust[I] - Tthrust[I-1]) / 2;
		Rtot = Rtot + Ritot[I];
	}
	Rmass[1] = 1;

	for(I = 2; I <= DDT.N_points; I++)	{
		Rmass[I] = Rmass[I-1] - Ritot[I] / Rtot;
	}
	Hpmax = ((DDT.Hmthph[4] * En + DDT.Hmthph[3]) * En + DDT.Hmthph[2]) * En + DDT.Hmthph[1];
	Bx = (((DDT.Bwiwe[6] * En + DDT.Bwiwe[5]) * En + DDT.Bwiwe[4]) * En + DDT.Bwiwe[3]) * En + DDT.Bwiwe[2];
	Bx = (Bx * En + DDT.Bwiwe[1]);
	if(Bx > 0)
		Bx = 0;

	/*++++++STARTVALUES+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	Refarea2 = DDT.Diaref * DDT.Diaref * Pi / 8;
	T = tempo;
	Init_met(Bx, Hpmax, DDT);

	/*------CORRVALUES------------------------------------------------------------*/
	Vx = (Vwxp + Wx_th) / DDT.Vwmax;
	Vy = (Vwyp + Wy_th) / DDT.Vwmax;
	Cosel = cos(Elr);

	Elcorw = 360 * FNBux(DDT.Elcor, En, Vx, Vy) / Cosel;
	Azcorw = 360 * FNBux(DDT.Azcor, En, Vx, Vy) / Cosel;
	Velcorw = FNBux(DDT.Velcor, En, Vx, Vy) / Cosel;
	Corbast = DDT.El_to * Cosel;
	Corbase = DDT.Elbas[1] + Cosel * (DDT.Elbas[2] + Cosel * DDT.Elbas[3]);
	Corbasa = DDT.Azbas[1] + En * (DDT.Azbas[2] + En * DDT.Azbas[3]);
	Corbasv = DDT.Velbas[1] + En * (DDT.Velbas[2] + En * DDT.Velbas[3]);

	Elcort = Corbase + Corbast + Elcorw;
	Azcort= Corbasa + Azcorw;
	Cwk = 1 + Corbasv + Velcorw;

	/*++++++CORRVALUES++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	El = (Elevation + Elcort) / Rad1;
	Al = (Azimuth + Azcort) / Rad1;
	B1 = Eangvel2 * cos(Latitude / Rad1) * cos(Al);
	B2 = Eangvel2 * cos(Latitude / Rad1) * sin(Al);
	B3 = Eangvel2 * sin(Latitude / Rad1);
	V[1] = V0 * cos(El) * sin(Azcort / Rad1);
	V[2] = V0 * cos(El) * cos(Azcort / Rad1);
	V[3] = V0 * sin(El);

	/*
	if(V[3] < 0)
		V[3] = V[3];
	*/

	Q[1] = 0;
	Q[2] = DDT.Laul * cos(Elr);
	Q[3] = DDT.Laul * sin(Elr);

	Cd_fac_eng = 1;
	Cdsm_fac_eng = 1;
	Thrust_fac_eng = 1;
	N = T/Steptime;
	Fuse_time = 0;
	Hejec_out = 0;
	Interpol = 1;
	Secballistics = 0;

	switch(Sec_bal)	{
		case 0: {
			Hejec=0;
			break;
		}
		case 1: {
			Hejec = Hejec1n;
			break;
		}
		case 2: {
			Hejec = Hejec2n;
			break;
		}
	}

	if(Delta_x_e_i != Empty)
		Q[1] = Q[1] + Delta_x_e_i;

	if(Delta_y_e_i != Empty)
		Q[2] = Q[2] + Delta_y_e_i;

	if(Delta_z_e_i != Empty)
		Q[3] = Q[3] + Delta_z_e_i;

	if(Delta_vx_e_i != Empty)
		V[1] = V[1] + Delta_vx_e_i;

	if(Delta_vy_e_i != Empty)
		V[2] = V[2] + Delta_vy_e_i;

	if(Delta_vz_e_i != Empty)
		V[3] = V[3] + Delta_vz_e_i;

	if(Cd_fac_e_i != Empty)
		Cd_fac_eng = Cd_fac_e_i;

	if(Cdsm_fac_e_i != Empty)
		Cdsm_fac_eng = Cdsm_fac_e_i;

	if (Thrust_fac_e_i != Empty)
		Thrust_fac_eng = Thrust_fac_e_i;

	if(Tubetime_e_i != Empty)
		Tubetime = Tubetime_e_i;

	if(Delta_ejec_e_i != Empty)
		DDT.Delta_ejec = Delta_ejec_e_i;

	if(Mass_e_i != Empty)
		DDT.Mass = Mass_e_i;

	if(Propmass_e_i != Empty)
		DDT.Propmass = Propmass_e_i;

	if(Hejec_e_i != Empty)
		Hejec = Hejec_e_i;

	for(I = 0; I <= 40; I++) {
		if(Cwss_e_i[I] != Empty)
			DDT.Cwss[I] = Cwss_e_i[I];
	}

	Balcoef0 = Refarea2 / (DDT.Mass - DDT.Propmass);
	Thrusteps = (int)(Thrustime / Steptime + .001);
	Tubesteps = (int)(Tubetime / Steptime + .001);

	Secsteps = (int)((1000 * .25 / STEP_VALUE) / Steptime);
	Zcor = Q[3];
}

static void  Init_met(double Bx, double Hpmax, struct TDDT DDT) {
	int 	I, Ind1, Indn, Ibat;
	double 	Aux, Vwxs, Vwys, Ax, Dh1;
	double 	S1, S2;
	double 	Seatemp,Seadens;

	Indn = 0;

	if(Imet) {
		/*--------------NAO PERTENCE AO SOFTWARE DA EDT-------------------------------*/
	}
	else {
		for(I = 0; I <= 8; I++) {
			Hbat[I] = ISA_ICAO76_H[I] * 1000;		/* Km -> m */
			Lbat[I] = ISA_ICAO76_L[I] / 1000;		/* Km -> m */
		}
	}

	/*------PONDERACAO DO VENTO DE SUPERFICIE-------------------------------------*/
	Icatm 	= 0;
	Vwyp 	= 0;
	Vwxp	= 0;
	Aux		= Azws / Rad1mil - Azimuth / Rad1;
	Vwxs 	= -Vws * sin(Aux) * Knots;
	Vwys	= -Vws * cos(Aux) * Knots;
	Ax		= (Hlay_end[1]) / Hpmax;

	if((Ax < 0) || (Ax > 1))
		Ax	= 1;

	S2 = (2 - Bx * Ax - sqrt((Bx * Bx - 4) * Ax * Ax + (8 - 4 * Bx) * Ax)) / 2;
	Vwxp = Vwxp + (1 - S2) * DDT.Fpon * Vwxs;
	Vwyp = Vwyp + (1 - S2) * DDT.Fpon * Vwys;

	if(Metcm_included && (Natm > 0)) {
		/*--------------ALTITUDES DE FIM DE CAMADA------------------------------------*/
		for(I = 0; I <= Nlay; I++) {
			Hcam[I] = Hlay_end[I] + Alt_met;
		}
		/*--------------DECOMPOSICAO DO VENTO, T E D----------------------------------*/

		if(Azwcor == Empty)
			Azwcor=0;

		for(I = 0; I <= Natm; I++) {
			Aux = Azwmetcm[I] / Rad1mil - Azimuth / Rad1 - Azwcor / Rad1;
			Vwxc[I] = -Vwmetcm[I] * sin(Aux) * Knots;
			Vwyc[I] = -Vwmetcm[I] * cos(Aux) * Knots;
			Tatm[I] = Tent[I];
			Datm[I] = 100 * Pent[I] / (Gasconst * Tent[I]);
		}

		/*--------------PONDERACAO DE VENTOS------------------------------------------*/
		if((((Alt_launch + Hlay_end[1]) >= Hcam[0]) && ((Alt_launch + Hlay_end[1]) < Hcam[Natm])) || (((Alt_launch + Hpmax) > Hcam[0]) && ((Alt_launch + Hpmax) <= Hcam[Natm])))
		{
			if((Hlay_end[1]) < Hpmax)
			{
				Ind1 = 0;
				for(I = 0; I <= Natm; I++)
				{
					if(Hcam[I] < (Alt_launch + Hlay_end[1]))
						Ind1 = I;

					if(Hcam[I] <= (Alt_launch + Hpmax))
						Indn = I + 1;
				}

				if(Ind1 <= Natm)
				{
					if(Indn > Natm)
						Indn = Natm;

					for(I = Ind1; I <= (Indn - 1); I++)
					{
						Ax = (Hcam[I] - Alt_launch) / Hpmax;

						if(I == Ind1)
							Ax = Hlay_end[1] / Hpmax;

						S1 = sqrt((Bx * Bx - 4) * Ax * Ax + (8 - 4 * Bx) * Ax);
						S1 = (2 - Bx * Ax - S1) / 2;
						Ax = (Hcam[I+1] - Alt_launch) / Hpmax;

						if(Ax > 1)
							Ax = 1;

						S2 = sqrt((Bx * Bx - 4) * Ax * Ax + (8 - 4 * Bx) * Ax);
						S2 = (2 - Bx * Ax - S2) / 2;
						Vwxp = Vwxp + (S1 - S2) * Vwxc[I+1];
						Vwyp = Vwyp + (S1 - S2) * Vwyc[I+1];
					}
				}
			}
		}

		/*--------------REDEF. HCAM PARA MEIO DE CAM.---------------------------------*/
		for(I = Nlay; I >= 1; I--)
		{
			Hcam[I]=(Hcam[I]+Hcam[I-1])/2;
		}

		/*--------------CALCULO DAS CONDICOES AO N.M. COM BASE NA ULTIMA LINHA DA METCM----
		----------------DETERM. DA 1a. INFLEXAO ABAIXO DA ALTIT. DA ULTIMA LINHA ENTRADA-*/
		Ibat = 8;

		while(Hbat[Ibat] > Hcam[Natm])
		{
			Ibat = Ibat - 1;
		}

		/*--------------DETERM. DA DENS.,TEMP. PARA A INFLEXAO ACIMA DETERMINADA------*/
		Dh1 = Hcam[Natm] - Hbat[Ibat];
		Tbat[Ibat] = Tatm[Natm] - Lbat[Ibat] * Dh1;

		if(Lbat[Ibat] == 0)
		{
			Dbat[Ibat] = Datm[Natm] * exp(G / Gasconst * Dh1 / Tatm[Natm]);
		}
		else
		{
			Aux = 1 + G / Gasconst / Lbat[Ibat];
			Dbat[Ibat] = Datm[Natm] * pow((Tatm[Natm] / Tbat[Ibat]), Aux);
		}

		/*--------------DETERMINACAO DAS CONDICOES DE N.M. POR RECORRENCIA------------*/
		for(I = Ibat; I >= 1; I--)
		{
			Dh1 = Hbat[I] - Hbat[I-1];
			Tbat[I-1] = Tbat[I] - Lbat[I-1] * Dh1;
			if(Lbat[I-1] == 0)
			{
				Dbat[I-1] = Dbat[I] * exp(G / Gasconst * Dh1 / Tbat[I]);
			}
			else
			{
				Aux = 1 + G / Gasconst / Lbat[I-1];
				Dbat[I-1] = Dbat[I] * pow((Tbat[I] / Tbat[I-1]), Aux);
			}
		}

		Seatemp = Tbat[0];
		Seadens = Dbat[0];

		/*--------------DETERMINACAO DO INDICE DA CAMADA INICIAL DA METCM-------------*/
		while((Alt_launch > Hcam[Icatm+1]) && (Icatm < (Natm-1)))
		{
			Icatm = Icatm + 1;
		}
	}
	else
	{
		/*--------------CALCULO DAS CONDICOES AO NIVEL DO MAR COM BASE NOS DADOS DE SUP.*/
		Seatemp = T0 + .0065 * Altfg;
		Seadens = P0 * 100 / Gasconst / T0;
		Seadens = Seadens * pow((T0 / Seatemp), (-4.2561));
	}

	/*--------------INICIALIZACAO DOS VETORES DE DENS. E TEMP.--------------------*/
	Tbat[0] = Seatemp;
	Dbat[0] = Seadens;

	for(I = 1; I <= 8; I++)
	{
		Dh1 = Hbat[I] - Hbat[I-1];
		Tbat[I] = Tbat[I-1] + Lbat[I-1] * Dh1;

		if (Lbat[I-1]==0)
		{
			Dbat[I] = Dbat[I-1] * exp(-G / Gasconst * Dh1 / Tbat[I]);
		}
		else
		{
			Aux = -1 - (G / (Gasconst * Lbat[I-1]));
			Dbat[I] = Dbat[I-1] * pow((Tbat[I] / Tbat[I-1]), Aux);
		}
	}
}


static void Metcm(double Height, double *pDensity, double *pVsound, double *pBal_windx, double *pBal_windy, double *pPressure)
{
	double Aux, Aux1;
	double Density, Vsound, Bal_windx, Bal_windy, Pressure, Temperature;

	Density   = *pDensity;
	Vsound    = *pVsound;
	Bal_windx = *pBal_windx;
	Bal_windy = *pBal_windy;
	Pressure  = *pPressure;

	if((!Metcm_included) || (!Natm))
	{
		Meteo(Height, &Density, &Temperature);
		Bal_windy = 0;
		Bal_windx = 0;
	}
	else
	{
		/*--------------INTERPOLA DADOS DE T,RO,VWX,VWY NA TABELA METCM ENTRADA-------*/
		if((Height <= Hcam[Natm]) && (Height > Hcam[0]))
		{
			while(Height > Hcam[Icatm+1])
			{
				Icatm = Icatm + 1;
			}

			while(Height < Hcam[Icatm])
			{
				Icatm = Icatm - 1;
			}

			Aux = (Height - Hcam[Icatm]) / (Hcam[Icatm + 1] - Hcam[Icatm]);
			Bal_windx = Vwxc[Icatm] + Aux * (Vwxc[Icatm + 1] - Vwxc[Icatm]);
			Bal_windy = Vwyc[Icatm] + Aux * (Vwyc[Icatm + 1] - Vwyc[Icatm]);
			Temperature = Tatm[Icatm] + Aux * (Tatm[Icatm + 1] - Tatm[Icatm]);
			Density = Datm[Icatm] + Aux * (Datm[Icatm + 1] - Datm[Icatm]);
		}
		else
		{
			/*----------------------EXTRAPOLA ACIMA DA METCM ENTRADA ATRAVES DO MODELO ICAO-*/
			if(Height > Hcam[Natm])
			{
				Meteo(Height, &Density, &Temperature);
				Bal_windx = Vwxc[Natm];
				Bal_windy = Vwyc[Natm];
			}

			 /*----------------------EXTRAPOLA ABAIXO DA METCM ENTRADA ATRAVES DO MODELO ICAO-*/
			if(Height < Hcam[0])
			{
				Temperature = Tatm[0] + Lbat[0] * (Height - Hcam[0]);
				Density = Datm[0] * pow((Tatm[0] / Temperature), (-4.2561));
				Bal_windx = Vwxc[0];
				Bal_windy = Vwyc[0];
			}
		}
	}
	Pressure = Gasconst * Density * Temperature;
  	Vsound = Soundconst * sqrt(Temperature);

	/*------MODELO DE VENTO CRESCENTE COM A ALTURA--------------------------------*/
	if(Metodo == 0)
	{
		/*--------------NAO PERTENCE AO SOFTWARE DA EDT-------------------------------*/
		if(Thrustphase)
		{
			Bal_windx = Bal_windx + Wx_th;
			Bal_windy = Bal_windy + Wy_th;
		}
		else
		{
			if(!Secballistics)
			{
				Bal_windx = Bal_windx + Wx_ff;
				Bal_windy = Bal_windy + Wy_ff;
			}
		}
	}
	else
	{
		Aux1 = (Height - Alt_launch) / 10000;
		if(Aux1 < 0)
			Aux1 = 0;
		Aux = Wx_ff * Aux1;
		if(fabs(Aux) > 200)
			Aux = 200 * sgn(Aux);
		if((Metodo == 2) && (Thrustphase))
			Aux = 0;
		if(!Secballistics)
			Bal_windx = Bal_windx + Aux;
		Aux = Wy_ff * Aux1;
		if(fabs(Aux) > 200)
			Aux = 200 * sgn(Aux);
		if((Metodo == 2) && (Thrustphase))
			Aux = 0;
		if(!Secballistics)
			Bal_windy = Bal_windy+Aux;
  	}

	*pDensity   = Density;
	*pVsound    = Vsound;
	*pBal_windx = Bal_windx;
	*pBal_windy = Bal_windy;
	*pPressure  = Pressure;
}


static void Thrust_mass(double Time, double *pAcceler, double *pBal_coef, double Pa, struct TDDT DDT)
{
	double Acceler, Bal_coef;
	double Aux, Fthrust, Fmass, Thrust;

	Acceler  = *pAcceler;
	Bal_coef = *pBal_coef;

	while(Time>Tthrust[Interpol+1]+1.E-6)
	{
		Interpol=Interpol+1;
	}

	while(Time<Tthrust[Interpol])
	{
		Interpol=Interpol-1;
	}

	Aux = (Time - Tthrust[Interpol]);
	Aux = Aux / (Tthrust[Interpol + 1] - Tthrust[Interpol]);
	Fthrust = Thrh[Interpol] + (Thrh[Interpol + 1] - Thrh[Interpol]) * Aux;
	Aux = (Tthrust[Interpol + 1] - Time) / (2 * Rtot);
	Fmass = Rmass[Interpol + 1] + (Thrh[Interpol + 1] + Fthrust) * Aux;
	Momass = DDT.Mass - DDT.Propmass * (1 - Fmass);
	Thrust = Thrust0 * Fthrust * Thrust_fac_eng + DDT.Ass * (DDT.Pnom - Pa);
	Bal_coef = Refarea2 / Momass;
	Acceler = Thrust / Momass;
	*pAcceler = Acceler;
  	*pBal_coef = Bal_coef;
}


static void Meteo(double Zabs, double *pDens, double *pTemp)
{
	double Dens, Temp;
	double Dh1, Aux;
	int Ibat;

	Dens = *pDens;
	Temp = *pTemp;

	Ibat=0;
	while((Zabs > Hbat[Ibat + 1]) && (Ibat < 7))
	{
		Ibat = Ibat + 1;
	}

	Dh1 = Zabs - Hbat[Ibat];
	if(Lbat[Ibat] == 0)
	{
		Temp = Tbat[Ibat];
		Dens = Dbat[Ibat] * exp(-G / Gasconst * Dh1 / Temp);
	}
	else
	{
		Temp = Tbat[Ibat] + Dh1 * Lbat[Ibat];
		Aux = -1 - G / Gasconst / Lbat[Ibat];
		Dens = Dbat[Ibat] * pow((Temp / Tbat[Ibat]), (Aux));
	}

	*pDens = Dens;
  	*pTemp = Temp;
}


static void Ru_ku_ny(struct TDDT DDT)
{
	int I;
	double Qint[4], Vint[4], Kappa[5][4], Aux;

	Diff_equ(T, Q, V, DDT);

	for(I = 1; I <= 3; I++)
	{
		Kappa[1][I] = Delta_t * F[I] / 2;
		Vint[I] = V[I] + Kappa[1][I];
		Qint[I] = Q[I] + Delta_t * (V[I] + Kappa[1][I] / 2) / 2;
	}

	Zcor = FNFzcor(Qint);
	Diff_equ(T + Delta_t / 2, Qint, Vint, DDT);

	for(I = 1; I <= 3; I++)
	{
		Kappa[2][I] = Delta_t * F[I] / 2;
		Vint[I] = V[I] + Kappa[2][I];
		Qint[I] = Q[I] + Delta_t * (V[I] + Kappa[2][I] / 2) / 2;
	}

	Zcor = FNFzcor(Qint);
	Diff_equ(T + Delta_t / 2, Qint, Vint, DDT);

	for(I = 1; I <= 3; I++)
	{
		Kappa[3][I] = Delta_t * F[I] / 2;
		Vint[I] = V[I] + 2 * Kappa[3][I];
		Qint[I] = Q[I] + Delta_t * (V[I] + Kappa[3][I]);
	}

	Zcor = FNFzcor(Qint);
	Diff_equ(T + Delta_t, Qint, Vint, DDT);

	for(I = 1; I <= 3; I++)
	{
		Kappa[4][I] = Delta_t * F[I] / 2;
		Aux = Delta_t * (V[I] + (Kappa[1][I] + Kappa[2][I] + Kappa[3][I]) / 3);
		Q[I] = Q[I] + Aux;
		Aux = (Kappa[1][I] + 2 * (Kappa[2][I] + Kappa[3][I]) + Kappa[4][I]) / 3;
		V[I] = V[I] + Aux;
	}
  	Zcor = FNFzcor(Q);
}


static void Diff_equ(double Ti, double Qi[4], double Vi[4], struct TDDT DDT)
{
	double Zc, Vabs, Windx, Windy, Vs, Balcoef, Rw, Densit, Rh, Tet, Gm, Sbs;
	double Pa, Accel;

	Zc = Zcor +Alt_launch;
	Vabs = sqrt(Vi[1] * Vi[1] + Vi[2] * Vi[2] + Vi[3] * Vi[3]);
	Metcm(Zc, &Densit, &Vs, &Windx, &Windy, &Pa);
	Vrel = sqrt(pow((Vi[1] - Windx), 2) + pow((Vi[2] - Windy), 2) + Vi[3] * Vi[3]);
	Mach = Vrel / Vs;
	Balcoef = Balcoef0;

	if(Thrustphase)
	{
		Cw = FNCwff(Mach, DDT) * DDT.Cdadj * Cwk;
		Thrust_mass(Ti, &Accel, &Balcoef, Pa, DDT);
	}
	else
	{
		if(Secballistics)
		{
			Cw = FNCwsec(Mach, DDT);
		}
		else
		{
			Cw = FNCwff(Mach, DDT) * (1 + Cda);
		}
	}
	Rw = -Cw * Densit * Vrel * Balcoef;
	Rh = sqrt(Qi[1] * Qi[1] + Qi[2] * Qi[2]);
	Tet = Rh / (Earth_rad + Zc);
	Gm = G * (1 - 2 * Zc / Earth_rad);
	F[1] = Rw * (Vi[1] - Windx) + B3 * Vi[2] - B1 * Vi[3] - Gm * Tet * Qi[1] / Rh;
	F[2] = Rw * (Vi[2] - Windy) - B3 * Vi[1] - B2 * Vi[3] - Gm * Tet * Qi[2] / Rh;
	F[3] = Rw * Vi[3] - Gm * (1 - Tet * Tet / 2) + B1 * Vi[1] + B2 * Vi[2];
	if(Thrustphase)
	{
		Sbs = Accel / Vabs;
		F[1] = F[1] + Sbs * Vi[1];
		F[2] = F[2] + Sbs * Vi[2];
		F[3] = F[3] + Sbs * Vi[3];
	}
}


static double FNBux(double Coef[4][10], double En, double Vx, double Vy)
{
	double A[10], B[4];
	double CoefCpy[4][10];
	/*!
	 * The following code block was added to ensure that the double are
	 * 8 byte aligned. If the variable Coef would be used directly and
	 * the code is compiled with the Windriver diab compiler, the
	 * alignment is only 4 bytes. This leads into a crash of the CPU
	 * board with PowerPC e500v2 boards.
	 */
	int i, j;
	for (i = 0; i < 4; ++i) {
		for (j = 0; j < 10; ++j) {
			memcpy(&(CoefCpy[i][j]), &(Coef[i][j]), 8);
		}
	}

	A[1] = CoefCpy[1][1] + En * (CoefCpy[2][1] + En * CoefCpy[3][1]);
	A[2] = CoefCpy[1][2] + En * (CoefCpy[2][2] + En * CoefCpy[3][2]);
	A[3] = CoefCpy[1][3] + En * (CoefCpy[2][3] + En * CoefCpy[3][3]);
	A[4] = CoefCpy[1][4] + En * (CoefCpy[2][4] + En * CoefCpy[3][4]);
	A[5] = CoefCpy[1][5] + En * (CoefCpy[2][5] + En * CoefCpy[3][5]);
	A[6] = CoefCpy[1][6] + En * (CoefCpy[2][6] + En * CoefCpy[3][6]);
	A[7] = CoefCpy[1][7] + En * (CoefCpy[2][7] + En * CoefCpy[3][7]);
	A[8] = CoefCpy[1][8] + En * (CoefCpy[2][8] + En * CoefCpy[3][8]);
	A[9] = CoefCpy[1][9] + En * (CoefCpy[2][9] + En * CoefCpy[3][9]);

	B[1] = A[1] + Vy * (A[2] + Vy * A[3]);
	B[2] = A[4] + Vy * (A[5] + Vy * A[6]);
	B[3] = A[7] + Vy * (A[8] + Vy * A[9]);

	return (B[1] + Vx * (B[2] + Vx * B[3]));
}


static double  FNCwff(double Machnr, struct TDDT DDT)
{
	int Ind;
	double cwff;

	Ind = (int)(Machnr * 10);

	if(Ind > 39)
		Ind = 39;

	cwff = (DDT.Cwss[Ind] + (Machnr * 10 - Ind) * (DDT.Cwss[Ind + 1] - DDT.Cwss[Ind])) * Cd_fac_eng;

  	return (cwff);
}


static double FNCwsec(double Machnr, struct TDDT DDT)
{
	return FNCwff(Machnr, DDT) * DDT.Cdadjsm * Cdsm_fac_eng;
}


static double FNFzcor(double Qu[4])
{
	double Rt, Rh2;

	Rt = Earth_rad + Alt_launch;
	Rh2 = (Qu[1] * Qu[1]) + (Qu[2] * Qu[2]);
	return ((Rh2 / (2 * Rt)) + Qu[3]);
}


static void SetData (struct TEdtData EdtData, struct TTelaEngenharia telaEngenharia)
{
	int i;

	Latitude = EdtData.Latitude;
	Sec_bal = EdtData.Sec_bal;
	Metcm_included = EdtData.Metcm_included;
	Natm = EdtData.Natm;

	for (i = 0; i <= 40; i ++)
	{
		Vwmetcm[i] = EdtData.Vwmetcm[i];
		Azwmetcm[i] = EdtData.Azwmetcm[i];
		Tent[i] = EdtData.Tent[i];
		Pent[i] = EdtData.Pent[i];
	}

	Alt_met = EdtData.Alt_met;
	Azwcor = EdtData.Azwcor;
	T0 = EdtData.T0 + CELKEL;
	P0 = EdtData.P0;
	Proptemp = EdtData.Proptemp;
	if (EdtData.Vws == Empty)
		Vws = 0;
	else
		Vws = EdtData.Vws;

	if (EdtData.Azws == Empty)
		Azws = 0;
	else
		Azws = EdtData.Azws;

	Altfg = EdtData.Altfg;
	RefDir = EdtData.RefDir;

	switch (EdtData.CalType)
	{
		case PILOT_TARGET:
			Elau = EdtData.Elau;
			Nlau = EdtData.Nlau;
			Alt_launch = EdtData.Alt_launch;
			Etarg = EdtData.Etarg;
			Ntarg = EdtData.Ntarg;
			Altarg = EdtData.Altarg;
			Fusetime_input = EdtData.Fusetime_input;
			Vweth = EdtData.Vweth;
			Vwnth = EdtData.Vwnth;
			Vweff = EdtData.Vweff;
			Vwnff = EdtData.Vwnff;
			Azim_tiro = EdtData.Azim_tiro;
			Elev_tiro = EdtData.Elev_tiro;
			Azimuth=(Azim_tiro+RefDir)*Grad1mil;
			Elevation=Elev_tiro*Grad1mil;
			break;

		case MAXRANGE:
			  Elau = EdtData.Elau;
			  Nlau = EdtData.Nlau;
			  Alt_launch = EdtData.Alt_launch;
			  Etarg = EdtData.Etarg;
			  Ntarg = EdtData.Ntarg;
			  Altarg = EdtData.Altarg;
			  Fusetime_input = EdtData.Fusetime_input;
			  Vweth = EdtData.Vweth;
			  Vwnth = EdtData.Vwnth;
			  Vweff = EdtData.Vweff;
			  Vwnff = EdtData.Vwnff;
			  break;

		case CMDCALC:
			  Elau = EdtData.Elau;
			  Nlau = EdtData.Nlau;
			  Alt_launch = EdtData.Alt_launch;
			  Etarg = EdtData.Etarg;
			  Ntarg = EdtData.Ntarg;
			  Altarg = EdtData.Altarg;
			  Fusetime_input = Empty;
			  Vweth = EdtData.Vweth;
			  Vwnth = EdtData.Vwnth;
			  Vweff = EdtData.Vweff;
			  Vwnff = EdtData.Vwnff;
			  break;

		case TRACKING:
			  Elau = EdtData.Elau;
			  Nlau = EdtData.Nlau;
			  Alt_launch = EdtData.Alt_launch;
			  Etarg = EdtData.Etarg;
			  Ntarg = EdtData.Ntarg;
			  Altarg = EdtData.Altarg;
			  Fusetime_input = EdtData.Fusetime_input;
			  Vweth = EdtData.Vweth;
			  Vwnth = EdtData.Vwnth;
			  Vweff = EdtData.Vweff;
			  Vwnff = EdtData.Vwnff;
			  Azim_tiro = EdtData.Azim_tiro;
			  Elev_tiro = EdtData.Elev_tiro;
			  Azimuth=(Azim_tiro+RefDir)*Grad1mil;
			  Elevation=Elev_tiro*Grad1mil;
				break;
	};

	if(Fusetime_input == 0)
		Fusetime_input = Empty;

	Thrust_factor = 0;
	Cda = 0;
	T_ext = 1000;

	Delta_x_e_i    = telaEngenharia.Delta_x_e_i;
	Delta_y_e_i    = telaEngenharia.Delta_y_e_i;
	Delta_z_e_i    = telaEngenharia.Delta_z_e_i;
	Delta_vx_e_i   = telaEngenharia.Delta_vx_e_i;
	Delta_vy_e_i   = telaEngenharia.Delta_vy_e_i;
	Delta_vz_e_i   = telaEngenharia.Delta_vz_e_i;
	Cd_fac_e_i     = telaEngenharia.Cd_fac_e_i;
	Cdsm_fac_e_i   = telaEngenharia.Cdsm_fac_e_i;
	Thrust_fac_e_i = telaEngenharia.Thrust_fac_e_i;
	Tubetime_e_i   = telaEngenharia.Tubetime_e_i;
	Delta_ejec_e_i = telaEngenharia.Delta_ejec_e_i;
	Mass_e_i       = telaEngenharia.Mass_e_i;
	Propmass_e_i   = telaEngenharia.Propmass_e_i;
	Hejec_e_i      = telaEngenharia.Hejec_e_i;

	for(i = 0; i <= 40; i ++)
		Cwss_e_i[i] = Empty;


	Wx_th = Vweth * cos(Azimuth / Rad1) - Vwnth * sin(Azimuth / Rad1);
	Wy_th = Vwnth * cos(Azimuth / Rad1) + Vweth * sin(Azimuth / Rad1);
	Wx_ff = Vweff * cos(Azimuth / Rad1) - Vwnff * sin(Azimuth / Rad1);
	Wy_ff = Vwnff * cos(Azimuth / Rad1) + Vweff * sin(Azimuth / Rad1);
}


static void init_crc32_tab( void ) {
	int i, j;
	unsigned long crc;

	for (i=0; i<256; i++) {
		crc = (unsigned long) i;
		for (j=0; j<8; j++) {
			if ( crc & 0x00000001L ) crc = ( crc >> 1 ) ^ P_32;
			else                     crc =   crc >> 1;
		}
		crc_tab32[i] = crc;
	}
	crc_tab32_init = TRUE;
}

static unsigned long update_crc_32( unsigned long crc, char c ) {
	unsigned long tmp, long_c;

	long_c = 0x000000ffL & (unsigned long) c;
	if ( ! crc_tab32_init ) init_crc32_tab();
	tmp = crc ^ long_c;
	crc = (crc >> 8) ^ crc_tab32[ tmp & 0xff ];
	return crc;
}

static unsigned long CRC32(char *buf, int buflen) {
	int i;
	unsigned long ret=0;

	for(i=0; i<buflen; i++) ret = update_crc_32(ret, buf[i]);

	return (ret);
}

static void Endianize(char *buf, int buflen) {
	int i;
	unsigned long *p;

	p=(unsigned long *)buf;
	for(i=0; i<(buflen/4); i++) p[i]=LongSwap(p[i]);
}
