/*
 * configuracaoParticular.h
 *
 *  Created on: 07/08/2015
 *      Author: avibras
 */

#ifndef CONFIGURACAOPARTICULAR_H_
#define CONFIGURACAOPARTICULAR_H_

#include "novaedt.h"

void configuracaoParticular(novaEdt *nedt);


#endif /* CONFIGURACAOPARTICULAR_H_ */
