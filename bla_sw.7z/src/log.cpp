/*
 * log.cpp
 *
 *  Created on: 26/10/2015
 *      Author: DVieira
 */

#include <stdio.h>
#include <stdlib.h>

int log(char* txt){

	static FILE *f;
	if(f == NULL)
		f = fopen("log_daniel.txt","w");

	fprintf(f,txt);
	return 1;
}
