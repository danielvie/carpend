/*
 * log.h
 *
 *  Created on: 26/10/2015
 *      Author: DVieira
 */

#ifndef LOG_H_
#define LOG_H_


int log(char* txt);


#endif /* LOG_H_ */
