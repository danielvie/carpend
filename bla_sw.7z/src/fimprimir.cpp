/*
 * imprimir.cpp
 *
 *  Created on: 05/08/2015
 *      Author: avibras
 */
#include "imprimir.h"

void imprimirDadosLancamento(novaEdt *nedt){
	// MOSTRANDO VALORES INICIAIS
	printf("sec_bal: %d\n",nedt->edtData.Sec_bal);

	printf("--------------------------------------------\n");
	printf("posicao lancadora: \n");

	printf("Este : %.2f\n",nedt->edtData.Elau);
	printf("Norte: %.2f\n",nedt->edtData.Nlau);
	printf("Alt  : %.2f\n",nedt->edtData.Alt_launch);

	printf("coordenadas alvo:\n");
	printf("Este : %.2f\n",nedt->edtData.Etarg);
	printf("Norte: %.2f\n",nedt->edtData.Ntarg);
	printf("Alt  : %.2f\n",nedt->edtData.Altarg);
	printf("--------------------------------------------\n");
}

void imprimirEstimacaoVento(novaEdt *nedt){
	std::cout << std::fixed;
	std::cout.precision(2);

	std::cout << "VentoTH YX: " << nedt->edtData.Vweth << "; " << nedt->edtData.Vwnth << std::endl;

	nedt->voarCompleto(nedt->tempoQueima*2);
	double velocidadeFimDeQueima[3] = {nedt->stState.VXN, nedt->stState.VYN, nedt->stState.VZN};

	printf("Velocidade rastreio : [ %5.2f %7.2f ]\n", nedt->velocidadeFimDeQueima[0], nedt->velocidadeFimDeQueima[1]);
	printf("Velocidade simulada : [ %5.2f %7.2f ]\n", nedt->stState.VXN, nedt->stState.VYN);
	printf("Erro                : [ %5.2f %7.2f ]\n",
		velocidadeFimDeQueima[0]-nedt->velocidadeFimDeQueima[0],
		velocidadeFimDeQueima[1]-nedt->velocidadeFimDeQueima[1]
	);
	std::cout << "\n";

	nedt->voarCompleto();
	std::cout << "VentoFF YX: " << nedt->edtData.Vweff << "; " << nedt->edtData.Vwnff << std::endl;

	printf("Impacto extrapolado : [ %9.2f %10.2f %7.2f ]\n", nedt->posicaoFimDeVoo[0], nedt->posicaoFimDeVoo[1], nedt->posicaoFimDeVoo[2]);
	printf("Impacto simulado    : [ %9.2f %10.2f %7.2f ]\n", nedt->posicaoImpacto[0], nedt->posicaoImpacto[1], nedt->posicaoImpacto[2]);
	printf("Erro                : [ %9.2f %10.2f %7.2f ]\n", nedt->posicaoFimDeVoo[0]-nedt->posicaoImpacto[0], nedt->posicaoFimDeVoo[1]-nedt->posicaoImpacto[1],nedt->posicaoFimDeVoo[2]-nedt->posicaoImpacto[2]);
	std::cout << "\n";

	std::cout.precision(0);
	std::cout << "Elev: " << nedt->edtData.Elev_tiro << "\tAzi: " << nedt->edtData.Azim_tiro << std::endl;
	std::cout.precision(2);
	std::cout << "Desvio Alcance: " << nedt->calcularDesvioAlcance() << std::endl;
	std::cout << "Desvio Lateral: " << nedt->calcularDesvioLateral() << std::endl;
	std::cout << "\n";
}

char* imprimirResultados(novaEdt *nedt){
	char* txt = (char*)malloc(800*sizeof(char));

	sprintf(txt,"RESULTADOS:\n");
	sprintf(txt+strlen(txt),"Elev: %6.2f",nedt->edtData.Elev_tiro);
	sprintf(txt+strlen(txt),"   ");
	sprintf(txt+strlen(txt),"Azi: %6.2f\n",nedt->edtData.Azim_tiro);

	sprintf(txt+strlen(txt),"E: %.2f\tN: %.2f\n",nedt->posicaoImpacto[0],nedt->posicaoImpacto[1]);
	sprintf(txt+strlen(txt),"Alcance           : %.2f\n", nedt->calcularAlcance());
	sprintf(txt+strlen(txt),"Desvio Alcance    : %.2f\n", nedt->calcularDesvioAlcance());
	sprintf(txt+strlen(txt),"Desvio Lateral    : %.2f\n", nedt->calcularDesvioLateral());
	sprintf(txt+strlen(txt),"Valor de fusetime : %.2f\n", nedt->Fusetime);
	sprintf(txt+strlen(txt),"Valor de hejec    : %.2f\n", nedt->Hejec);
	printf(txt);

	return txt;
}

char* imprimirFog(int fog){
	char* txt = (char*)malloc(20*sizeof(char));

	switch(fog){
	case 1: 
		sprintf(txt,"fog: SS_09TS");
		break;
	case 2: 
		sprintf(txt,"fog: SS_30");
		break;
	case 3: 
		sprintf(txt,"fog: SS_40");
		break;
	case 4: 
		sprintf(txt,"fog: SS_60");
		break;
	case 5: 
		sprintf(txt,"fog: SS_80");
		break;
	default:
		sprintf(txt,"fog: invalido!");
		break;
	}
	printf("%s\n",txt);
	return txt;
}

void imprimirElementos(novaEdt *nedt){
	printf("Elementos:\n");
	printf("Elevacao: %.2f\n",nedt->edtData.Elev_tiro);
	printf("Azimute : %.2f\n",nedt->edtData.Azim_tiro);
	printf("\n");
}

void toc(clock_t tempo){
	printf("tempo de execucao: %.3f\n",(double)(clock()-tempo)/CLOCKS_PER_SEC);
}
