/*
 * configuraNEDT.cpp
 *
 *  Created on: 09/02/2015
 *      Author: User
 */
#include "configuraNEDT.h"
#include <stdio.h>

void configuraNEDT(novaEdt *nedt, struct TTrackingResult *rastreio, double *lancamento, double *ponteiroTabelaVento){
	double Tabela_Vento[41][5];
	memcpy(&Tabela_Vento,ponteiroTabelaVento,sizeof(Tabela_Vento));

	// DADOS DE LANCAMENTO
	//	nedt->edtData.DDTType        = fog; // Tipo de foguete que estamos lan�ando
	nedt->edtData.Sec_bal        = lancamento[0];//(int)1; //(int)lancamento[0]; // 1; // Com [1] ou Sem Bal�stica Secund�ria [0]
	nedt->edtData.Altfg          = lancamento[1]; // 0; // Altitude da EDT [m]
	nedt->edtData.Alt_launch     = lancamento[2]; // 0; // Altitude da Lan�adora em Metros
	nedt->edtData.Altarg         = lancamento[3]; // 0; // Altitude do Alvo em metros
	nedt->edtData.Latitude       = lancamento[4]; // 5; // Latitude da Lan�adora [�]
	nedt->edtData.Elev_tiro      = lancamento[5]; // 444; // Eleva��o do tiro mils
	nedt->edtData.Azim_tiro      = lancamento[6]; // 0; // Azimute do Tiro
	nedt->edtData.Fusetime_input = lancamento[7]; // lancamento[7]; // 10000; // Tempo de eje��o para os casos que tem Submuni��o
	nedt->edtData.T0             = lancamento[8]; // 15; // Temperatura do Ar C
	nedt->edtData.Proptemp       = lancamento[9]; // 15; // Temperatura do Propelente C
	nedt->edtData.P0             = lancamento[10]; // 1013; // Press�o do Ar mbar
	nedt->edtData.Azws           = lancamento[11]; // 1777; // Azimute do Vento de Superf�cie mils
	nedt->edtData.Vws            = lancamento[12]; // 0; // Velocidade do Vento de superf�cie knos
	nedt->edtData.Nlau           = lancamento[13]; // 0; // Coordenada Norte da Lan�adora [m]
	nedt->edtData.Elau           = lancamento[14]; // 0; // Coordenada Leste da Lan�adora [m]
	nedt->edtData.Ntarg          = lancamento[15]; // 16652.677556; // Coordenada Norte do Alvo [m]
	nedt->edtData.Etarg          = lancamento[16]; // -7.757720; // Coordenada Leste do Alvo [m]

	// METCM
	nedt->edtData.Metcm_included = lancamento[17];// 0;//Tem [1] ou n�o [0] Metcm
	nedt->edtData.Alt_met        = lancamento[18];// 0;//Altitude do posto de medida meteorol�gica
	nedt->edtData.Azwcor         = lancamento[19];// 0;//Corre��o de Azimute das medidas meteorol�gicas [graus]
	nedt->edtData.Natm           = lancamento[20];//10;//Numero de camadas da metcm

	// TABELA DE VENTO
	for (int var = 0; var <= nedt->edtData.Natm; ++var) {
		nedt->edtData.Azwmetcm[var] = Tabela_Vento[var][1];
		nedt->edtData.Vwmetcm[var]  = Tabela_Vento[var][2];
		nedt->edtData.Tent[var]     = Tabela_Vento[var][3];
		nedt->edtData.Pent[var]     = Tabela_Vento[var][4];
	}
}
