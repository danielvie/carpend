/*
 * imprimir.h
 *
 *  Created on: 05/08/2015
 *      Author: avibras
 */

#ifndef IMPRIMIR_H_
#define IMPRIMIR_H_

#include <iostream>
#include <time.h>
#include "novaedt.h"


void imprimirDadosLancamento(novaEdt *nedt);
void imprimirEstimacaoVento(novaEdt *nedt);
char* imprimirResultados(novaEdt *nedt);
char* imprimirFog(int fog);
void imprimirElementos(novaEdt *nedt);
void toc(clock_t tempo);

#endif /* IMPRIMIR_H_ */
