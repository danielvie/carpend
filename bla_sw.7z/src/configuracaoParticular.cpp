/*
 * configuracaoParticular.cpp
 *
 *  Created on: 07/08/2015
 *      Author: avibras
 */
#include "configuracaoParticular.h"

void configuracaoParticular(novaEdt *nedt){
	nedt->edtData.Elau       = 0;
	nedt->edtData.Nlau       = 0;
	nedt->edtData.Alt_launch = 0;

	nedt->edtData.T0         = 15;
	nedt->edtData.P0         = 1013.25;
	nedt->edtData.Proptemp   = 15;

	nedt->edtData.Latitude   = -15;

	nedt->edtData.Fusetime_input = 1.e38;
	nedt->edtData.Sec_bal = (int)1;

	//	nedt->edtData.Fusetime_input = 23.4;
	nedt->edtData.Vws = 0;
	nedt->Vweth = 0;
	nedt->Vwnth = 0;
	nedt->Vweff = 0;
	nedt->Vweff = 0;
	nedt->edtData.Vweth = 0;
	nedt->edtData.Vwnth = 0;
	nedt->edtData.Vweff = 0;
	nedt->edtData.Vweff = 0;
}
