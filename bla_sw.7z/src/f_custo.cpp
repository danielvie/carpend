/*
 * f_custo.cpp
 *
 *  Created on: 11/12/2014
 *      Author: User
 */

#include "f_custo.h"
#include "novaedt.h"
#include "imprimir.h"

double f_custo(double x[], void *params) {
	struct TShot shot;
	double elevacao, azimute;

	elevacao = x[0];

	novaEdt* nedt = (novaEdt*)params;

	if (elevacao < nedt->DDTDLL.Elev_min)
		return 1e8;
	if (elevacao > nedt->DDTDLL.Elevmax/0.05625) // caso de elevacao maxima
		return 1e8;

	nedt->edtData.Elev_tiro = elevacao;

	azimute = nedt->edtData.Azim_tiro;

	// Condicao inicial
	shot = nedt->voarCompleto();

	//	ENCONTRAR O DESVIO ALCANCE E LATERAL
	double desvAlc = nedt->calcularDesvioAlcance();
	double desvLat = nedt->calcularDesvioLateral();

	double erroAlc = fabs(desvAlc);
	double erro = erroAlc;

	// ajuste azimute
	double ajusteAzi = desvLat/nedt->calcularAlcance()*1000;

	azimute -= ajusteAzi;
	nedt->edtData.Azim_tiro = azimute;

	if(shot.Error == BALISTIC_ERROR002) // caso de nao conseguir fazer a ejecao
		erro += 1e5;

	return erro;
}

double f_custo_ventoth(double x[], void *params) {
	double ventoE,ventoN;
	ventoE = x[0];
	ventoN = x[1];

	novaEdt *nedt = (novaEdt*)params;

	// Condicao inicial
	nedt->edtData.Vweth = ventoE;
	nedt->edtData.Vwnth = ventoN;

	// fazendo a diferenca dos ventos em 2x o tempo de queima do foguete
	// isso foi passado pelo Ricardo P. durante os testes o radar com o
	// Flavio e o Derso. A mudanca eh  para que o vento TH represente a
	// fase de voo do foguete com maior variacao de velocidade, deixando
	// o vento FF para a fase do voo com velocidade mais constante;
	nedt->voarCompleto(nedt->tempoQueima*2);

	//	ENCONTRAR O DESVIO ALCANCE E LATERAL

	double diferenca[3] = {nedt->stState.VXN-nedt->velocidadeFimDeQueima[0],nedt->stState.VYN-nedt->velocidadeFimDeQueima[1],nedt->stState.VZN-nedt->velocidadeFimDeQueima[2]};
	double erro = diferenca[0]*diferenca[0] + diferenca[1]*diferenca[1] + diferenca[2]*diferenca[2];
	return erro;
}

double f_custo_ventoff(double x[], void *params) {
	double ventoE,ventoN;
	ventoE = x[0];
	ventoN = x[1];

	novaEdt *nedt = (novaEdt*)params;

	// Condicao inicial
	nedt->edtData.Vweff = ventoE;
	nedt->edtData.Vwnff = ventoN;

	nedt->voarCompleto();

	//	ENCONTRAR O DESVIO ALCANCE E LATERAL
	double diferenca[3] = {
			nedt->posicaoImpacto[0] - nedt->posicaoFimDeVoo[0],
			nedt->posicaoImpacto[1] - nedt->posicaoFimDeVoo[1],
			nedt->posicaoImpacto[2] - nedt->posicaoFimDeVoo[2]};

	double d1 = sqrt(diferenca[0]*diferenca[0]);
	double d2 = sqrt(diferenca[1]*diferenca[1]);
	double erro =  d1 + d2;

	return erro;
}

double f_custoAlcanceMaximo(double x[], void *params) {
// double f_custoAlcanceMaximo(const gsl_vector *v, void *params) {
	double elevacao, erro;
// elevacao = gsl_vector_get(v, 0);
	elevacao = x[0];

	novaEdt *nedt = (novaEdt*)params;

	if (elevacao < 0 || elevacao > nedt->DDTDLL.Elevmax/0.05625)
		return 1e8;

	// calculando voo
	nedt->edtData.Elev_tiro = elevacao;
	nedt->voarCompleto();

	// calculando erro
	erro = 1/fabs(nedt->calcularAlcance())*1e5;

	if(nedt->Fusetime < 0.01) // caso de nao conseguir fazer a ejecao
		erro += 1e5;

	return erro;
}
