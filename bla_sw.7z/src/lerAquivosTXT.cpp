/*
 * lerAquivosTXT.cpp
 *
 *  Created on: 09/02/2015
 *      Author: User
 */

#include "lerAquivosTXT.h"
#include <stdio.h>
#include <windows.h>
#include "novaedt.h"
#include "estruturas.h"

int lerAquivosTXT(struct TTrackingResult *radarIN, int *foguete, double *Lanc, double *Tabela_VentoIN, int *CntTrkData){
	double valores1;
	double valores2;
	double valores3;
	double valores4;
	double valores5;
	double valores6;
	double valores7;
	double valores8;
	double valores9;
	double valores10;
	double valores11;
	double valores12;
	double valores13;
	int valores14;

	double Tabela_Vento[41][5];

	double aux1;
	double aux2;
	double aux3;
	double aux4;
	double aux5;
	
	int aux_int;

	char linha[300];

	int contador = 0;

	//	LENDO ARQUIVOS
	FILE *tipoFog;
	FILE *lancamento;
	FILE *tabelaVento;
	FILE *Radar1;
	FILE *Radar2;
	FILE *Radar3;
	FILE *CntTrkDataf;

	char endereco[40] = "./src/arquivos/40_2";//Mudei aqui para pegar os arquivos direto na fonte
	char arquivo[40]; strcpy(arquivo,endereco);

	tipoFog     = fopen(strcat(arquivo,"/Ar4.txt"),"r"); strcpy(arquivo,endereco);
	lancamento  = fopen(strcat(arquivo,"/Ar1.txt"),"r"); strcpy(arquivo,endereco);
	tabelaVento = fopen(strcat(arquivo,"/Ar2.txt"),"r"); strcpy(arquivo,endereco);
	Radar1      = fopen(strcat(arquivo,"/Ar7.txt"),"r"); strcpy(arquivo,endereco);
	Radar2      = fopen(strcat(arquivo,"/Ar5.txt"),"r"); strcpy(arquivo,endereco);
	Radar3      = fopen(strcat(arquivo,"/Ar6.txt"),"r"); strcpy(arquivo,endereco);
	CntTrkDataf	= fopen(strcat(arquivo,"/Ar8.txt"),"r"); strcpy(arquivo,endereco);

	int ret = 1;
	if(tipoFog==NULL){
		printf("Derso, cad� o arquivo Ar4!!!\n");
		ret = 0;
	};
	if(lancamento==NULL){
		printf("Derso, cad� o arquivo Ar1!!!\n");
		ret = 0;
	};
	if(tabelaVento==NULL){
		printf("Derso, cad� o arquivo Ar2!!!\n");
		ret = 0;
	};
	// if(cond_ini==NULL) {
	// 	printf("Derso, cad� o arquivo Ar3!!!\t\n");
	// 	ret = 0;
	// };
	if(Radar1==NULL) {
		printf("Derso, cad� o arquivo Ar7!!!\n");
		ret = 0;
	};
	if(Radar2==NULL) {
		printf("Derso, cad� o arquivo Ar5!!!\n");
		ret = 0;
	};
	if(Radar3==NULL) {
		printf("Derso, cad� o arquivo Ar6!!!\n");
		ret = 0;
	};
	if(CntTrkDataf==NULL) {
		printf("Derso, cad� o arquivo Ar8!!!\n");
		ret = 0;
	};

	if (ret == 0) return 0;

	// -----------------------
	// Tipo de foguete - Ar4

	while(fgets(linha,sizeof(linha),tipoFog)) {
		sscanf(linha,"%d",&aux_int);
		(*foguete) = aux_int;
	};

	// -----------------------
	// Dados de lancamento - Ar1

	contador = 0;
	while(fgets(linha,sizeof(linha),lancamento)) {
		sscanf(linha,"%lf\n",&aux1);
		Lanc[contador]=aux1;
		contador++;
	};

	// -----------------------
	// Tabela de vento - Ar2

	contador = 0;
	while (fgets(linha,sizeof(linha),tabelaVento)) {
		sscanf(linha,"%lf %lf %lf %lf %lf",&aux1,&aux2,&aux3,&aux4,&aux5);
		Tabela_Vento[contador][0] = aux1;
		Tabela_Vento[contador][1] = aux2;
		Tabela_Vento[contador][2] = aux3;
		Tabela_Vento[contador][3] = aux4;
		Tabela_Vento[contador][4] = aux5;
		contador++;
	};

	memcpy(Tabela_VentoIN,&Tabela_Vento,sizeof(Tabela_Vento));

	// -----------------------
	// Condicao inicial - Ar2


	// -----------------------
	// Dados do radar Parte 1 - Ar7

	contador = 0;
	while(fgets(linha,sizeof(linha),Radar1)){
		sscanf(linha,"%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %d",
				&valores1,  &valores2,  &valores3,  &valores4, &valores5,
				&valores6,  &valores7,  &valores8,  &valores9, &valores10,
				&valores11, &valores12, &valores13, &valores14);

		radarIN->MeasuredPositionX[contador] = valores1;
		radarIN->MeasuredPositionY[contador] = valores2;
		radarIN->MeasuredPositionZ[contador] = valores3;
		radarIN->OneSigmaX[contador] = valores4;
		radarIN->OneSigmaY[contador] = valores5;
		radarIN->OneSigmaZ[contador] = valores6;
		radarIN->SignalToNoiseRatio[contador] = valores7;
		radarIN->FilteredPositionX[contador] = valores8;
		radarIN->FilteredPositionY[contador] = valores9;
		radarIN->FilteredPositionZ[contador] = valores10;
		radarIN->FilteredVelocityX[contador] = valores11;
		radarIN->FilteredVelocityY[contador] = valores12;
		radarIN->FilteredVelocityZ[contador] = valores13;
		radarIN->RelativeTime[contador] = valores14;

		contador++;
	}
	// printf("contador: %d\n",contador);
	// -----------------------
	// Dados do radar Parte 2 - Ar5

	contador = 0;
	char tring[15];
	while(!feof(Radar2)) {
		fscanf(Radar2,"%s",tring);
		strcpy(radarIN->MissionState[contador],tring);
		contador++;
	}

	// -----------------------
	// Dados do radar Parte 3 - Ar6

	contador = 0;
	while(fgets(linha,sizeof(linha),Radar3)) {
		sscanf(linha,"%s",tring);
		strcpy(radarIN->MeasuredPositionState[contador],tring);
		contador++;
	}

	// -----------------------
	// Tamanho dos dados do Radar -  Ar8
	fscanf(CntTrkDataf,"%d",CntTrkData);

	// printf("CntTrkData: %d\n",*CntTrkData);
	return 1;
}
