/*
 * testes.cpp
 *
 *  Created on: 07/08/2015
 *      Author: avibras
 */

#include "testes.h"
#include "lerAquivosTXT.h"
#include "configuraNEDT.h"
#include "imprimir.h"

int testeLancamentoSimples(novaEdt *nedt){
	// Inicializando foguete
	int fog = SS_60;
	nedt->ConfigEdt(fog);

	//  Elementos de Tiro:
	nedt->edtData.Elau       = 352742.0; // Leste lancadora
	nedt->edtData.Nlau       = 9138740.0; // Norte lancadora
	nedt->edtData.Alt_launch = 4.0; // Alti. lancadora
	nedt->edtData.Latitude   = 5.0; // Latitude

	nedt->edtData.Etarg      = 336447.0; // Leste alvo
	nedt->edtData.Ntarg      = 9069635.0; // Norte alvo
	nedt->edtData.Altarg     = 0.0; // Alti. alvo

	nedt->edtData.Alt_met    = 10.0; // Alti. MET
	nedt->edtData.Altfg      = 10.0; // Alti. UCF

	nedt->edtData.T0         = 31.4; // Temperatura
	nedt->edtData.Proptemp   = 31.4; // T. Propelente
	nedt->edtData.P0         = 1007.4; // Pressao

	nedt->edtData.Sec_bal    = 1; // Balistica Sec.

	nedt->edtData.Latitude   = 5.0; // Latitude

	// Vento de Superficie:
	nedt->edtData.Vws        = 6.0; // Vel.Vento Sup.
	nedt->edtData.Azws       = 3200.0; // Az. Vento Sup.

	// METCM:
	nedt->edtData.Metcm_included = 1;
	nedt->edtData.Natm = 27;

	nedt->edtData.Vwmetcm[0] = 2.0; nedt->edtData.Vwmetcm[1] = 3.0; nedt->edtData.Vwmetcm[2] = 7.0; nedt->edtData.Vwmetcm[3] = 9.0; nedt->edtData.Vwmetcm[4] = 10.0; nedt->edtData.Vwmetcm[5] = 11.0; nedt->edtData.Vwmetcm[6] = 21.0; nedt->edtData.Vwmetcm[7] = 28.0; nedt->edtData.Vwmetcm[8] = 24.0; nedt->edtData.Vwmetcm[9] = 24.0; nedt->edtData.Vwmetcm[10] = 16.0; nedt->edtData.Vwmetcm[11] = 12.0; nedt->edtData.Vwmetcm[12] = 7.0; nedt->edtData.Vwmetcm[13] = 15.0; nedt->edtData.Vwmetcm[14] = 11.0; nedt->edtData.Vwmetcm[15] = 8.0; nedt->edtData.Vwmetcm[16] = 9.0; nedt->edtData.Vwmetcm[17] = 3.0; nedt->edtData.Vwmetcm[18] = 6.0; nedt->edtData.Vwmetcm[19] = 11.0; nedt->edtData.Vwmetcm[20] = 5.0; nedt->edtData.Vwmetcm[21] = 9.0; nedt->edtData.Vwmetcm[22] = 19.0; nedt->edtData.Vwmetcm[23] = 10.0; nedt->edtData.Vwmetcm[24] = 21.0; nedt->edtData.Vwmetcm[25] = 16.0; nedt->edtData.Vwmetcm[26] = 27.0; nedt->edtData.Vwmetcm[27] = 17.0; 
	nedt->edtData.Azwmetcm[0] = 3310.0; nedt->edtData.Azwmetcm[1] = 2840.0; nedt->edtData.Azwmetcm[2] = 2290.0; nedt->edtData.Azwmetcm[3] = 2440.0; nedt->edtData.Azwmetcm[4] = 2300.0; nedt->edtData.Azwmetcm[5] = 1990.0; nedt->edtData.Azwmetcm[6] = 1620.0; nedt->edtData.Azwmetcm[7] = 1660.0; nedt->edtData.Azwmetcm[8] = 1530.0; nedt->edtData.Azwmetcm[9] = 1270.0; nedt->edtData.Azwmetcm[10] = 1220.0; nedt->edtData.Azwmetcm[11] = 1410.0; nedt->edtData.Azwmetcm[12] = 1620.0; nedt->edtData.Azwmetcm[13] = 2120.0; nedt->edtData.Azwmetcm[14] = 2030.0; nedt->edtData.Azwmetcm[15] = 2760.0; nedt->edtData.Azwmetcm[16] = 2880.0; nedt->edtData.Azwmetcm[17] = 3630.0; nedt->edtData.Azwmetcm[18] = 5350.0; nedt->edtData.Azwmetcm[19] = 5710.0; nedt->edtData.Azwmetcm[20] = 5930.0; nedt->edtData.Azwmetcm[21] = 670.0; nedt->edtData.Azwmetcm[22] = 1040.0; nedt->edtData.Azwmetcm[23] = 1740.0; nedt->edtData.Azwmetcm[24] = 1910.0; nedt->edtData.Azwmetcm[25] = 4780.0; nedt->edtData.Azwmetcm[26] = 4870.0; nedt->edtData.Azwmetcm[27] = 4950.0; 
	nedt->edtData.Tent[0] = 306.8; nedt->edtData.Tent[1] = 304.5; nedt->edtData.Tent[2] = 302.3; nedt->edtData.Tent[3] = 299.0; nedt->edtData.Tent[4] = 295.2; nedt->edtData.Tent[5] = 292.2; nedt->edtData.Tent[6] = 289.8; nedt->edtData.Tent[7] = 286.5; nedt->edtData.Tent[8] = 282.5; nedt->edtData.Tent[9] = 280.0; nedt->edtData.Tent[10] = 277.4; nedt->edtData.Tent[11] = 274.5; nedt->edtData.Tent[12] = 269.4; nedt->edtData.Tent[13] = 265.7; nedt->edtData.Tent[14] = 259.1; nedt->edtData.Tent[15] = 253.0; nedt->edtData.Tent[16] = 245.4; nedt->edtData.Tent[17] = 236.8; nedt->edtData.Tent[18] = 228.4; nedt->edtData.Tent[19] = 219.7; nedt->edtData.Tent[20] = 211.3; nedt->edtData.Tent[21] = 202.7; nedt->edtData.Tent[22] = 196.8; nedt->edtData.Tent[23] = 192.3; nedt->edtData.Tent[24] = 192.7; nedt->edtData.Tent[25] = 201.3; nedt->edtData.Tent[26] = 200.0; nedt->edtData.Tent[27] = 201.7; 
	nedt->edtData.Pent[0] = 1009.0; nedt->edtData.Pent[1] = 998.0; nedt->edtData.Pent[2] = 970.0; nedt->edtData.Pent[3] = 927.0; nedt->edtData.Pent[4] = 875.0; nedt->edtData.Pent[5] = 825.0; nedt->edtData.Pent[6] = 778.0; nedt->edtData.Pent[7] = 734.0; nedt->edtData.Pent[8] = 691.0; nedt->edtData.Pent[9] = 650.0; nedt->edtData.Pent[10] = 612.0; nedt->edtData.Pent[11] = 575.0; nedt->edtData.Pent[12] = 523.0; nedt->edtData.Pent[13] = 460.0; nedt->edtData.Pent[14] = 404.0; nedt->edtData.Pent[15] = 354.0; nedt->edtData.Pent[16] = 308.0; nedt->edtData.Pent[17] = 268.0; nedt->edtData.Pent[18] = 231.0; nedt->edtData.Pent[19] = 198.0; nedt->edtData.Pent[20] = 169.0; nedt->edtData.Pent[21] = 143.0; nedt->edtData.Pent[22] = 121.0; nedt->edtData.Pent[23] = 101.0; nedt->edtData.Pent[24] = 85.0; nedt->edtData.Pent[25] = 71.0; nedt->edtData.Pent[26] = 60.0; nedt->edtData.Pent[27] = 47.0; 

	//  Calculo de Tiro :
	nedt->edtData.Elev_tiro      = 1120.0;
	nedt->edtData.Azim_tiro      = 3462.0;
	nedt->edtData.Fusetime_input = 154.1;

	// nedt->calcularTiro2();

	if ((fog == SS_30) || (fog == SS_09TS)) {
		nedt->edtData.Sec_bal = 0;
	}

	struct TShot shot;
	
	nedt->calcularAlcanceMaximo();
	int i;

	nedt->edtData.Elev_tiro = 1108.0;
	for (i = 0; i < 50; i++){
		nedt->edtData.Elev_tiro += 1.0;
		nedt->edtData.Fusetime_input = 0.0;
		shot = nedt->voarCompleto();
		printf("elev: %.2f, alcance: %.2f\n", shot.El, shot.Range);
	}
	

	
	nedt->calcularAlcanceMaximo2();



	//	imprimirResultados(nedt);
	

	imprimir p(nedt);
	// p.resultados();

	return 1;
}