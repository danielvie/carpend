/*
 * testes.cpp
 *
 *  Created on: 07/08/2015
 *      Author: avibras
 */

#include "testes.h"
#include "lerAquivosTXT.h"
#include "configuraNEDT.h"
#include "imprimir.h"

//void testeApontamento(novaEdt *nedt){
//	clock_t tempo;
//	configuracaoParticular(nedt);
//
//	nedt->edtData.Elev_tiro = 1066;
//	nedt->edtData.Azim_tiro = 1600;
//
//	nedt->edtData.Sec_bal = (int)0;
//	//	nedt->voarCompleto();
//
//	//	printf("calculos de tiro: \n");
//	//	clock_t tempo = clock();
//	//	nedt->calcularTiro();
//	//	imprimirResultados(nedt);
//	//	printf("tempo calculartiro: %.2f s\n",(double)(clock()-tempo)/CLOCKS_PER_SEC);
//
//	imprimir p(nedt);
//
//	tempo = clock();
//	printf("passei por aqui!");
//	nedt->calcularTiro2();
//	//	imprimirResultados(nedt);
//	p.resultados();
//	printf("tempo calculartiro2: %.2f s\n",(double)(clock()-tempo)/CLOCKS_PER_SEC);
//}
//
//struct TTrackingResult rastreio;
//
//int testeVentoIdentificacao(novaEdt *nedt){
////	double lancamento[21]; // dados de lancamento
////	double tabelaVento[41][5]; // tabela de vento
////	double *ponteiroTabelaVento = tabelaVento[0];
////	int CntTrkData;
////
////	imprimir p(nedt);
////
////	for (int var = 0; var <= 4500; ++var)
////		rastreio.RelativeTime[var] = -1;
////
////	// LENDO ARQUIVOS TXT
////	int fog;
////	int ret;
////	ret = lerAquivosTXT(&rastreio,&fog,lancamento,ponteiroTabelaVento,&CntTrkData);
////
////	fog = SS_40;
////	nedt->ConfigEdt(fog);
////
////	if (!ret){
////		printf("\nErro ao ler arquivos de dados");
////		return 0;
////	}
////
////	// USANDO OS DADOS LIDOS PARA CONFIGURAR O OBJETO
////	configuraNEDT(nedt, &rastreio, lancamento, ponteiroTabelaVento);
////
////	nedt->SetTrackingData(&rastreio);
////	nedt->SetCntTrkData(CntTrkData);
////
////	// --------------------------------------------
////	// AQUI COMECA A NOVA EDT
////	// SIMULACAO DE VOO
////
////	// TRATANDO VALORES DE RASTREIO
////	double C0_fq[7], C0_extrap[7];
////	int erro[5];
////	nedt->tratarDadosRadar(nedt->tempoQueima*2,C0_fq,C0_extrap,erro);
////
////	// criando variavel de condicaoInicial
////	condicaoInicial inicio;
////	inicio.extrapolar = TRUE; // <-------- DERSO, CONFERE ISSO LAH
////	inicio.tempo      = C0_extrap[0];
////	inicio.pos[0]     = C0_extrap[1];
////	inicio.pos[1]     = C0_extrap[2];
////	inicio.pos[2]     = C0_extrap[3];
////	inicio.vel[0]     = C0_extrap[4];
////	inicio.vel[1]     = C0_extrap[5];
////	inicio.vel[2]     = C0_extrap[6];
////
////	printf("inicio pos: %.2f\n",inicio.pos[0]);
////	printf("inicio pos: %.2f\n",inicio.pos[1]);
////	printf("inicio pos: %.2f\n",inicio.pos[2]);
////
////	// extrapolando ponto de impacto a partir da condicaoInicial
////	struct TShot shot;
////	shot = nedt->voarExtrapolando(&inicio);
////
////	p.resultados();
////	printf("estou aqui!\n");
////
////	return 1;
////	// calculando ponto de impacto em coordenadas EN
////
////	double Norte_Pilotos[100], Leste_Pilotos[100], Altitude_Pilotos[100];
////	int Pontos_Validos[100], tam;
////	double Media_Pto_Imp[3];
////
////	// DERSO, AQUI VC VAI FAZER A MEDIA DAS VELOCIDADES FIM DE QUEIMA
////	// E DOS PONTOS DE IMPACTO EXTRAPOLADOS
////
////	// salvando valores de media nas posicoes
////	nedt->posicaoFimDeQueima[0]    = C0_fq[1];
////	nedt->posicaoFimDeQueima[1]    = C0_fq[2];
////	nedt->posicaoFimDeQueima[2]    = C0_fq[3];
////	nedt->velocidadeFimDeQueima[0] = C0_fq[4]; // X
////	nedt->velocidadeFimDeQueima[1] = C0_fq[5]; // Y
////	nedt->velocidadeFimDeQueima[2] = C0_fq[6]; // Z
////
////	nedt->posicaoFimDeVoo[0] = nedt->posicaoImpacto[0]; // E
////	nedt->posicaoFimDeVoo[1] = nedt->posicaoImpacto[1]; // N
////	nedt->posicaoFimDeVoo[2] = nedt->posicaoImpacto[2]; // H
////
////	// ---------------------------------------------------------------------------
////	// INICIO CALCULOS DE VENTO
////	nedt->log("resultadoOriginal");
////	p.resultados();
////	nedt->log(p.txt);
////
////	// zerando valores de vento
////	nedt->Vweth = 0; // vento ESTE propulsada
////	nedt->Vwnth = 0; // vento NORTE propulsada
////	nedt->Vweff = 0; // vento ESTE free flight
////	nedt->Vwnff = 0; // vento NORTE free flight
////	nedt->edtData.Vweth = 0; // vento ESTE propulsada
////	nedt->edtData.Vwnth = 0; // vento NORTE propulsada
////	nedt->edtData.Vweff = 0; // vento ESTE free flight
////	nedt->edtData.Vwnff = 0; // vento NORTE free flight
////
////	double desvioAlcance, desvioLateral, alvoVerdadeiro[2];
////	desvioAlcance = nedt->calcularDesvioAlcance();
////	desvioLateral = nedt->calcularDesvioLateral();
////
////	//	calculos de ventos fase propulsada
////	nedt->log("calculoTiroCorrecaoVento");
////	nedt->log("nedt->calcularVentoTH");
////	nedt->calcularVentoTH();
////
////	//	calculos de ventos fase balistica
////	nedt->log("nedt->calcularVentoFF");
////	nedt->calcularVentoFF();
////
////	nedt->calcularTiro2_semRange();
////	p.resultados();
////	nedt->log(p.txt);
////
////	nedt->log("calculoTiroPontoObservado");
////	nedt->Vweth = 0; // vento ESTE propulsada
////	nedt->Vwnth = 0; // vento NORTE propulsada
////	nedt->Vweff = 0; // vento ESTE free flight
////	nedt->Vwnff = 0; // vento NORTE free flight
////	nedt->edtData.Vweth = 0; // vento ESTE propulsada
////	nedt->edtData.Vwnth = 0; // vento NORTE propulsada
////	nedt->edtData.Vweff = 0; // vento ESTE free flight
////	nedt->edtData.Vwnff = 0; // vento NORTE free flight
////
////	alvoVerdadeiro[0] = nedt->edtData.Etarg;
////	alvoVerdadeiro[1] = nedt->edtData.Ntarg;
////
////	nedt->calcularTiro2_semRange();
////	p.resultados();
////
////	// atualizando posicao alvo para calculo
////	p.posicaoImpacto();
////	nedt->log(p.txt);
////	nedt->edtData.Etarg -= nedt->posicaoFimDeVoo[0]-nedt->edtData.Etarg;
////	nedt->edtData.Ntarg -= nedt->posicaoFimDeVoo[1]-nedt->edtData.Ntarg;
////	p.posicaoImpacto();
////	nedt->log(p.txt);
////	nedt->calcularTiro2_semRange();
////
////	nedt->log("resultados com o alvo deslocado");
////	p.resultados();
////	nedt->log(p.txt);
////
////	// retornando posicao alvo original
////	nedt->edtData.Etarg = alvoVerdadeiro[0];
////	nedt->edtData.Ntarg = alvoVerdadeiro[1];
////
////	nedt->log("resultados com o alvo corrigido");
////	p.resultados();
////	nedt->log(p.txt);
////
////	//	p.resultados();
////
////	return 1;
//}

int testeLancamentoSimples(novaEdt *nedt){
	int fog = SS_80;
	nedt->ConfigEdt(fog);

	nedt->edtData.Elau       = 0;
	nedt->edtData.Nlau       = 0;
	nedt->edtData.Alt_launch = 0;
	nedt->edtData.Etarg      = 0;
	nedt->edtData.Ntarg      = 40000;
	nedt->edtData.Altarg     = 0;
	nedt->edtData.Alt_met    = 0;

	nedt->edtData.T0         = 15;
	nedt->edtData.Proptemp   = 15;
	nedt->edtData.P0         = 1013.25;

	nedt->edtData.Sec_bal    = (int)1;
	printf("secbal: %d\n",nedt->edtData.Sec_bal);

	nedt->edtData.Latitude   = -15;
	nedt->edtData.Elev_tiro  = 1072;

	nedt->edtData.Fusetime_input = 125;

	nedt->calcularTiro2();

	//	imprimirResultados(nedt);
	imprimir p(nedt);
	p.resultados();
	return 1;
}

//int testeLancamentoLeitura(novaEdt *nedt){
//	double lancamento[21]; // dados de lancamento
//	double tabelaVento[41][5]; // tabela de vento
//	double *ponteiroTabelaVento = tabelaVento[0];
//	int CntTrkData;
//
//	for (int var = 0; var <= 4500; ++var)
//		rastreio.RelativeTime[var] = -1;
//
//	// LENDO ARQUIVOS TXT
//	int fog;
//	int ret;
//	ret = lerAquivosTXT(&rastreio,&fog,lancamento,ponteiroTabelaVento,&CntTrkData);
//
//	if (!ret){
//		std::cout << "\nErro ao ler arquivos de dados" << std::endl;
//		return 0;
//	}
//
//	fog = SS_80;
//	nedt->ConfigEdt(fog);
//
//	nedt->calcularTiro2();
//
//	//	imprimirResultados(nedt);
//	imprimir p(nedt);
//	p.resultados();
//
//	return 1;
//}
//
//void testeContaDoZe(void){
//
//	//	double alvo[3] = {263765,8246154,0};
//	double alvo[3]        = {263765,8246145,0};
//	double po1[3]         = {262670,8250240,0};
//	double po2[3]         = {264796,8249229,0};
//	//	double ucf_nova_bi[3] = {259061,8252202,0};
//	double ucf_nova_bi[3] = {260944.2,8266987.4,0};
//
//	double stoina[3] = {261000.6,8266903.1,0};
//
//
//	double lmu[3]         = {259261,8251950,0};
//	double lmu2[3]        = {260993,8266660,0};
//	double azi;
//
//
//
//	printf("CONTA ZE -> ALVO:\n");
//	azi = bradock::contaDoZe(lmu,alvo)*180/3.14159265359/0.05625;
//	printf("azi: %.2f\n",azi);
//
//	printf("CONTA ZE -> PO1:\n");
//	azi = bradock::contaDoZe(lmu,po1)*180/3.14159265359/0.05625;
//	printf("azi: %.2f\n",azi);
//
//	printf("CONTA ZE -> UCF bi:\n");
//	azi = bradock::contaDoZe(lmu2,ucf_nova_bi)*180/3.14159265359/0.05625;
//	printf("azi: %.2f\n",azi);
//
//	printf("CONTA ZE -> sto:\n");
//	azi = bradock::contaDoZe(lmu2,stoina)*180/3.14159265359/0.05625;
//	printf("azi: %.2f\n",azi);
//}
//
//void testeExtrapolar2(novaEdt *nedt){
//	int fog = SS_40;
//	nedt->ConfigEdt(fog);
//
//	nedt->edtData.DDTType=3; nedt->edtData.Latitude=5; nedt->edtData.Sec_bal=(int)1 ; nedt->edtData.Metcm_included=1 ; nedt->edtData.Natm=19; nedt->edtData.Vwmetcm[0]=4; nedt->edtData.Vwmetcm[1]=9; nedt->edtData.Vwmetcm[2]=12; nedt->edtData.Vwmetcm[3]=13; nedt->edtData.Vwmetcm[4]=14; nedt->edtData.Vwmetcm[5]=16; nedt->edtData.Vwmetcm[6]=18; nedt->edtData.Vwmetcm[7]=12; nedt->edtData.Vwmetcm[8]=2; nedt->edtData.Vwmetcm[9]=3; nedt->edtData.Vwmetcm[10]=5; nedt->edtData.Vwmetcm[11]=3; nedt->edtData.Vwmetcm[12]=15; nedt->edtData.Vwmetcm[13]=14; nedt->edtData.Vwmetcm[14]=21; nedt->edtData.Vwmetcm[15]=26; nedt->edtData.Vwmetcm[16]=28; nedt->edtData.Vwmetcm[17]=29; nedt->edtData.Vwmetcm[18]=24; nedt->edtData.Vwmetcm[19]=25; nedt->edtData.Vwmetcm[20]=0; nedt->edtData.Vwmetcm[21]=0; nedt->edtData.Vwmetcm[22]=0; nedt->edtData.Vwmetcm[23]=0; nedt->edtData.Vwmetcm[24]=0; nedt->edtData.Vwmetcm[25]=0; nedt->edtData.Vwmetcm[26]=0; nedt->edtData.Vwmetcm[27]=0; nedt->edtData.Vwmetcm[28]=0; nedt->edtData.Vwmetcm[29]=0; nedt->edtData.Vwmetcm[30]=0; nedt->edtData.Vwmetcm[31]=0; nedt->edtData.Vwmetcm[32]=0; nedt->edtData.Vwmetcm[33]=0; nedt->edtData.Vwmetcm[34]=0; nedt->edtData.Vwmetcm[35]=0; nedt->edtData.Vwmetcm[36]=0; nedt->edtData.Vwmetcm[37]=0; nedt->edtData.Vwmetcm[38]=0; nedt->edtData.Vwmetcm[39]=0; nedt->edtData.Vwmetcm[40]=0; nedt->edtData.Azwmetcm[0]=1170; nedt->edtData.Azwmetcm[1]=1130; nedt->edtData.Azwmetcm[2]=1180; nedt->edtData.Azwmetcm[3]=1160; nedt->edtData.Azwmetcm[4]=1130; nedt->edtData.Azwmetcm[5]=1180; nedt->edtData.Azwmetcm[6]=1280; nedt->edtData.Azwmetcm[7]=1390; nedt->edtData.Azwmetcm[8]=1910; nedt->edtData.Azwmetcm[9]=3780; nedt->edtData.Azwmetcm[10]=3910; nedt->edtData.Azwmetcm[11]=5680; nedt->edtData.Azwmetcm[12]=4880; nedt->edtData.Azwmetcm[13]=5140; nedt->edtData.Azwmetcm[14]=4270; nedt->edtData.Azwmetcm[15]=4190; nedt->edtData.Azwmetcm[16]=4140; nedt->edtData.Azwmetcm[17]=3990; nedt->edtData.Azwmetcm[18]=3890; nedt->edtData.Azwmetcm[19]=3910; nedt->edtData.Azwmetcm[20]=0; nedt->edtData.Azwmetcm[21]=0; nedt->edtData.Azwmetcm[22]=0; nedt->edtData.Azwmetcm[23]=0; nedt->edtData.Azwmetcm[24]=0; nedt->edtData.Azwmetcm[25]=0; nedt->edtData.Azwmetcm[26]=0; nedt->edtData.Azwmetcm[27]=0; nedt->edtData.Azwmetcm[28]=0; nedt->edtData.Azwmetcm[29]=0; nedt->edtData.Azwmetcm[30]=0; nedt->edtData.Azwmetcm[31]=0; nedt->edtData.Azwmetcm[32]=0; nedt->edtData.Azwmetcm[33]=0; nedt->edtData.Azwmetcm[34]=0; nedt->edtData.Azwmetcm[35]=0; nedt->edtData.Azwmetcm[36]=0; nedt->edtData.Azwmetcm[37]=0; nedt->edtData.Azwmetcm[38]=0; nedt->edtData.Azwmetcm[39]=0; nedt->edtData.Azwmetcm[40]=0; nedt->edtData.Tent[0]=307.200012207031; nedt->edtData.Tent[1]=301.799987792969; nedt->edtData.Tent[2]=299.200012207031; nedt->edtData.Tent[3]=295.5; nedt->edtData.Tent[4]=290.799987792969; nedt->edtData.Tent[5]=286.899993896484; nedt->edtData.Tent[6]=283.299987792969; nedt->edtData.Tent[7]=279.600006103516; nedt->edtData.Tent[8]=277.299987792969; nedt->edtData.Tent[9]=273.5; nedt->edtData.Tent[10]=270.700012207031; nedt->edtData.Tent[11]=267.200012207031; nedt->edtData.Tent[12]=264.5; nedt->edtData.Tent[13]=257.100006103516; nedt->edtData.Tent[14]=249.5; nedt->edtData.Tent[15]=244; nedt->edtData.Tent[16]=235.899993896484; nedt->edtData.Tent[17]=227.800003051758; nedt->edtData.Tent[18]=219.600006103516; nedt->edtData.Tent[19]=215.300003051758; nedt->edtData.Tent[20]=0; nedt->edtData.Tent[21]=0; nedt->edtData.Tent[22]=0; nedt->edtData.Tent[23]=0; nedt->edtData.Tent[24]=0; nedt->edtData.Tent[25]=0; nedt->edtData.Tent[26]=0; nedt->edtData.Tent[27]=0; nedt->edtData.Tent[28]=0; nedt->edtData.Tent[29]=0; nedt->edtData.Tent[30]=0; nedt->edtData.Tent[31]=0; nedt->edtData.Tent[32]=0; nedt->edtData.Tent[33]=0; nedt->edtData.Tent[34]=0; nedt->edtData.Tent[35]=0; nedt->edtData.Tent[36]=0; nedt->edtData.Tent[37]=0; nedt->edtData.Tent[38]=0; nedt->edtData.Tent[39]=0; nedt->edtData.Tent[40]=0; nedt->edtData.Pent[0]=906; nedt->edtData.Pent[1]=895; nedt->edtData.Pent[2]=870; nedt->edtData.Pent[3]=831; nedt->edtData.Pent[4]=784; nedt->edtData.Pent[5]=739; nedt->edtData.Pent[6]=696; nedt->edtData.Pent[7]=655; nedt->edtData.Pent[8]=616; nedt->edtData.Pent[9]=579; nedt->edtData.Pent[10]=544; nedt->edtData.Pent[11]=510; nedt->edtData.Pent[12]=463; nedt->edtData.Pent[13]=406; nedt->edtData.Pent[14]=355; nedt->edtData.Pent[15]=309; nedt->edtData.Pent[16]=268; nedt->edtData.Pent[17]=231; nedt->edtData.Pent[18]=199; nedt->edtData.Pent[19]=170; nedt->edtData.Pent[20]=0; nedt->edtData.Pent[21]=0; nedt->edtData.Pent[22]=0; nedt->edtData.Pent[23]=0; nedt->edtData.Pent[24]=0; nedt->edtData.Pent[25]=0; nedt->edtData.Pent[26]=0; nedt->edtData.Pent[27]=0; nedt->edtData.Pent[28]=0; nedt->edtData.Pent[29]=0; nedt->edtData.Pent[30]=0; nedt->edtData.Pent[31]=0; nedt->edtData.Pent[32]=0; nedt->edtData.Pent[33]=0; nedt->edtData.Pent[34]=0; nedt->edtData.Pent[35]=0; nedt->edtData.Pent[36]=0; nedt->edtData.Pent[37]=0; nedt->edtData.Pent[38]=0; nedt->edtData.Pent[39]=0; nedt->edtData.Pent[40]=0; nedt->edtData.Alt_met=1021; nedt->edtData.Azwcor=0; nedt->edtData.T0=30.5; nedt->edtData.P0=900.125; nedt->edtData.Proptemp=30.5; nedt->edtData.Vws=9.33625; nedt->edtData.Azws=1410.46666666667; nedt->edtData.Altfg=1021; nedt->edtData.RefDir=0; nedt->edtData.Elau=260992; nedt->edtData.Nlau=8266660; nedt->edtData.Alt_launch=1004; nedt->edtData.Etarg=263769; nedt->edtData.Ntarg=8246145; nedt->edtData.Altarg=972; nedt->edtData.Azim_tiro=3578; nedt->edtData.Elev_tiro=533; nedt->edtData.Fusetime_input=0; nedt->edtData.Vweth=0; nedt->edtData.Vwnth=0; nedt->edtData.Vweff=0; nedt->edtData.Vwnff=0; nedt->edtData.Elev_max=60; nedt->edtData.CalType=3;
//	//	nedt->Vweth = -1.18318;
//	//	nedt->Vwnth = -1.59478;
//	//	nedt->Vweff = -3.09412;
//	//	nedt->Vwnff = 3.80189;
//
//	nedt->voarCompleto();
//
//	//	imprimirResultados(nedt);
//	imprimir p(nedt);
//	p.resultados();
//}
//
//void testeExtrapolar(novaEdt *nedt){
//	int fog = SS_40;
//	nedt->ConfigEdt(fog);
//
//	nedt->edtData.DDTType = 3; nedt->edtData.Latitude = 5; nedt->edtData.Sec_bal = (int)1; nedt->edtData.Metcm_included = 1; nedt->edtData.Natm = 12; nedt->edtData.Vwmetcm[0] = 4; nedt->edtData.Vwmetcm[1] = 9; nedt->edtData.Vwmetcm[2] = 10; nedt->edtData.Vwmetcm[3] = 9; nedt->edtData.Vwmetcm[4] = 10; nedt->edtData.Vwmetcm[5] = 5; nedt->edtData.Vwmetcm[6] = 7; nedt->edtData.Vwmetcm[7] = 8; nedt->edtData.Vwmetcm[8] = 10; nedt->edtData.Vwmetcm[9] = 8; nedt->edtData.Vwmetcm[10] = 2; nedt->edtData.Vwmetcm[11] = 6; nedt->edtData.Vwmetcm[12] = 10; nedt->edtData.Vwmetcm[13] = 0; nedt->edtData.Vwmetcm[14] = 0; nedt->edtData.Vwmetcm[15] = 0; nedt->edtData.Vwmetcm[16] = 0; nedt->edtData.Vwmetcm[17] = 0; nedt->edtData.Vwmetcm[18] = 0; nedt->edtData.Vwmetcm[19] = 0; nedt->edtData.Vwmetcm[20] = 0; nedt->edtData.Vwmetcm[21] = 0; nedt->edtData.Vwmetcm[22] = 0; nedt->edtData.Vwmetcm[23] = 0; nedt->edtData.Vwmetcm[24] = 0; nedt->edtData.Vwmetcm[25] = 0; nedt->edtData.Vwmetcm[26] = 0; nedt->edtData.Vwmetcm[27] = 0; nedt->edtData.Vwmetcm[28] = 0; nedt->edtData.Vwmetcm[29] = 0; nedt->edtData.Vwmetcm[30] = 0; nedt->edtData.Vwmetcm[31] = 0; nedt->edtData.Vwmetcm[32] = 0; nedt->edtData.Vwmetcm[33] = 0; nedt->edtData.Vwmetcm[34] = 0; nedt->edtData.Vwmetcm[35] = 0; nedt->edtData.Vwmetcm[36] = 0; nedt->edtData.Vwmetcm[37] = 0; nedt->edtData.Vwmetcm[38] = 0; nedt->edtData.Vwmetcm[39] = 0; nedt->edtData.Vwmetcm[40] = 0; nedt->edtData.Azwmetcm[0] = 2140; nedt->edtData.Azwmetcm[1] = 1960; nedt->edtData.Azwmetcm[2] = 1960; nedt->edtData.Azwmetcm[3] = 1710; nedt->edtData.Azwmetcm[4] = 1300; nedt->edtData.Azwmetcm[5] = 910; nedt->edtData.Azwmetcm[6] = 610; nedt->edtData.Azwmetcm[7] = 210; nedt->edtData.Azwmetcm[8] = 30; nedt->edtData.Azwmetcm[9] = 460; nedt->edtData.Azwmetcm[10] = 1470; nedt->edtData.Azwmetcm[11] = 4080; nedt->edtData.Azwmetcm[12] = 4220; nedt->edtData.Azwmetcm[13] = 0; nedt->edtData.Azwmetcm[14] = 0; nedt->edtData.Azwmetcm[15] = 0; nedt->edtData.Azwmetcm[16] = 0; nedt->edtData.Azwmetcm[17] = 0; nedt->edtData.Azwmetcm[18] = 0; nedt->edtData.Azwmetcm[19] = 0; nedt->edtData.Azwmetcm[20] = 0; nedt->edtData.Azwmetcm[21] = 0; nedt->edtData.Azwmetcm[22] = 0; nedt->edtData.Azwmetcm[23] = 0; nedt->edtData.Azwmetcm[24] = 0; nedt->edtData.Azwmetcm[25] = 0; nedt->edtData.Azwmetcm[26] = 0; nedt->edtData.Azwmetcm[27] = 0; nedt->edtData.Azwmetcm[28] = 0; nedt->edtData.Azwmetcm[29] = 0; nedt->edtData.Azwmetcm[30] = 0; nedt->edtData.Azwmetcm[31] = 0; nedt->edtData.Azwmetcm[32] = 0; nedt->edtData.Azwmetcm[33] = 0; nedt->edtData.Azwmetcm[34] = 0; nedt->edtData.Azwmetcm[35] = 0; nedt->edtData.Azwmetcm[36] = 0; nedt->edtData.Azwmetcm[37] = 0; nedt->edtData.Azwmetcm[38] = 0; nedt->edtData.Azwmetcm[39] = 0; nedt->edtData.Azwmetcm[40] = 0; nedt->edtData.Tent[0] = 300.899993896484; nedt->edtData.Tent[1] = 300.600006103516; nedt->edtData.Tent[2] = 299.799987792969; nedt->edtData.Tent[3] = 296.399993896484; nedt->edtData.Tent[4] = 292.100006103516; nedt->edtData.Tent[5] = 288; nedt->edtData.Tent[6] = 283.700012207031; nedt->edtData.Tent[7] = 280; nedt->edtData.Tent[8] = 276; nedt->edtData.Tent[9] = 273.299987792969; nedt->edtData.Tent[10] = 270.600006103516; nedt->edtData.Tent[11] = 267.399993896484; nedt->edtData.Tent[12] = 265.399993896484; nedt->edtData.Tent[13] = 0; nedt->edtData.Tent[14] = 0; nedt->edtData.Tent[15] = 0; nedt->edtData.Tent[16] = 0; nedt->edtData.Tent[17] = 0; nedt->edtData.Tent[18] = 0; nedt->edtData.Tent[19] = 0; nedt->edtData.Tent[20] = 0; nedt->edtData.Tent[21] = 0; nedt->edtData.Tent[22] = 0; nedt->edtData.Tent[23] = 0; nedt->edtData.Tent[24] = 0; nedt->edtData.Tent[25] = 0; nedt->edtData.Tent[26] = 0; nedt->edtData.Tent[27] = 0; nedt->edtData.Tent[28] = 0; nedt->edtData.Tent[29] = 0; nedt->edtData.Tent[30] = 0; nedt->edtData.Tent[31] = 0; nedt->edtData.Tent[32] = 0; nedt->edtData.Tent[33] = 0; nedt->edtData.Tent[34] = 0; nedt->edtData.Tent[35] = 0; nedt->edtData.Tent[36] = 0; nedt->edtData.Tent[37] = 0; nedt->edtData.Tent[38] = 0; nedt->edtData.Tent[39] = 0; nedt->edtData.Tent[40] = 0; nedt->edtData.Pent[0] = 902; nedt->edtData.Pent[1] = 892; nedt->edtData.Pent[2] = 867; nedt->edtData.Pent[3] = 828; nedt->edtData.Pent[4] = 781; nedt->edtData.Pent[5] = 736; nedt->edtData.Pent[6] = 694; nedt->edtData.Pent[7] = 653; nedt->edtData.Pent[8] = 614; nedt->edtData.Pent[9] = 577; nedt->edtData.Pent[10] = 542; nedt->edtData.Pent[11] = 508; nedt->edtData.Pent[12] = 462; nedt->edtData.Pent[13] = 0; nedt->edtData.Pent[14] = 0; nedt->edtData.Pent[15] = 0; nedt->edtData.Pent[16] = 0; nedt->edtData.Pent[17] = 0; nedt->edtData.Pent[18] = 0; nedt->edtData.Pent[19] = 0; nedt->edtData.Pent[20] = 0; nedt->edtData.Pent[21] = 0; nedt->edtData.Pent[22] = 0; nedt->edtData.Pent[23] = 0; nedt->edtData.Pent[24] = 0; nedt->edtData.Pent[25] = 0; nedt->edtData.Pent[26] = 0; nedt->edtData.Pent[27] = 0; nedt->edtData.Pent[28] = 0; nedt->edtData.Pent[29] = 0; nedt->edtData.Pent[30] = 0; nedt->edtData.Pent[31] = 0; nedt->edtData.Pent[32] = 0; nedt->edtData.Pent[33] = 0; nedt->edtData.Pent[34] = 0; nedt->edtData.Pent[35] = 0; nedt->edtData.Pent[36] = 0; nedt->edtData.Pent[37] = 0; nedt->edtData.Pent[38] = 0; nedt->edtData.Pent[39] = 0; nedt->edtData.Pent[40] = 0; nedt->edtData.Alt_met = 1018; nedt->edtData.Azwcor = 0; nedt->edtData.T0 = 24.625; nedt->edtData.P0 = 900.3125; nedt->edtData.Proptemp = 24.625; nedt->edtData.Vws = 4.365; nedt->edtData.Azws = 2378.23333333333; nedt->edtData.Altfg = 1021; nedt->edtData.RefDir = 0; nedt->edtData.Elau = 260992; nedt->edtData.Nlau = 8266660; nedt->edtData.Alt_launch = 1004; nedt->edtData.Etarg = 263769; nedt->edtData.Ntarg = 8246145; nedt->edtData.Altarg = 971; nedt->edtData.Azim_tiro = 3068; nedt->edtData.Elev_tiro = 428; nedt->edtData.Fusetime_input = 36.0864078812592; nedt->edtData.Vweth = 0; nedt->edtData.Vwnth = 0; nedt->edtData.Vweff = 0; nedt->edtData.Vwnff = 0; nedt->edtData.Elev_max = 60;
//	nedt->edtData.CalType = 3;
//
//	condicaoInicial inicio;
//	inicio.extrapolar = TRUE; // <-------- DERSO, CONFERE ISSO LAH
//	inicio.tempo      = 31.03500; //C0_extrap[0];
//	inicio.pos[0]     = -479.63000; //C0_extrap[1];
//	inicio.pos[1]     = 17952.75000; //C0_extrap[2];
//	inicio.pos[2]     = 1952.89000; //C0_extrap[3];
//	inicio.vel[0]     = -9.26000; //C0_extrap[4];
//	inicio.vel[1]     = 341.73000; //C0_extrap[5];
//	inicio.vel[2]     = -81.72000; //C0_extrap[6];
//
//	nedt->edtData.Vweth = -1.18318;
//	nedt->edtData.Vwnth = -1.59478;
//	nedt->edtData.Vweff = -3.09412;
//	nedt->edtData.Vwnff = 3.80189;
//
//	nedt->posicaoFimDeQueima[0]    = -284.86000;
//	nedt->posicaoFimDeQueima[1]    = 10652.54000;
//	nedt->posicaoFimDeQueima[2]    = 2168.12000;
//	nedt->velocidadeFimDeQueima[0] = -16.21000;
//	nedt->velocidadeFimDeQueima[1] = 615.37000;
//	nedt->velocidadeFimDeQueima[2] = 68.92000;
//
//	nedt->posicaoFimDeVoo[0] = 264081.69;
//	nedt->posicaoFimDeVoo[1] = 8246399.82;
//	nedt->posicaoFimDeVoo[2] = -33;
//
//	//	nedt->edtData.CalType = 3;
//	printf("CalType: %d\n",nedt->edtData.CalType);
//	nedt->voarExtrapolando(&inicio);
//
//	nedt->calcularTiro2();
//
//	//	imprimirResultados(nedt);
//	imprimir p(nedt);
//	p.resultados();
//}
//
//void testeFireFor(novaEdt *nedt){
//	int fog = SS_40;
//	nedt->ConfigEdt(fog);
//
//	nedt->edtData.DDTType=3; nedt->edtData.Latitude=5; nedt->edtData.Sec_bal=1 ; nedt->edtData.Metcm_included=1 ; nedt->edtData.Natm=13; nedt->edtData.Vwmetcm[0]=6; nedt->edtData.Vwmetcm[1]=9; nedt->edtData.Vwmetcm[2]=7; nedt->edtData.Vwmetcm[3]=8; nedt->edtData.Vwmetcm[4]=7; nedt->edtData.Vwmetcm[5]=7; nedt->edtData.Vwmetcm[6]=11; nedt->edtData.Vwmetcm[7]=8; nedt->edtData.Vwmetcm[8]=6; nedt->edtData.Vwmetcm[9]=9; nedt->edtData.Vwmetcm[10]=11; nedt->edtData.Vwmetcm[11]=15; nedt->edtData.Vwmetcm[12]=20; nedt->edtData.Vwmetcm[13]=22; nedt->edtData.Vwmetcm[14]=0; nedt->edtData.Vwmetcm[15]=0; nedt->edtData.Vwmetcm[16]=0; nedt->edtData.Vwmetcm[17]=0; nedt->edtData.Vwmetcm[18]=0; nedt->edtData.Vwmetcm[19]=0; nedt->edtData.Vwmetcm[20]=0; nedt->edtData.Vwmetcm[21]=0; nedt->edtData.Vwmetcm[22]=0; nedt->edtData.Vwmetcm[23]=0; nedt->edtData.Vwmetcm[24]=0; nedt->edtData.Vwmetcm[25]=0; nedt->edtData.Vwmetcm[26]=0; nedt->edtData.Vwmetcm[27]=0; nedt->edtData.Vwmetcm[28]=0; nedt->edtData.Vwmetcm[29]=0; nedt->edtData.Vwmetcm[30]=0; nedt->edtData.Vwmetcm[31]=0; nedt->edtData.Vwmetcm[32]=0; nedt->edtData.Vwmetcm[33]=0; nedt->edtData.Vwmetcm[34]=0; nedt->edtData.Vwmetcm[35]=0; nedt->edtData.Vwmetcm[36]=0; nedt->edtData.Vwmetcm[37]=0; nedt->edtData.Vwmetcm[38]=0; nedt->edtData.Vwmetcm[39]=0; nedt->edtData.Vwmetcm[40]=0; nedt->edtData.Azwmetcm[0]=1960; nedt->edtData.Azwmetcm[1]=1850; nedt->edtData.Azwmetcm[2]=1520; nedt->edtData.Azwmetcm[3]=1320; nedt->edtData.Azwmetcm[4]=1650; nedt->edtData.Azwmetcm[5]=1750; nedt->edtData.Azwmetcm[6]=2060; nedt->edtData.Azwmetcm[7]=2020; nedt->edtData.Azwmetcm[8]=1860; nedt->edtData.Azwmetcm[9]=1630; nedt->edtData.Azwmetcm[10]=2340; nedt->edtData.Azwmetcm[11]=2360; nedt->edtData.Azwmetcm[12]=2750; nedt->edtData.Azwmetcm[13]=3000; nedt->edtData.Azwmetcm[14]=0; nedt->edtData.Azwmetcm[15]=0; nedt->edtData.Azwmetcm[16]=0; nedt->edtData.Azwmetcm[17]=0; nedt->edtData.Azwmetcm[18]=0; nedt->edtData.Azwmetcm[19]=0; nedt->edtData.Azwmetcm[20]=0; nedt->edtData.Azwmetcm[21]=0; nedt->edtData.Azwmetcm[22]=0; nedt->edtData.Azwmetcm[23]=0; nedt->edtData.Azwmetcm[24]=0; nedt->edtData.Azwmetcm[25]=0; nedt->edtData.Azwmetcm[26]=0; nedt->edtData.Azwmetcm[27]=0; nedt->edtData.Azwmetcm[28]=0; nedt->edtData.Azwmetcm[29]=0; nedt->edtData.Azwmetcm[30]=0; nedt->edtData.Azwmetcm[31]=0; nedt->edtData.Azwmetcm[32]=0; nedt->edtData.Azwmetcm[33]=0; nedt->edtData.Azwmetcm[34]=0; nedt->edtData.Azwmetcm[35]=0; nedt->edtData.Azwmetcm[36]=0; nedt->edtData.Azwmetcm[37]=0; nedt->edtData.Azwmetcm[38]=0; nedt->edtData.Azwmetcm[39]=0; nedt->edtData.Azwmetcm[40]=0; nedt->edtData.Tent[0]=306.399993896484; nedt->edtData.Tent[1]=303.399993896484; nedt->edtData.Tent[2]=301; nedt->edtData.Tent[3]=297.200012207031; nedt->edtData.Tent[4]=292.399993896484; nedt->edtData.Tent[5]=287.700012207031; nedt->edtData.Tent[6]=283.5; nedt->edtData.Tent[7]=280.5; nedt->edtData.Tent[8]=275.799987792969; nedt->edtData.Tent[9]=272.100006103516; nedt->edtData.Tent[10]=269.5; nedt->edtData.Tent[11]=268.299987792969; nedt->edtData.Tent[12]=263.899993896484; nedt->edtData.Tent[13]=260.5; nedt->edtData.Tent[14]=0; nedt->edtData.Tent[15]=0; nedt->edtData.Tent[16]=0; nedt->edtData.Tent[17]=0; nedt->edtData.Tent[18]=0; nedt->edtData.Tent[19]=0; nedt->edtData.Tent[20]=0; nedt->edtData.Tent[21]=0; nedt->edtData.Tent[22]=0; nedt->edtData.Tent[23]=0; nedt->edtData.Tent[24]=0; nedt->edtData.Tent[25]=0; nedt->edtData.Tent[26]=0; nedt->edtData.Tent[27]=0; nedt->edtData.Tent[28]=0; nedt->edtData.Tent[29]=0; nedt->edtData.Tent[30]=0; nedt->edtData.Tent[31]=0; nedt->edtData.Tent[32]=0; nedt->edtData.Tent[33]=0; nedt->edtData.Tent[34]=0; nedt->edtData.Tent[35]=0; nedt->edtData.Tent[36]=0; nedt->edtData.Tent[37]=0; nedt->edtData.Tent[38]=0; nedt->edtData.Tent[39]=0; nedt->edtData.Tent[40]=0; nedt->edtData.Pent[0]=905; nedt->edtData.Pent[1]=895; nedt->edtData.Pent[2]=870; nedt->edtData.Pent[3]=831; nedt->edtData.Pent[4]=784; nedt->edtData.Pent[5]=740; nedt->edtData.Pent[6]=697; nedt->edtData.Pent[7]=656; nedt->edtData.Pent[8]=617; nedt->edtData.Pent[9]=579; nedt->edtData.Pent[10]=544; nedt->edtData.Pent[11]=510; nedt->edtData.Pent[12]=463; nedt->edtData.Pent[13]=407; nedt->edtData.Pent[14]=0; nedt->edtData.Pent[15]=0; nedt->edtData.Pent[16]=0; nedt->edtData.Pent[17]=0; nedt->edtData.Pent[18]=0; nedt->edtData.Pent[19]=0; nedt->edtData.Pent[20]=0; nedt->edtData.Pent[21]=0; nedt->edtData.Pent[22]=0; nedt->edtData.Pent[23]=0; nedt->edtData.Pent[24]=0; nedt->edtData.Pent[25]=0; nedt->edtData.Pent[26]=0; nedt->edtData.Pent[27]=0; nedt->edtData.Pent[28]=0; nedt->edtData.Pent[29]=0; nedt->edtData.Pent[30]=0; nedt->edtData.Pent[31]=0; nedt->edtData.Pent[32]=0; nedt->edtData.Pent[33]=0; nedt->edtData.Pent[34]=0; nedt->edtData.Pent[35]=0; nedt->edtData.Pent[36]=0; nedt->edtData.Pent[37]=0; nedt->edtData.Pent[38]=0; nedt->edtData.Pent[39]=0; nedt->edtData.Pent[40]=0; nedt->edtData.Alt_met=976; nedt->edtData.Azwcor=0; nedt->edtData.T0=33.5625; nedt->edtData.P0=902.375; nedt->edtData.Proptemp=33.5625; nedt->edtData.Vws=5.0925; nedt->edtData.Azws=2461.06666666667; nedt->edtData.Altfg=976; nedt->edtData.RefDir=0; nedt->edtData.Elau=262544; nedt->edtData.Nlau=8277043; nedt->edtData.Alt_launch=980; nedt->edtData.Etarg=263811; nedt->edtData.Ntarg=8245068; nedt->edtData.Altarg=970; nedt->edtData.Azim_tiro=3105; nedt->edtData.Elev_tiro=496; nedt->edtData.Fusetime_input=81.472921603969; nedt->edtData.Vweth=0; nedt->edtData.Vwnth=0; nedt->edtData.Vweff=0; nedt->edtData.Vwnff=0; nedt->edtData.Elev_max=60; nedt->edtData.CalType=3;
//	//	nedt->edtData.Vweth = 11.72250;
//	//	nedt->edtData.Vwnth = -63.33643;
//	//	nedt->edtData.Vweff = 0.00000;
//	//	nedt->edtData.Vwnff = 0.00000;
//
//	//	nedt->Vweth = 11.72250;
//	//	nedt->Vwnth = -63.33643;
//	//	nedt->Vweff = 0.00000;
//	//	nedt->Vwnff = 0.00000;
//
//	imprimir p(nedt);
//
//	//	nedt->log("nedt->calcularRangeMin");
//	//	nedt->calcularRangeMin();
//	//	nedt->log("nedt->calcularRangeMax");
//	//	nedt->calcularRangeMax();
//	//	nedt->log("nedt->calcularTiro2_semRange");
//	//	nedt->calcularTiro2_semRange();
//
//	//	nedt->log("nedt->calcularTiro2");
//	//	nedt->calcularTiro2();
//	//	p.resultados();
//	//	nedt->log(p.txt);
//
//	nedt->log("nedt->calcularVentoTH");
//	nedt->calcularVentoTH();
//	nedt->log("nedt->calcularVentoFF");
//	nedt->calcularVentoFF();
//
//	//	nedt->Vweth = -1.18318;
//	//	nedt->Vwnth = -1.59478;
//	//	nedt->Vweff = -3.09412;
//	//	nedt->Vwnff =  3.80189;
//
//	nedt->log("nedt->estimacaoVento");
//	p.estimacaoVento();
//	nedt->log(p.txt);
//
//	//	nedt->voarCompleto();
//
//	//	imprimirResultados(nedt);
//	p.resultados();
//	nedt->log(p.txt);
//
//}
//
//int testeLancamentoEdtData(novaEdt *nedt){
//	int fog = RHAN;
//	nedt->ConfigEdt(fog);
//
//	nedt->edtData.DDTType = 7; nedt->edtData.Latitude = 5; nedt->edtData.Sec_bal = 0; nedt->edtData.Metcm_included = 1;
//	nedt->edtData.Natm    = 12; nedt->edtData.Vwmetcm[0] = 2; nedt->edtData.Vwmetcm[1] = 4; nedt->edtData.Vwmetcm[2] = 8; nedt->edtData.Vwmetcm[3] = 8; nedt->edtData.Vwmetcm[4] = 11; nedt->edtData.Vwmetcm[5] = 15; nedt->edtData.Vwmetcm[6] = 14; nedt->edtData.Vwmetcm[7] = 10; nedt->edtData.Vwmetcm[8] = 3; nedt->edtData.Vwmetcm[9] = 3; nedt->edtData.Vwmetcm[10] = 13; nedt->edtData.Vwmetcm[11] = 13; nedt->edtData.Vwmetcm[12] = 16; nedt->edtData.Vwmetcm[13] = 0; nedt->edtData.Vwmetcm[14] = 0; nedt->edtData.Vwmetcm[15] = 0; nedt->edtData.Vwmetcm[16] = 0; nedt->edtData.Vwmetcm[17] = 0; nedt->edtData.Vwmetcm[18] = 0; nedt->edtData.Vwmetcm[19] = 0; nedt->edtData.Vwmetcm[20] = 0; nedt->edtData.Vwmetcm[21] = 0; nedt->edtData.Vwmetcm[22] = 0; nedt->edtData.Vwmetcm[23] = 0; nedt->edtData.Vwmetcm[24] = 0; nedt->edtData.Vwmetcm[25] = 0; nedt->edtData.Vwmetcm[26] = 0; nedt->edtData.Vwmetcm[27] = 0; nedt->edtData.Vwmetcm[28] = 0; nedt->edtData.Vwmetcm[29] = 0; nedt->edtData.Vwmetcm[30] = 0; nedt->edtData.Vwmetcm[31] = 0; nedt->edtData.Vwmetcm[32] = 0; nedt->edtData.Vwmetcm[33] = 0; nedt->edtData.Vwmetcm[34] = 0; nedt->edtData.Vwmetcm[35] = 0; nedt->edtData.Vwmetcm[36] = 0; nedt->edtData.Vwmetcm[37] = 0; nedt->edtData.Vwmetcm[38] = 0; nedt->edtData.Vwmetcm[39] = 0; nedt->edtData.Vwmetcm[40] = 0; nedt->edtData.Azwmetcm[0] = 570; nedt->edtData.Azwmetcm[1] = 340; nedt->edtData.Azwmetcm[2] = 510; nedt->edtData.Azwmetcm[3] = 870; nedt->edtData.Azwmetcm[4] = 2220; nedt->edtData.Azwmetcm[5] = 2190; nedt->edtData.Azwmetcm[6] = 1880; nedt->edtData.Azwmetcm[7] = 2160; nedt->edtData.Azwmetcm[8] = 1910; nedt->edtData.Azwmetcm[9] = 1910; nedt->edtData.Azwmetcm[10] = 2800; nedt->edtData.Azwmetcm[11] = 2110; nedt->edtData.Azwmetcm[12] = 2740; nedt->edtData.Azwmetcm[13] = 3060; nedt->edtData.Azwmetcm[14] = 2980; nedt->edtData.Azwmetcm[15] = 0; nedt->edtData.Azwmetcm[16] = 0; nedt->edtData.Azwmetcm[17] = 0; nedt->edtData.Azwmetcm[18] = 0; nedt->edtData.Azwmetcm[19] = 0; nedt->edtData.Azwmetcm[20] = 0; nedt->edtData.Azwmetcm[21] = 0; nedt->edtData.Azwmetcm[22] = 0; nedt->edtData.Azwmetcm[23] = 0; nedt->edtData.Azwmetcm[24] = 0; nedt->edtData.Azwmetcm[25] = 0; nedt->edtData.Azwmetcm[26] = 0; nedt->edtData.Azwmetcm[27] = 0; nedt->edtData.Azwmetcm[28] = 0; nedt->edtData.Azwmetcm[29] = 0; nedt->edtData.Azwmetcm[30] = 0; nedt->edtData.Azwmetcm[31] = 0; nedt->edtData.Azwmetcm[32] = 0; nedt->edtData.Azwmetcm[33] = 0; nedt->edtData.Azwmetcm[34] = 0; nedt->edtData.Azwmetcm[35] = 0; nedt->edtData.Azwmetcm[36] = 0; nedt->edtData.Azwmetcm[37] = 0; nedt->edtData.Azwmetcm[38] = 0; nedt->edtData.Azwmetcm[39] = 0; nedt->edtData.Azwmetcm[40] = 0; nedt->edtData.Tent[0]  = 302.1; nedt->edtData.Tent[1]  = 301.6; nedt->edtData.Tent[2]  = 298.4; nedt->edtData.Tent[3]  = 294.2; nedt->edtData.Tent[4]  = 290.8; nedt->edtData.Tent[5]  = 287.5; nedt->edtData.Tent[6]  = 283.7; nedt->edtData.Tent[7]  = 279.4; nedt->edtData.Tent[8]  = 276.0; nedt->edtData.Tent[9]  = 271.7; nedt->edtData.Tent[10] = 270.6; nedt->edtData.Tent[11] = 269.0; nedt->edtData.Tent[12] = 264.3; nedt->edtData.Tent[13] = 257.8; nedt->edtData.Tent[14] = 252.5; nedt->edtData.Tent[15] = 0; nedt->edtData.Tent[16] = 0; nedt->edtData.Tent[17] = 0; nedt->edtData.Tent[18] = 0; nedt->edtData.Tent[19] = 0; nedt->edtData.Tent[20] = 0; nedt->edtData.Tent[21] = 0; nedt->edtData.Tent[22] = 0; nedt->edtData.Tent[23] = 0; nedt->edtData.Tent[24] = 0; nedt->edtData.Tent[25] = 0; nedt->edtData.Tent[26] = 0; nedt->edtData.Tent[27] = 0; nedt->edtData.Tent[28] = 0; nedt->edtData.Tent[29] = 0; nedt->edtData.Tent[30] = 0; nedt->edtData.Tent[31] = 0; nedt->edtData.Tent[32] = 0; nedt->edtData.Tent[33] = 0; nedt->edtData.Tent[34] = 0; nedt->edtData.Tent[35] = 0; nedt->edtData.Tent[36] = 0; nedt->edtData.Tent[37] = 0; nedt->edtData.Tent[38] = 0; nedt->edtData.Tent[39] = 0; nedt->edtData.Tent[40] = 0; nedt->edtData.Pent[0]  = 906; nedt->edtData.Pent[1]  = 896; nedt->edtData.Pent[2]  = 871; nedt->edtData.Pent[3]  = 832; nedt->edtData.Pent[4]  = 784; nedt->edtData.Pent[5]  = 739; nedt->edtData.Pent[6]  = 697; nedt->edtData.Pent[7]  = 656; nedt->edtData.Pent[8]  = 616; nedt->edtData.Pent[9]  = 579; nedt->edtData.Pent[10] = 544; nedt->edtData.Pent[11] = 510; nedt->edtData.Pent[12] = 464; nedt->edtData.Pent[13] = 407; nedt->edtData.Pent[14] = 356; nedt->edtData.Pent[15] = 0; nedt->edtData.Pent[16] = 0; nedt->edtData.Pent[17] = 0; nedt->edtData.Pent[18] = 0; nedt->edtData.Pent[19] = 0; nedt->edtData.Pent[20] = 0; nedt->edtData.Pent[21] = 0; nedt->edtData.Pent[22] = 0; nedt->edtData.Pent[23] = 0; nedt->edtData.Pent[24] = 0; nedt->edtData.Pent[25] = 0; nedt->edtData.Pent[26] = 0; nedt->edtData.Pent[27] = 0; nedt->edtData.Pent[28] = 0; nedt->edtData.Pent[29] = 0; nedt->edtData.Pent[30] = 0; nedt->edtData.Pent[31] = 0; nedt->edtData.Pent[32] = 0; nedt->edtData.Pent[33] = 0; nedt->edtData.Pent[34] = 0; nedt->edtData.Pent[35] = 0; nedt->edtData.Pent[36] = 0; nedt->edtData.Pent[37] = 0; nedt->edtData.Pent[38] = 0; nedt->edtData.Pent[39] = 0; nedt->edtData.Pent[40] = 0;
//	nedt->edtData.Alt_met = 976; nedt->edtData.Azwcor = 0;
//
//	nedt->edtData.Natm     = 10;
//	nedt->edtData.T0       = 30.4375;
//	nedt->edtData.P0       = 905.5625;
//	nedt->edtData.Proptemp = 30.4375;
//	nedt->edtData.Vws      = 8.12375;
//	nedt->edtData.Azws     = 563.188888888889;
//
//	nedt->edtData.Altfg   = 976; nedt->edtData.RefDir = 0; nedt->edtData.Elau = 262544; nedt->edtData.Nlau = 8277042; nedt->edtData.Alt_launch = 980; nedt->edtData.Etarg = 263769; nedt->edtData.Ntarg = 8246145; nedt->edtData.Altarg = 971; nedt->edtData.Azim_tiro = 3167; nedt->edtData.Elev_tiro = 569; nedt->edtData.Fusetime_input = 1E38; nedt->edtData.Vweth = 0; nedt->edtData.Vwnth = 0; nedt->edtData.Vweff = 0; nedt->edtData.Vwnff = 0; nedt->edtData.Elev_max = 60; nedt->edtData.CalType = 2;
//
//	//	nedt->edtData.Elau    = 273810.4;
//	//	nedt->edtData.Nlau    = 8284220.8;
//	//
//	//	nedt->edtData.Etarg   = 262750;
//
//
//	//	nedt->edtData.DDTType=7; nedt->edtData.Latitude=5; nedt->edtData.Sec_bal=0; nedt->edtData.Metcm_included=1; nedt->edtData.Natm=12; nedt->edtData.Vwmetcm[0]=2; nedt->edtData.Vwmetcm[1]=4; nedt->edtData.Vwmetcm[2]=8; nedt->edtData.Vwmetcm[3]=8; nedt->edtData.Vwmetcm[4]=11; nedt->edtData.Vwmetcm[5]=15; nedt->edtData.Vwmetcm[6]=14; nedt->edtData.Vwmetcm[7]=10; nedt->edtData.Vwmetcm[8]=3; nedt->edtData.Vwmetcm[9]=3; nedt->edtData.Vwmetcm[10]=13; nedt->edtData.Vwmetcm[11]=13; nedt->edtData.Vwmetcm[12]=16; nedt->edtData.Vwmetcm[13]=0; nedt->edtData.Vwmetcm[14]=0; nedt->edtData.Vwmetcm[15]=0; nedt->edtData.Vwmetcm[16]=0; nedt->edtData.Vwmetcm[17]=0; nedt->edtData.Vwmetcm[18]=0; nedt->edtData.Vwmetcm[19]=0; nedt->edtData.Vwmetcm[20]=0; nedt->edtData.Vwmetcm[21]=0; nedt->edtData.Vwmetcm[22]=0; nedt->edtData.Vwmetcm[23]=0; nedt->edtData.Vwmetcm[24]=0; nedt->edtData.Vwmetcm[25]=0; nedt->edtData.Vwmetcm[26]=0; nedt->edtData.Vwmetcm[27]=0; nedt->edtData.Vwmetcm[28]=0; nedt->edtData.Vwmetcm[29]=0; nedt->edtData.Vwmetcm[30]=0; nedt->edtData.Vwmetcm[31]=0; nedt->edtData.Vwmetcm[32]=0; nedt->edtData.Vwmetcm[33]=0; nedt->edtData.Vwmetcm[34]=0; nedt->edtData.Vwmetcm[35]=0; nedt->edtData.Vwmetcm[36]=0; nedt->edtData.Vwmetcm[37]=0; nedt->edtData.Vwmetcm[38]=0; nedt->edtData.Vwmetcm[39]=0; nedt->edtData.Vwmetcm[40]=0; nedt->edtData.Azwmetcm[0]=570; nedt->edtData.Azwmetcm[1]=340; nedt->edtData.Azwmetcm[2]=510; nedt->edtData.Azwmetcm[3]=870; nedt->edtData.Azwmetcm[4]=2220; nedt->edtData.Azwmetcm[5]=2190; nedt->edtData.Azwmetcm[6]=1880; nedt->edtData.Azwmetcm[7]=2160; nedt->edtData.Azwmetcm[8]=1910; nedt->edtData.Azwmetcm[9]=1910; nedt->edtData.Azwmetcm[10]=2800; nedt->edtData.Azwmetcm[11]=2110; nedt->edtData.Azwmetcm[12]=2220; nedt->edtData.Azwmetcm[13]=0; nedt->edtData.Azwmetcm[14]=0; nedt->edtData.Azwmetcm[15]=0; nedt->edtData.Azwmetcm[16]=0; nedt->edtData.Azwmetcm[17]=0; nedt->edtData.Azwmetcm[18]=0; nedt->edtData.Azwmetcm[19]=0; nedt->edtData.Azwmetcm[20]=0; nedt->edtData.Azwmetcm[21]=0; nedt->edtData.Azwmetcm[22]=0; nedt->edtData.Azwmetcm[23]=0; nedt->edtData.Azwmetcm[24]=0; nedt->edtData.Azwmetcm[25]=0; nedt->edtData.Azwmetcm[26]=0; nedt->edtData.Azwmetcm[27]=0; nedt->edtData.Azwmetcm[28]=0; nedt->edtData.Azwmetcm[29]=0; nedt->edtData.Azwmetcm[30]=0; nedt->edtData.Azwmetcm[31]=0; nedt->edtData.Azwmetcm[32]=0; nedt->edtData.Azwmetcm[33]=0; nedt->edtData.Azwmetcm[34]=0; nedt->edtData.Azwmetcm[35]=0; nedt->edtData.Azwmetcm[36]=0; nedt->edtData.Azwmetcm[37]=0; nedt->edtData.Azwmetcm[38]=0; nedt->edtData.Azwmetcm[39]=0; nedt->edtData.Azwmetcm[40]=0; nedt->edtData.Tent[0]=302.100006103516; nedt->edtData.Tent[1]=301.600006103516; nedt->edtData.Tent[2]=298.399993896484; nedt->edtData.Tent[3]=294.200012207031; nedt->edtData.Tent[4]=290.799987792969; nedt->edtData.Tent[5]=287.5; nedt->edtData.Tent[6]=283.700012207031; nedt->edtData.Tent[7]=279.399993896484; nedt->edtData.Tent[8]=276; nedt->edtData.Tent[9]=271.700012207031; nedt->edtData.Tent[10]=270.600006103516; nedt->edtData.Tent[11]=269; nedt->edtData.Tent[12]=266.200012207031; nedt->edtData.Tent[13]=0; nedt->edtData.Tent[14]=0; nedt->edtData.Tent[15]=0; nedt->edtData.Tent[16]=0; nedt->edtData.Tent[17]=0; nedt->edtData.Tent[18]=0; nedt->edtData.Tent[19]=0; nedt->edtData.Tent[20]=0; nedt->edtData.Tent[21]=0; nedt->edtData.Tent[22]=0; nedt->edtData.Tent[23]=0; nedt->edtData.Tent[24]=0; nedt->edtData.Tent[25]=0; nedt->edtData.Tent[26]=0; nedt->edtData.Tent[27]=0; nedt->edtData.Tent[28]=0; nedt->edtData.Tent[29]=0; nedt->edtData.Tent[30]=0; nedt->edtData.Tent[31]=0; nedt->edtData.Tent[32]=0; nedt->edtData.Tent[33]=0; nedt->edtData.Tent[34]=0; nedt->edtData.Tent[35]=0; nedt->edtData.Tent[36]=0; nedt->edtData.Tent[37]=0; nedt->edtData.Tent[38]=0; nedt->edtData.Tent[39]=0; nedt->edtData.Tent[40]=0; nedt->edtData.Pent[0]=906; nedt->edtData.Pent[1]=896; nedt->edtData.Pent[2]=871; nedt->edtData.Pent[3]=832; nedt->edtData.Pent[4]=784; nedt->edtData.Pent[5]=739; nedt->edtData.Pent[6]=697; nedt->edtData.Pent[7]=656; nedt->edtData.Pent[8]=616; nedt->edtData.Pent[9]=579; nedt->edtData.Pent[10]=544; nedt->edtData.Pent[11]=510; nedt->edtData.Pent[12]=464; nedt->edtData.Pent[13]=0; nedt->edtData.Pent[14]=0; nedt->edtData.Pent[15]=0; nedt->edtData.Pent[16]=0; nedt->edtData.Pent[17]=0; nedt->edtData.Pent[18]=0; nedt->edtData.Pent[19]=0; nedt->edtData.Pent[20]=0; nedt->edtData.Pent[21]=0; nedt->edtData.Pent[22]=0; nedt->edtData.Pent[23]=0; nedt->edtData.Pent[24]=0; nedt->edtData.Pent[25]=0; nedt->edtData.Pent[26]=0; nedt->edtData.Pent[27]=0; nedt->edtData.Pent[28]=0; nedt->edtData.Pent[29]=0; nedt->edtData.Pent[30]=0; nedt->edtData.Pent[31]=0; nedt->edtData.Pent[32]=0; nedt->edtData.Pent[33]=0; nedt->edtData.Pent[34]=0; nedt->edtData.Pent[35]=0; nedt->edtData.Pent[36]=0; nedt->edtData.Pent[37]=0; nedt->edtData.Pent[38]=0; nedt->edtData.Pent[39]=0; nedt->edtData.Pent[40]=0; nedt->edtData.Alt_met=976; nedt->edtData.Azwcor=0; nedt->edtData.T0=28.375; nedt->edtData.P0=907.8125; nedt->edtData.Proptemp=28.375; nedt->edtData.Vws=10.06375; nedt->edtData.Azws=323.533333333333; nedt->edtData.Altfg=959; nedt->edtData.RefDir=0; nedt->edtData.Elau=273810; nedt->edtData.Nlau=8284220; nedt->edtData.Alt_launch=965; nedt->edtData.Etarg=262750; nedt->edtData.Ntarg=8246145; nedt->edtData.Altarg=970; nedt->edtData.Azim_tiro=3476; nedt->edtData.Elev_tiro=1067; nedt->edtData.Fusetime_input=1E38; nedt->edtData.Vweth=0; nedt->edtData.Vwnth=0; nedt->edtData.Vweff=0; nedt->edtData.Vwnff=0; nedt->edtData.Elev_max=60; nedt->edtData.CalType=2;
//
//	nedt->edtData.Elev_tiro = 580;
//	nedt->edtData.Azim_tiro = 3168;
//	printf("empuxo: %.2f\n",nedt->DDTDLL.Emp);
//	printf("dragss[0]: %.8f\n",nedt->DDTDLL.Cwss[0]);
//
//	//	nedt->calcularTiro2();
//	nedt->voarCompleto();
//
//	//	imprimirDadosLancamento(nedt);
//	//	imprimirResultados(nedt);
//	imprimir p(nedt);
//	p.dadosLancamento();
//	p.resultados();
//	return 1;
//}
//
//int testeLancamentoEdtData3(novaEdt *nedt){
//	int fog = SS_80;
//	nedt->ConfigEdt(fog);
//
//	nedt->edtData.DDTType = 5; nedt->edtData.Latitude = 5; nedt->edtData.Sec_bal = 1 ; nedt->edtData.Metcm_included = 1 ; nedt->edtData.Natm = 29; nedt->edtData.Vwmetcm[0] = 4; nedt->edtData.Vwmetcm[1] = 7; nedt->edtData.Vwmetcm[2] = 8; nedt->edtData.Vwmetcm[3] = 11; nedt->edtData.Vwmetcm[4] = 15; nedt->edtData.Vwmetcm[5] = 17; nedt->edtData.Vwmetcm[6] = 19; nedt->edtData.Vwmetcm[7] = 27; nedt->edtData.Vwmetcm[8] = 23; nedt->edtData.Vwmetcm[9] = 20; nedt->edtData.Vwmetcm[10] = 29; nedt->edtData.Vwmetcm[11] = 30; nedt->edtData.Vwmetcm[12] = 27; nedt->edtData.Vwmetcm[13] = 30; nedt->edtData.Vwmetcm[14] = 34; nedt->edtData.Vwmetcm[15] = 28; nedt->edtData.Vwmetcm[16] = 25; nedt->edtData.Vwmetcm[17] = 13; nedt->edtData.Vwmetcm[18] = 13; nedt->edtData.Vwmetcm[19] = 11; nedt->edtData.Vwmetcm[20] = 11; nedt->edtData.Vwmetcm[21] = 8; nedt->edtData.Vwmetcm[22] = 3; nedt->edtData.Vwmetcm[23] = 5; nedt->edtData.Vwmetcm[24] = 12; nedt->edtData.Vwmetcm[25] = 13; nedt->edtData.Vwmetcm[26] = 3; nedt->edtData.Vwmetcm[27] = 5; nedt->edtData.Vwmetcm[28] = 5; nedt->edtData.Vwmetcm[29] = 9; nedt->edtData.Vwmetcm[30] = 0; nedt->edtData.Vwmetcm[31] = 0; nedt->edtData.Vwmetcm[32] = 0; nedt->edtData.Vwmetcm[33] = 0; nedt->edtData.Vwmetcm[34] = 0; nedt->edtData.Vwmetcm[35] = 0; nedt->edtData.Vwmetcm[36] = 0; nedt->edtData.Vwmetcm[37] = 0; nedt->edtData.Vwmetcm[38] = 0; nedt->edtData.Vwmetcm[39] = 0; nedt->edtData.Vwmetcm[40] = 0; nedt->edtData.Azwmetcm[0] = 1550; nedt->edtData.Azwmetcm[1] = 1590; nedt->edtData.Azwmetcm[2] = 1660; nedt->edtData.Azwmetcm[3] = 1080; nedt->edtData.Azwmetcm[4] = 1680; nedt->edtData.Azwmetcm[5] = 1610; nedt->edtData.Azwmetcm[6] = 1420; nedt->edtData.Azwmetcm[7] = 1460; nedt->edtData.Azwmetcm[8] = 1580; nedt->edtData.Azwmetcm[9] = 1720; nedt->edtData.Azwmetcm[10] = 1750; nedt->edtData.Azwmetcm[11] = 1830; nedt->edtData.Azwmetcm[12] = 2200; nedt->edtData.Azwmetcm[13] = 2010; nedt->edtData.Azwmetcm[14] = 2050; nedt->edtData.Azwmetcm[15] = 2170; nedt->edtData.Azwmetcm[16] = 2150; nedt->edtData.Azwmetcm[17] = 2620; nedt->edtData.Azwmetcm[18] = 2830; nedt->edtData.Azwmetcm[19] = 2040; nedt->edtData.Azwmetcm[20] = 1210; nedt->edtData.Azwmetcm[21] = 2300; nedt->edtData.Azwmetcm[22] = 2560; nedt->edtData.Azwmetcm[23] = 2770; nedt->edtData.Azwmetcm[24] = 1540; nedt->edtData.Azwmetcm[25] = 1150; nedt->edtData.Azwmetcm[26] = 1110; nedt->edtData.Azwmetcm[27] = 6070; nedt->edtData.Azwmetcm[28] = 3250; nedt->edtData.Azwmetcm[29] = 5740; nedt->edtData.Azwmetcm[30] = 0; nedt->edtData.Azwmetcm[31] = 0; nedt->edtData.Azwmetcm[32] = 0; nedt->edtData.Azwmetcm[33] = 0; nedt->edtData.Azwmetcm[34] = 0; nedt->edtData.Azwmetcm[35] = 0; nedt->edtData.Azwmetcm[36] = 0; nedt->edtData.Azwmetcm[37] = 0; nedt->edtData.Azwmetcm[38] = 0; nedt->edtData.Azwmetcm[39] = 0; nedt->edtData.Azwmetcm[40] = 0; nedt->edtData.Tent[0] = 306.200012207031; nedt->edtData.Tent[1] = 301.899993896484; nedt->edtData.Tent[2] = 299.299987792969; nedt->edtData.Tent[3] = 295.5; nedt->edtData.Tent[4] = 290.700012207031; nedt->edtData.Tent[5] = 287.100006103516; nedt->edtData.Tent[6] = 283.799987792969; nedt->edtData.Tent[7] = 279.600006103516; nedt->edtData.Tent[8] = 275.399993896484; nedt->edtData.Tent[9] = 271.600006103516; nedt->edtData.Tent[10] = 269.799987792969; nedt->edtData.Tent[11] = 266.600006103516; nedt->edtData.Tent[12] = 263.899993896484; nedt->edtData.Tent[13] = 261.700012207031; nedt->edtData.Tent[14] = 254; nedt->edtData.Tent[15] = 245.100006103516; nedt->edtData.Tent[16] = 237; nedt->edtData.Tent[17] = 228.300003051758; nedt->edtData.Tent[18] = 220.5; nedt->edtData.Tent[19] = 211.600006103516; nedt->edtData.Tent[20] = 204.399993896484; nedt->edtData.Tent[21] = 199.399993896484; nedt->edtData.Tent[22] = 197.699996948242; nedt->edtData.Tent[23] = 197.899993896484; nedt->edtData.Tent[24] = 198.600006103516; nedt->edtData.Tent[25] = 203.100006103516; nedt->edtData.Tent[26] = 208.5; nedt->edtData.Tent[27] = 214.899993896484; nedt->edtData.Tent[28] = 217.399993896484; nedt->edtData.Tent[29] = 223.800003051758; nedt->edtData.Tent[30] = 0; nedt->edtData.Tent[31] = 0; nedt->edtData.Tent[32] = 0; nedt->edtData.Tent[33] = 0; nedt->edtData.Tent[34] = 0; nedt->edtData.Tent[35] = 0; nedt->edtData.Tent[36] = 0; nedt->edtData.Tent[37] = 0; nedt->edtData.Tent[38] = 0; nedt->edtData.Tent[39] = 0; nedt->edtData.Tent[40] = 0; nedt->edtData.Pent[0] = 908; nedt->edtData.Pent[1] = 898; nedt->edtData.Pent[2] = 873; nedt->edtData.Pent[3] = 833; nedt->edtData.Pent[4] = 786; nedt->edtData.Pent[5] = 741; nedt->edtData.Pent[6] = 698; nedt->edtData.Pent[7] = 657; nedt->edtData.Pent[8] = 618; nedt->edtData.Pent[9] = 580; nedt->edtData.Pent[10] = 545; nedt->edtData.Pent[11] = 511; nedt->edtData.Pent[12] = 464; nedt->edtData.Pent[13] = 408; nedt->edtData.Pent[14] = 357; nedt->edtData.Pent[15] = 311; nedt->edtData.Pent[16] = 270; nedt->edtData.Pent[17] = 233; nedt->edtData.Pent[18] = 200; nedt->edtData.Pent[19] = 171; nedt->edtData.Pent[20] = 145; nedt->edtData.Pent[21] = 122; nedt->edtData.Pent[22] = 103; nedt->edtData.Pent[23] = 87; nedt->edtData.Pent[24] = 73; nedt->edtData.Pent[25] = 62; nedt->edtData.Pent[26] = 52; nedt->edtData.Pent[27] = 41; nedt->edtData.Pent[28] = 30; nedt->edtData.Pent[29] = 22; nedt->edtData.Pent[30] = 0; nedt->edtData.Pent[31] = 0; nedt->edtData.Pent[32] = 0; nedt->edtData.Pent[33] = 0; nedt->edtData.Pent[34] = 0; nedt->edtData.Pent[35] = 0; nedt->edtData.Pent[36] = 0; nedt->edtData.Pent[37] = 0; nedt->edtData.Pent[38] = 0; nedt->edtData.Pent[39] = 0; nedt->edtData.Pent[40] = 0; nedt->edtData.Alt_met = 959; nedt->edtData.Azwcor = 0; nedt->edtData.T0 = 33.3125; nedt->edtData.P0 = 903.75; nedt->edtData.Proptemp = 33.3125; nedt->edtData.Vws = 6.66875; nedt->edtData.Azws = 1720.2; nedt->edtData.Altfg = 959; nedt->edtData.RefDir = 0; nedt->edtData.Elau = 273825; nedt->edtData.Nlau = 8284210; nedt->edtData.Alt_launch = 965; nedt->edtData.Etarg = 262750; nedt->edtData.Ntarg = 8246145; nedt->edtData.Altarg = 970; nedt->edtData.Azim_tiro = 3555; nedt->edtData.Elev_tiro = 575; nedt->edtData.Fusetime_input = 68.0978973617567; nedt->edtData.Vweth = 0; nedt->edtData.Vwnth = 0; nedt->edtData.Vweff = 0; nedt->edtData.Vwnff = 0; nedt->edtData.Elev_max = 61.8; nedt->edtData.CalType = 3;
//
//	nedt->calcularTiro2();
//	//	nedt->edtData.Elev_tiro = 564;
//	//	nedt->edtData.Azim_tiro = 3488;
//
//	nedt->voarCompleto();
//
//	//	imprimirDadosLancamento(nedt);
//	//	imprimirResultados(nedt);
//	imprimir p(nedt);
//	p.dadosLancamento();
//	p.resultados();
//	return 1;
//}
//
//
//int testeErroElevationTooHigh(novaEdt *nedt){
//	//	printf("TESTANDO ERROS DE ELEVATION TOO HIGH");
//	int fog = SS_60;
//	nedt->ConfigEdt(fog);
//
//	imprimir p(nedt);
//	//	p.fog(fog);
//	//	printf("p.txt: %s\n",p.txt);
//
//	//	nedt->log(p.txt);
//
//	// condicoes de ambiente padrao
//	nedt->edtData.T0         = -273.18 + 281.65; //268.65-273.15;//275.15-273.15;//281.65-273.15;
//	nedt->edtData.Proptemp   = nedt->edtData.T0;
//	nedt->edtData.P0         = 898.74; //701.0854;//898.74;//1013.25;
//	nedt->edtData.Latitude   = -45;
//	nedt->edtData.Sec_bal    = (int)1;
//
//	// posicao lancadora
//	nedt->edtData.Elau = 0;
//	nedt->edtData.Nlau = 0;
//	nedt->edtData.Alt_launch = 0;
//
//	// posicao alvo
//	nedt->edtData.Etarg = 0;
//	nedt->edtData.Ntarg = 10000;
//	nedt->edtData.Altarg = 0;
//
//	// calcula range
//	nedt->log("nedt->calcularAlcanceMinimo");
//	nedt->calcularAlcanceMinimo();
//	nedt->log("nedt->calcularAlcanceMaximo");
//	nedt->calcularAlcanceMaximo();
//
//	// resultados
//	p.range();
//	nedt->log(p.txt);
//	nedt->voarCompleto();
//
//	return 1;
//}
//
//int testeCalculoObservador(novaEdt *nedt){
//	double lancamento[21]; // dados de lancamento
//	double tabelaVento[41][5]; // tabela de vento
//	double *ponteiroTabelaVento = tabelaVento[0];
//	int CntTrkData;
//
//	imprimir p(nedt);
//
//	for (int var = 0; var <= 4500; ++var)
//		rastreio.RelativeTime[var] = -1;
//
//	// LENDO ARQUIVOS TXT
//	int fog;
//	int ret;
//	ret = lerAquivosTXT(&rastreio,&fog,lancamento,ponteiroTabelaVento,&CntTrkData);
//
//	fog = SS_40;
//	nedt->ConfigEdt(fog);
//
//	if (!ret){
//		printf("\nErro ao ler arquivos de dados");
//		return 0;
//	}
//
//	// USANDO OS DADOS LIDOS PARA CONFIGURAR O OBJETO
//	configuraNEDT(nedt, &rastreio, lancamento, ponteiroTabelaVento);
//
//	nedt->SetTrackingData(&rastreio);
//	nedt->SetCntTrkData(CntTrkData);
//
//	// --------------------------------------------
//	// AQUI COMECA A NOVA EDT
//	// SIMULACAO DE VOO
//
//	// TRATANDO VALORES DE RASTREIO
//	double C0_fq[7], C0_extrap[7];
//	int erro[5];
//	nedt->tratarDadosRadar(nedt->tempoQueima*2,C0_fq,C0_extrap,erro);
//
//	// criando variavel de condicaoInicial
//	condicaoInicial inicio;
//	inicio.extrapolar = TRUE; // <-------- DERSO, CONFERE ISSO LAH
//	inicio.tempo = C0_extrap[0]; inicio.pos[0] = C0_extrap[1]; inicio.pos[1] = C0_extrap[2]; inicio.pos[2] = C0_extrap[3]; inicio.vel[0] = C0_extrap[4]; inicio.vel[1] = C0_extrap[5]; inicio.vel[2] = C0_extrap[6];
//
//	// extrapolando ponto de impacto a partir da condicaoInicial
//	nedt->voarExtrapolando(&inicio);
//
//	// calculando ponto de impacto em coordenadas EN
//
//	double Norte_Pilotos[100], Leste_Pilotos[100], Altitude_Pilotos[100];
//	int Pontos_Validos[100], tam;
//	double Media_Pto_Imp[3];
//
//	// salvando valores de media nas posicoes
//	nedt->posicaoFimDeQueima[0] = C0_fq[1]; nedt->posicaoFimDeQueima[1] = C0_fq[2]; nedt->posicaoFimDeQueima[2] = C0_fq[3]; nedt->velocidadeFimDeQueima[0] = C0_fq[4]; nedt->velocidadeFimDeQueima[1] = C0_fq[5]; nedt->velocidadeFimDeQueima[2] = C0_fq[6];
//	nedt->posicaoFimDeVoo[0] = nedt->posicaoImpacto[0]; nedt->posicaoFimDeVoo[1] = nedt->posicaoImpacto[1]; nedt->posicaoFimDeVoo[2] = nedt->posicaoImpacto[2];
//
//	// ---------------------------------------------------------------------------
//	// INICIO CALCULOS DE VENTO
//	nedt->log("resultadoOriginal");
//	p.resultados();
//	nedt->log(p.txt);
//
//	// zerando valores de vento
//	nedt->Vweth = 0; nedt->Vwnth = 0; nedt->Vweff = 0; nedt->Vwnff = 0;
//	nedt->edtData.Vweth = 0; nedt->edtData.Vwnth = 0; nedt->edtData.Vweff = 0; nedt->edtData.Vwnff = 0;
//
//	double desvioAlcance, desvioLateral, alvoVerdadeiro[2];
//	desvioAlcance = nedt->calcularDesvioAlcance();
//	desvioLateral = nedt->calcularDesvioLateral();
//
//	// calculando ventos
//	// calculos de ventos fase propulsada
//	nedt->log("USANDO VENTOS ESTIMADOS");
//	nedt->log("nedt->calcularVentoTH");
//	nedt->calcularVentoTH();
//
//	// calculos de ventos fase balistica
//	nedt->log("nedt->calcularVentoFF");
//	nedt->calcularVentoFF();
//
//	// calculo elementos para ventos estimados
//	nedt->calcularTiro2_semRange();
//	p.resultados();
//	nedt->log(p.txt);
//
//	nedt->log("USANDO VENTOS ESTIMADOS COM ELEMENTOS DO PONTO OBERVADO");
//	nedt->edtData.Elev_tiro = 705;
//	nedt->edtData.Azim_tiro = 3183;
//	nedt->edtData.Fusetime_input = 74.91;
//	nedt->voarCompleto();
//	p.resultados();
//	nedt->log(p.txt);
//
//	// calculando por pontoObservado
//	nedt->log("calculoTiroPontoObservado");
//	nedt->Vweth = 0; nedt->Vwnth = 0; nedt->Vweff = 0; nedt->Vwnff = 0;
//	nedt->edtData.Vweth = 0; nedt->edtData.Vwnth = 0; nedt->edtData.Vweff = 0; nedt->edtData.Vwnff = 0;
//
//	// atualizando posicao alvo para calculo
//	nedt->pontoObservado[0] = nedt->posicaoFimDeVoo[0];
//	nedt->pontoObservado[1] = nedt->posicaoFimDeVoo[1];
//	nedt->calcularTiroObservador();
//
//	nedt->log("resultados com o alvo deslocado");
//	p.resultados();
//	nedt->log(p.txt);
//
//	return 1;
//}
//int tiroEdtData(novaEdt *nedt) {
//	int fog = SS_09TS;
//	nedt->ConfigEdt(fog);
//
//	printf("passei aqui!\n");
//	imprimir p(nedt);
//	//	nedt->edtData.DDTType=5; nedt->edtData.Latitude=5.00; nedt->edtData.Sec_bal=0; nedt->edtData.Metcm_included=1; nedt->edtData.Natm=26; nedt->edtData.Vwmetcm[0]=7.00; nedt->edtData.Azwmetcm[0]=920.00; nedt->edtData.Tent[0]=303.20; nedt->edtData.Pent[0]=909.00; nedt->edtData.Vwmetcm[1]=11.00; nedt->edtData.Azwmetcm[1]=910.00; nedt->edtData.Tent[1]=299.40; nedt->edtData.Pent[1]=898.00; nedt->edtData.Vwmetcm[2]=13.00; nedt->edtData.Azwmetcm[2]=880.00; nedt->edtData.Tent[2]=296.30; nedt->edtData.Pent[2]=873.00; nedt->edtData.Vwmetcm[3]=12.00; nedt->edtData.Azwmetcm[3]=950.00; nedt->edtData.Tent[3]=293.20; nedt->edtData.Pent[3]=833.00; nedt->edtData.Vwmetcm[4]=10.00; nedt->edtData.Azwmetcm[4]=2030.00; nedt->edtData.Tent[4]=290.30; nedt->edtData.Pent[4]=786.00; nedt->edtData.Vwmetcm[5]=9.00; nedt->edtData.Azwmetcm[5]=2200.00; nedt->edtData.Tent[5]=285.60; nedt->edtData.Pent[5]=741.00; nedt->edtData.Vwmetcm[6]=19.00; nedt->edtData.Azwmetcm[6]=1810.00; nedt->edtData.Tent[6]=282.70; nedt->edtData.Pent[6]=697.00; nedt->edtData.Vwmetcm[7]=27.00; nedt->edtData.Azwmetcm[7]=1490.00; nedt->edtData.Tent[7]=279.60; nedt->edtData.Pent[7]=656.00; nedt->edtData.Vwmetcm[8]=28.00; nedt->edtData.Azwmetcm[8]=1500.00; nedt->edtData.Tent[8]=275.40; nedt->edtData.Pent[8]=617.00; nedt->edtData.Vwmetcm[9]=27.00; nedt->edtData.Azwmetcm[9]=1530.00; nedt->edtData.Tent[9]=271.20; nedt->edtData.Pent[9]=580.00; nedt->edtData.Vwmetcm[10]=24.00; nedt->edtData.Azwmetcm[10]=1830.00; nedt->edtData.Tent[10]=269.90; nedt->edtData.Pent[10]=544.00; nedt->edtData.Vwmetcm[11]=29.00; nedt->edtData.Azwmetcm[11]=2110.00; nedt->edtData.Tent[11]=268.30; nedt->edtData.Pent[11]=511.00; nedt->edtData.Vwmetcm[12]=27.00; nedt->edtData.Azwmetcm[12]=2280.00; nedt->edtData.Tent[12]=263.60; nedt->edtData.Pent[12]=464.00; nedt->edtData.Vwmetcm[13]=31.00; nedt->edtData.Azwmetcm[13]=2190.00; nedt->edtData.Tent[13]=260.90; nedt->edtData.Pent[13]=407.00; nedt->edtData.Vwmetcm[14]=31.00; nedt->edtData.Azwmetcm[14]=2320.00; nedt->edtData.Tent[14]=254.40; nedt->edtData.Pent[14]=356.00; nedt->edtData.Vwmetcm[15]=26.00; nedt->edtData.Azwmetcm[15]=2450.00; nedt->edtData.Tent[15]=245.70; nedt->edtData.Pent[15]=311.00; nedt->edtData.Vwmetcm[16]=24.00; nedt->edtData.Azwmetcm[16]=2370.00; nedt->edtData.Tent[16]=237.40; nedt->edtData.Pent[16]=270.00; nedt->edtData.Vwmetcm[17]=11.00; nedt->edtData.Azwmetcm[17]=3000.00; nedt->edtData.Tent[17]=228.80; nedt->edtData.Pent[17]=233.00; nedt->edtData.Vwmetcm[18]=10.00; nedt->edtData.Azwmetcm[18]=2640.00; nedt->edtData.Tent[18]=221.40; nedt->edtData.Pent[18]=200.00; nedt->edtData.Vwmetcm[19]=13.00; nedt->edtData.Azwmetcm[19]=2060.00; nedt->edtData.Tent[19]=212.40; nedt->edtData.Pent[19]=171.00; nedt->edtData.Vwmetcm[20]=10.00; nedt->edtData.Azwmetcm[20]=1500.00; nedt->edtData.Tent[20]=204.60; nedt->edtData.Pent[20]=145.00; nedt->edtData.Vwmetcm[21]=6.00; nedt->edtData.Azwmetcm[21]=1510.00; nedt->edtData.Tent[21]=199.20; nedt->edtData.Pent[21]=123.00; nedt->edtData.Vwmetcm[22]=1.00; nedt->edtData.Azwmetcm[22]=5010.00; nedt->edtData.Tent[22]=197.60; nedt->edtData.Pent[22]=103.00; nedt->edtData.Vwmetcm[23]=5.00; nedt->edtData.Azwmetcm[23]=3070.00; nedt->edtData.Tent[23]=198.70; nedt->edtData.Pent[23]=87.00; nedt->edtData.Vwmetcm[24]=10.00; nedt->edtData.Azwmetcm[24]=2190.00; nedt->edtData.Tent[24]=197.70; nedt->edtData.Pent[24]=73.00; nedt->edtData.Vwmetcm[25]=17.00; nedt->edtData.Azwmetcm[25]=1230.00; nedt->edtData.Tent[25]=202.70; nedt->edtData.Pent[25]=62.00; nedt->edtData.Vwmetcm[26]=12.00; nedt->edtData.Azwmetcm[26]=1270.00; nedt->edtData.Tent[26]=206.90; nedt->edtData.Pent[26]=52.00; nedt->edtData.Vwmetcm[27]=0.00; nedt->edtData.Azwmetcm[27]=0.00; nedt->edtData.Tent[27]=0.00; nedt->edtData.Pent[27]=0.00; nedt->edtData.Vwmetcm[28]=0.00; nedt->edtData.Azwmetcm[28]=0.00; nedt->edtData.Tent[28]=0.00; nedt->edtData.Pent[28]=0.00; nedt->edtData.Vwmetcm[29]=0.00; nedt->edtData.Azwmetcm[29]=0.00; nedt->edtData.Tent[29]=0.00; nedt->edtData.Pent[29]=0.00; nedt->edtData.Vwmetcm[30]=0.00; nedt->edtData.Azwmetcm[30]=0.00; nedt->edtData.Tent[30]=0.00; nedt->edtData.Pent[30]=0.00; nedt->edtData.Vwmetcm[31]=0.00; nedt->edtData.Azwmetcm[31]=0.00; nedt->edtData.Tent[31]=0.00; nedt->edtData.Pent[31]=0.00; nedt->edtData.Vwmetcm[32]=0.00; nedt->edtData.Azwmetcm[32]=0.00; nedt->edtData.Tent[32]=0.00; nedt->edtData.Pent[32]=0.00; nedt->edtData.Vwmetcm[33]=0.00; nedt->edtData.Azwmetcm[33]=0.00; nedt->edtData.Tent[33]=0.00; nedt->edtData.Pent[33]=0.00; nedt->edtData.Vwmetcm[34]=0.00; nedt->edtData.Azwmetcm[34]=0.00; nedt->edtData.Tent[34]=0.00; nedt->edtData.Pent[34]=0.00; nedt->edtData.Vwmetcm[35]=0.00; nedt->edtData.Azwmetcm[35]=0.00; nedt->edtData.Tent[35]=0.00; nedt->edtData.Pent[35]=0.00; nedt->edtData.Vwmetcm[36]=0.00; nedt->edtData.Azwmetcm[36]=0.00; nedt->edtData.Tent[36]=0.00; nedt->edtData.Pent[36]=0.00; nedt->edtData.Vwmetcm[37]=0.00; nedt->edtData.Azwmetcm[37]=0.00; nedt->edtData.Tent[37]=0.00; nedt->edtData.Pent[37]=0.00; nedt->edtData.Vwmetcm[38]=0.00; nedt->edtData.Azwmetcm[38]=0.00; nedt->edtData.Tent[38]=0.00; nedt->edtData.Pent[38]=0.00; nedt->edtData.Vwmetcm[39]=0.00; nedt->edtData.Azwmetcm[39]=0.00; nedt->edtData.Tent[39]=0.00; nedt->edtData.Pent[39]=0.00; nedt->edtData.Vwmetcm[40]=0.00; nedt->edtData.Azwmetcm[40]=0.00; nedt->edtData.Tent[40]=0.00; nedt->edtData.Pent[40]=0.00; nedt->edtData.Alt_met=959.00; nedt->edtData.Azwcor=0.00; nedt->edtData.T0=30.44; nedt->edtData.P0=906.00; nedt->edtData.Proptemp=30.44; nedt->edtData.Vws=7.00; nedt->edtData.Azws=800.00; nedt->edtData.Altfg=959.00; nedt->edtData.RefDir=0.00; nedt->edtData.Elau=273810.00; nedt->edtData.Nlau=8284220.00; nedt->edtData.Alt_launch=965.00; nedt->edtData.Etarg=262750.00; nedt->edtData.Ntarg=8246145.00; nedt->edtData.Altarg=970.00; nedt->edtData.Azim_tiro=3493.00; nedt->edtData.Elev_tiro=1067.00; nedt->edtData.Fusetime_input=99999999999999997750000000000000000000.00; nedt->edtData.Vweth=0.00; nedt->edtData.Vwnth=0.00; nedt->edtData.Vweff=0.00; nedt->edtData.Vwnff=0.00; nedt->edtData.Elev_max=60.00; nedt->edtData.CalType=2;
//	struct TShot shot;
//	shot = nedt->calcularTiro2_semRange();
//
//	//	nedt->edtData.Elev_tiro = 1067;
//	//	nedt->edtData.Azim_tiro = 3493;
//	//	nedt->voarCompleto();
//
//	p.erro(shot);
//	p.fog(fog);
//
//	//	p.dadosLancamento();
//	p.resultados();
//	p.range();
//
//	return 1;
//}
//
//int testeTiroNominal(novaEdt *nedt){
//	//	nedt->log("----------------");
//	//	nedt->log("testeTiroNominal");
//
//	int fog = SS_80;
//	nedt->ConfigEdt(fog);
//
//	char* txt = (char*)malloc(800*sizeof(char));
//
//	// condicoes de ambiente padrao
//	double alt;
//
//	alt = 960;
//	nedt->edtData.T0         = 32.0;
//	nedt->edtData.P0         = 910.0;
//
//	// incluindo metcm
//	nedt->edtData.Metcm_included = 1;
//
//	//	 numero de elementos da met
//	nedt->edtData.Natm           = 17;
//
//	// vento de superficie
//	nedt->edtData.Vws            = 5.0;
//	nedt->edtData.Azws           = 400;
//
//	nedt->edtData.Proptemp   = nedt->edtData.T0;
//	nedt->edtData.Latitude   = -15.5094;
//	nedt->edtData.Sec_bal    = (int)0;
//
//	nedt->edtData.Alt_met    = 915;
//	nedt->edtData.Altfg      = 954;
//	nedt->edtData.Alt_launch = 960;
//	nedt->edtData.Altarg     = 971;//alt;//alt;//3000;//1500;//600;//alt;
//
//	// posicao lancadora
//	nedt->edtData.Elau = 273820;
//	nedt->edtData.Nlau = 8284208;
//
//	// posicao alvo
//	nedt->edtData.Etarg  = 263769;
//	nedt->edtData.Ntarg  = 8246145;
//	////
//		nedt->edtData.Altarg = 971;
//
//	imprimir p(nedt);
//	p.fog(fog);
//	nedt->log(p.txt);
//
//	struct TShot shot;
//
//	// TABELA VENTO
//	// velocidade
//	nedt->edtData.Vwmetcm[0]=2; nedt->edtData.Vwmetcm[1]=5; nedt->edtData.Vwmetcm[2]=9; nedt->edtData.Vwmetcm[3]=14; nedt->edtData.Vwmetcm[4]=10; nedt->edtData.Vwmetcm[5]=7; nedt->edtData.Vwmetcm[6]=8; nedt->edtData.Vwmetcm[7]=13; nedt->edtData.Vwmetcm[8]=16; nedt->edtData.Vwmetcm[9]=17; nedt->edtData.Vwmetcm[10]=20; nedt->edtData.Vwmetcm[11]=23; nedt->edtData.Vwmetcm[12]=31; nedt->edtData.Vwmetcm[13]=37; nedt->edtData.Vwmetcm[14]=40; nedt->edtData.Vwmetcm[15]=44; nedt->edtData.Vwmetcm[16]=58;
//	// azimute vento
//	nedt->edtData.Azwmetcm[0]=5660; nedt->edtData.Azwmetcm[1]=5500; nedt->edtData.Azwmetcm[2]=6140; nedt->edtData.Azwmetcm[3]=50; nedt->edtData.Azwmetcm[4]=6180; nedt->edtData.Azwmetcm[5]=5640; nedt->edtData.Azwmetcm[6]=4910; nedt->edtData.Azwmetcm[7]=3880; nedt->edtData.Azwmetcm[8]=4130; nedt->edtData.Azwmetcm[9]=4740; nedt->edtData.Azwmetcm[10]=4900; nedt->edtData.Azwmetcm[11]=4670; nedt->edtData.Azwmetcm[12]=4340; nedt->edtData.Azwmetcm[13]=4480; nedt->edtData.Azwmetcm[14]=4590; nedt->edtData.Azwmetcm[15]=4760; nedt->edtData.Azwmetcm[16]=5010;
//	// temperatura
//	nedt->edtData.Tent[0]=302.6; nedt->edtData.Tent[1]=299.9; nedt->edtData.Tent[2]=297.9; nedt->edtData.Tent[3]=294.7; nedt->edtData.Tent[4]=290.3; nedt->edtData.Tent[5]=285.5; nedt->edtData.Tent[6]=280.9; nedt->edtData.Tent[7]=278.0; nedt->edtData.Tent[8]=275.6; nedt->edtData.Tent[9]=273.7; nedt->edtData.Tent[10]=271.1; nedt->edtData.Tent[11]=268.1; nedt->edtData.Tent[12]=263.3; nedt->edtData.Tent[13]=256.2; nedt->edtData.Tent[14]=250.3; nedt->edtData.Tent[15]=244.1; nedt->edtData.Tent[16]=239.5;
//	// pressao
//	nedt->edtData.Pent[0]=906; nedt->edtData.Pent[1]=896; nedt->edtData.Pent[2]=871; nedt->edtData.Pent[3]=831; nedt->edtData.Pent[4]=784; nedt->edtData.Pent[5]=739; nedt->edtData.Pent[6]=696; nedt->edtData.Pent[7]=654; nedt->edtData.Pent[8]=615; nedt->edtData.Pent[9]=578; nedt->edtData.Pent[10]=543; nedt->edtData.Pent[11]=510; nedt->edtData.Pent[12]=463; nedt->edtData.Pent[13]=406; nedt->edtData.Pent[14]=354; nedt->edtData.Pent[15]=309; nedt->edtData.Pent[16]=268;
//
//	shot = nedt->calcularTiro2_semRange();
//
//	p.range();
//	p.erro(shot);
//	p.resultados();
//
//	double a[3];
//	a[0] = nedt->edtData.Elau;
//	a[1] = nedt->edtData.Nlau;
//	a[2] = nedt->edtData.Alt_launch;
//
//	double b[3];
//	b[0] = nedt->edtData.Etarg;
//	b[1] = nedt->edtData.Ntarg;
//	b[2] = nedt->edtData.Altarg;
//
//	double aa;
//
//	aa = bradock::contaDoZe(a,b);
//
////	p.dadosLancamento();
//	printf("linha de tiro: %f\n",aa*180/3.141562/0.05625);
//	return 1;
//	//	shot = nedt->calcularTiro2();
//	//	shot = nedt->calcularAlcanceMaximo_();
//	//	shot = nedt->calcularAlcanceMinimo();
//
//	nedt->edtData.Elev_tiro = 564;
//	nedt->edtData.Azim_tiro = 3507;
//	nedt->edtData.Fusetime_input = 55.62;
//
//	condicaoInicial inicio;
//
//	inicio.extrapolar = 1;
//	inicio.tempo  = 12.02;
//	inicio.pos[0] = 0.24;
//	inicio.pos[1] = 7943.80;
//	inicio.pos[2] = 3192.90;
//	inicio.vel[0] = 0.21;
//	inicio.vel[1] = 706.56;
//	inicio.vel[2] = 239.22;
//
//	//	shot = nedt->voarExtrapolando(&inicio);
//	shot = nedt->voarCompleto();
//	p.erro(shot);
//	p.resultados();
//	return 1;
//
//	sprintf(txt,"secbal: %d",nedt->edtData.Sec_bal);
//	nedt->log(txt);
//	p.erro(shot);
//	nedt->log(p.txt);
//	p.resultados();
//	nedt->log(p.txt);
//	p.range();
//	nedt->log(p.txt);
//	return 1;
//}
//
//int testeTiroComVento(novaEdt *nedt){
//
//	int fog = SS_40_G;
//	nedt->ConfigEdt(fog);
//
//	char* txt = (char*)malloc(800*sizeof(char));
//
//	// condicoes de ambiente padrao
//	double alt;
//
//	/* CONDICOES DE LANCAMENTO */
//
//
//	alt = 45;
//	nedt->edtData.T0         = 15;
//	nedt->edtData.P0         = 1013;
//
//	nedt->edtData.Proptemp   = nedt->edtData.T0;
//	nedt->edtData.Latitude   = 0;
//	nedt->edtData.Sec_bal    = (int)0;
//
//	nedt->edtData.Alt_met    = alt; // altitude metcm
//	nedt->edtData.Altfg      = alt; // altitude fieldguard
//	nedt->edtData.Alt_launch = alt; // altitude lancadora
//	nedt->edtData.Altarg     = 0;//alt; // altitude alvo
//
//	// posicao lancadora
//	nedt->edtData.Elau = 260864;
//	nedt->edtData.Nlau = 9344748;
//
//	// posicao alvo
//	nedt->edtData.Etarg  = 288384;
//	nedt->edtData.Ntarg  = 9340357;
//
//	/* VENTOS METCM */
//
//	//	// incluindo metcm
//	nedt->edtData.Metcm_included = 1;
//	//
//	////	 numero de elementos da met
//	nedt->edtData.Natm           = 32;
//	//
//	////	 velocidade vento
//	//
//	nedt->edtData.Vwmetcm[0]=3.30000000000000; nedt->edtData.Vwmetcm[1]=8.07870504304126; nedt->edtData.Vwmetcm[2]=9.38383716782864; nedt->edtData.Vwmetcm[3]=9.83152217633165; nedt->edtData.Vwmetcm[4]=7.09292552538153; nedt->edtData.Vwmetcm[5]=6.30344076146812; nedt->edtData.Vwmetcm[6]=9.44535695256723; nedt->edtData.Vwmetcm[7]=10.7772205427270; nedt->edtData.Vwmetcm[8]=8.68499533252474; nedt->edtData.Vwmetcm[9]=6.69231794237404; nedt->edtData.Vwmetcm[10]=2.04416144917911; nedt->edtData.Vwmetcm[11]=0.197948736109506; nedt->edtData.Vwmetcm[12]=2.38441042875469; nedt->edtData.Vwmetcm[13]=3.97072125368766; nedt->edtData.Vwmetcm[14]=4.03093971139466; nedt->edtData.Vwmetcm[15]=3.73010714163368; nedt->edtData.Vwmetcm[16]=7.66902604057061; nedt->edtData.Vwmetcm[17]=11.6733903282839; nedt->edtData.Vwmetcm[18]=10.2117110812938; nedt->edtData.Vwmetcm[19]=11.9586866863407; nedt->edtData.Vwmetcm[20]=10.6847085688432; nedt->edtData.Vwmetcm[21]=9.78930511168659; nedt->edtData.Vwmetcm[22]=9.77804593371047; nedt->edtData.Vwmetcm[23]=6.95790457727154; nedt->edtData.Vwmetcm[24]=6.61604307150338; nedt->edtData.Vwmetcm[25]=1.82485698431496; nedt->edtData.Vwmetcm[26]=3.30726461423679; nedt->edtData.Vwmetcm[27]=11.0039545108379; nedt->edtData.Vwmetcm[28]=25.4464231945117; nedt->edtData.Vwmetcm[29]=19.9807396452154; nedt->edtData.Vwmetcm[30]=10.5115550042269; nedt->edtData.Vwmetcm[31]=4.72747684097716;
//	//
//	//
//	//	// azimute vento
//	nedt->edtData.Azwmetcm[0]=2471.11111111111; nedt->edtData.Azwmetcm[1]=2469.15867250120; nedt->edtData.Azwmetcm[2]=2253.23203160074; nedt->edtData.Azwmetcm[3]=2385.78934824759; nedt->edtData.Azwmetcm[4]=2458.06169036862; nedt->edtData.Azwmetcm[5]=1816.03747868833; nedt->edtData.Azwmetcm[6]=1504.70124390344; nedt->edtData.Azwmetcm[7]=1317.56094742466; nedt->edtData.Azwmetcm[8]=1112.67353038016; nedt->edtData.Azwmetcm[9]=878.113647143593; nedt->edtData.Azwmetcm[10]=224.641491001025; nedt->edtData.Azwmetcm[11]=1668.56363720786; nedt->edtData.Azwmetcm[12]=171.520598067881; nedt->edtData.Azwmetcm[13]=2717.98407010951; nedt->edtData.Azwmetcm[14]=4477.98103500521; nedt->edtData.Azwmetcm[15]=4267.46296003855; nedt->edtData.Azwmetcm[16]=3330.96171168505; nedt->edtData.Azwmetcm[17]=3328.55335523015; nedt->edtData.Azwmetcm[18]=3586.04092595436; nedt->edtData.Azwmetcm[19]=3622.77350393908; nedt->edtData.Azwmetcm[20]=3845.07285098265; nedt->edtData.Azwmetcm[21]=4146.31721744587; nedt->edtData.Azwmetcm[22]=4342.61908949165; nedt->edtData.Azwmetcm[23]=4121.20035534310; nedt->edtData.Azwmetcm[24]=4722.17398709151; nedt->edtData.Azwmetcm[25]=5894.74918285087; nedt->edtData.Azwmetcm[26]=6190.00110616281; nedt->edtData.Azwmetcm[27]=1991.13370428457; nedt->edtData.Azwmetcm[28]=1669.19245364114; nedt->edtData.Azwmetcm[29]=1340.21924854643; nedt->edtData.Azwmetcm[30]=897.241760190903; nedt->edtData.Azwmetcm[31]=147.253436752178;
//	//
//	//	// temperatura
//	nedt->edtData.Tent[0]=288.150000000000; nedt->edtData.Tent[1]=286.850000000000; nedt->edtData.Tent[2]=284.900000000000; nedt->edtData.Tent[3]=281.650000000000; nedt->edtData.Tent[4]=278.400000000000; nedt->edtData.Tent[5]=275.150000000000; nedt->edtData.Tent[6]=271.900000000000; nedt->edtData.Tent[7]=268.650000000000; nedt->edtData.Tent[8]=265.400000000000; nedt->edtData.Tent[9]=262.150000000000; nedt->edtData.Tent[10]=258.900000000000; nedt->edtData.Tent[11]=255.650000000000; nedt->edtData.Tent[12]=249.150000000000; nedt->edtData.Tent[13]=242.650000000000; nedt->edtData.Tent[14]=236.150000000000; nedt->edtData.Tent[15]=229.650000000000; nedt->edtData.Tent[16]=223.150000000000; nedt->edtData.Tent[17]=216.650000000000; nedt->edtData.Tent[18]=216.650000000000; nedt->edtData.Tent[19]=216.650000000000; nedt->edtData.Tent[20]=216.650000000000; nedt->edtData.Tent[21]=216.650000000000; nedt->edtData.Tent[22]=216.650000000000; nedt->edtData.Tent[23]=216.650000000000; nedt->edtData.Tent[24]=216.650000000000; nedt->edtData.Tent[25]=216.650000000000; nedt->edtData.Tent[26]=216.650000000000; nedt->edtData.Tent[27]=216.650000000000; nedt->edtData.Tent[28]=216.650000000000; nedt->edtData.Tent[29]=216.650000000000; nedt->edtData.Tent[30]=216.650000000000; nedt->edtData.Tent[31]=216.650000000000;
//
//	//	// pressao
//	nedt->edtData.Pent[0]=1013.25000000000; nedt->edtData.Pent[1]=989.453258707980; nedt->edtData.Pent[2]=954.608398964989; nedt->edtData.Pent[3]=898.745715517214; nedt->edtData.Pent[4]=845.560063310531; nedt->edtData.Pent[5]=794.952173888263; nedt->edtData.Pent[6]=746.825358802046; nedt->edtData.Pent[7]=701.085471843675; nedt->edtData.Pent[8]=657.640871390932; nedt->edtData.Pent[9]=616.402382868402; nedt->edtData.Pent[10]=577.283261324326; nedt->edtData.Pent[11]=540.199154124531; nedt->edtData.Pent[12]=471.810310800850; nedt->edtData.Pent[13]=410.607468025938; nedt->edtData.Pent[14]=355.998150487498; nedt->edtData.Pent[15]=307.424619907145; nedt->edtData.Pent[16]=264.362710526770; nedt->edtData.Pent[17]=226.320672770139; nedt->edtData.Pent[18]=193.304081669978; nedt->edtData.Pent[19]=165.104086749621; nedt->edtData.Pent[20]=141.018023137067; nedt->edtData.Pent[21]=120.445733603453; nedt->edtData.Pent[22]=102.874614326236; nedt->edtData.Pent[23]=87.8668422379756; nedt->edtData.Pent[24]=75.0484657020416; nedt->edtData.Pent[25]=64.1000866854445; nedt->edtData.Pent[26]=54.7489022546362; nedt->edtData.Pent[27]=54.7489022546362; nedt->edtData.Pent[28]=54.7489022546362; nedt->edtData.Pent[29]=54.7489022546362; nedt->edtData.Pent[30]=54.7489022546362; nedt->edtData.Pent[31]=54.7489022546362;
//
//	// vento de superficie
//	nedt->edtData.Vws            = 3.5;
//	nedt->edtData.Azws           = 2524;
//
//	// ventos estimados fase propulsada
//	nedt->edtData.Vweth          = 0;
//	nedt->edtData.Vwnth          = 0;
//
//	// ventos estimados fase free flight
//	nedt->edtData.Vweff          = 0;
//	nedt->edtData.Vwnff          = 0;
//
//	//	nedt->edtData.Elev_tiro=661;
//	//	nedt->edtData.Azim_tiro=1777;
//
//
//	/* CALCULOS */
//	imprimir p(nedt);
//	p.fog(fog);
//	nedt->log(p.txt);
//
//	struct TShot shot;
//
//	shot = nedt->calcularTiro2();
//	//   nedt->edtData.Elev_tiro=616;
//	//   nedt->edtData.Azim_tiro=1753;
//	//   shot = nedt->voarCompleto();
//
//	p.range();
//	p.erro(shot);
//	p.resultados();
//
//	return 1;
//}
