
/******************************************************************************
- TITULO       : bradock.h
- PROPOSITO    :
- AUTOR        :
-              :
- AUDITOR      : -
- DATA         : 08/12/2014 - Daniel Vieira, Anderson Millan
- MODIFICACOES : -
*******************************************************************************/


#ifndef BRADOCK_H_
#define BRADOCK_H_

#include <math.h>

struct prodVetorial {
	double x;
	double y;
	double z;
};
typedef struct prodVetorial prodVetorial;

class bradock {
public:
	static double produtoEscalar(double *x,double *y);
	static double norma(double *x);
	static double produtoVetorial(double *x,double *y, int el);
	static int minimo(double *x, int tam);
	static double arredonda(double x);
	static double trunca(double x);
	static double contaDoZe(double *origem, double *fim);
	static int sinal(double nro);
};

#endif /* BRADOCK_H_ */
